#define _Addr long
#define _Int64 long
#define _Reg long

#if __AARCH64EB__
#define __BYTE_ORDER 4321
#else
#define __BYTE_ORDER 1234
#endif

#define __LONG_MAX 0x7fffffffffffffffL

#ifndef __cplusplus
TYPEDEF unsigned wchar_t;
#endif
TYPEDEF unsigned wint_t;

TYPEDEF int blksize_t;
TYPEDEF unsigned int nlink_t;

TYPEDEF float float_t;
TYPEDEF double double_t;

TYPEDEF struct { long long __ll; long double __ld; } max_align_t;
