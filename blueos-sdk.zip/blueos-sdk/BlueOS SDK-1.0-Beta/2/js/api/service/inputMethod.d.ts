/**
 * input method
 * Interface declaration: {"name": "blueos.service.inputMethod"}
 */
declare module "@blueos.service.inputMethod" {
  /**
   * @desc set the data entered by the input method
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} set input parameters for the data entered by the input method {SetInputParams}
   */
  const setInput: (params: SetInputParams) => void;
}

/**
 * @desc Input parameter
 */
declare interface SetInputParams {
  /**
   *   @desc 	data entered by the input method
   */
  value: string;
}
