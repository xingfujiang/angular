/**
 * system settings
 * Interface declaration: {"name": "blueos.service.settings"}
 */
declare module "@blueos.service.settings" {
  /**
   * @desc get the value of the setting
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Get setting input parameters {GetValueParams}
   */
  const getValue: (params: GetValueParams) => void;

  /**
   * @desc get the value of the setting
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Get setting input parameters {PromiseGetValueParams}
   * @returns {Promise<KeyValue>}
   */
  const getValue: (params: PromiseGetValueParams) => Promise<KeyValue>;

  /**
   * @desc Synchronously get the value of the setting
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {key} get setting input parameters {SystemConfiguration}
   */
  const getValueSync: (key: SystemConfiguration) => any;
}

/**
 * system settings enumeration
 */
declare enum SystemConfiguration {
  /**
   * @desc screen brightness
   */
  Brightness = "brightness",
  /**
   * @desc wearing hand
   */
  WearHand = "wearHand",
  /**
   * @desc Wrist raise detection switch
   */
  RaiseWristSwitch = "raiseWristSwitch",
  /**
   * @desc Wrist raise detection sensitivity
   */
  RaiseWristSensitivity = "raiseWristSensitivity",
  /**
   * @desc silent mode
   */
  SilentMode = "silentMode",
  /**
   * @desc screen rotation
   */
  FlipScreen = "flipScreen",
}

/**
 * @desc return value
 */
declare interface KeyValue {
  /**
   * @desc the field name of the corresponding setting
   */
  key: string;
  /**
   * @desc the value of the corresponding setting
   */
  value: any;
}

/**
 * @desc Input parameter
 */
declare interface PromiseGetValueParams {
  /**
   * @desc the field name of the corresponding setting
   */
  key: string;
}

/**
 * @desc Input parameter
 */
declare interface GetValueParams {
  /**
   * @desc he field name of the corresponding setting
   */
  key: SystemConfiguration;
  /**
   * @desc success callback
   * @param {data} callback function return value {KeyValue}
   */
  success?: (data: KeyValue) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
