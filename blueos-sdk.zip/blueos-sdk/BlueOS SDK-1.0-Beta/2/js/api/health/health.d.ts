/**
 * Health
 * Interface declaration: { "name": "blueos.health.health" }
 */
declare module "@blueos.health.health" {
  /**
   * @desc The supported data types can be:AVERAGE,SUM,MAX,MIN
   */
  const STATISTIC_TYPES: Record<any, any>;

  /**
   * @desc he supported data types can be:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  const DATA_TYPES: Record<any, any>;

  /**
   * @desc 	Obtain the most recent sampling data
   * @param {params} Get input parameters for the most recent sampling data {GetRecentSamplesParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getRecentSamples: (params: GetRecentSamplesParams) => void;

  /**
   * @desc 	Obtain the most recent sampling data
   * @param {params} Get input parameters for the most recent sampling data {PromiseGetRecentSamplesParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data>}
   */
  const getRecentSamples: (
    params: PromiseGetRecentSamplesParams
  ) => Promise<Data>;

  /**
   *   @desc 	Monitor sampling data changes
   *   @param {params} Listen to sampling data changes with input parameters {SubscribeSampleParams}.
   *   @devices (phone,watch)
   *   @apiLevel 1
   */
  const subscribeSample: (params: SubscribeSampleParams) => void;

  /**
   *   @desc 	Cancel sampling data changes
   *   @devices (phone,watch)
   *   @param {params} Listen Cancel sampling data changes input parameters {UnsubscribeSampleParams}.
   *   @apiLevel 1
   */
  const unsubscribeSample: (params: UnsubscribeSampleParams) => void;

  /**
   *   @desc 	Query today's statistical data
   *   @param {params} Input parameters for querying today's statistical data {GetTodayStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   */
  const getTodayStatistic: (params: GetTodayStatisticParams) => void;

  /**
   *   @desc 	Query today's statistical data
   *   @param {params} Input parameters for querying today's statistical data {PromiseGetTodayStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   *   @returns {Promise<Array<string>>}
   */
  const getTodayStatistic: (
    params: PromiseGetTodayStatisticParams
  ) => Promise<Array<string>>;

  /**
   *   @desc 	Query today's statistical data
   *   @param {params} Input parameters for querying today's statistical data {GetStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   */
  const getStatistic: (params: GetStatisticParams) => void;

  /**
   *   @desc 	Query today's statistical data
   *   @param {params} Input parameters for querying today's statistical data {PromiseGetStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   *   @returns {Promise<Array<string>>}
   */
  const getStatistic: (
    params: PromiseGetStatisticParams
  ) => Promise<Array<string>>;

  /**
   *   @desc 	Monitor today's statistical data
   *   @param {params} Input parameters for monitoring today's statistical data{SubscribeTodayStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   */
  const subscribeTodayStatistic: (
    params: SubscribeTodayStatisticParams
  ) => void;

  /**
   *   @desc 	Cancel monitoring of today's statistical data.
   *   @param {params} Input parameters for canceling monitoring of today's statistical data {UnsubscribeTodayStatisticParams}
   *   @devices (phone,watch)
   *   @apiLevel 1
   */
  const unsubscribeTodayStatistic: (
    params: UnsubscribeTodayStatisticParams
  ) => void;
}

/**
 *   @desc Return value
 */
declare interface DataTypeValue {
  /**
   *   @desc Sampling time
   */
  timeStamp: number;
  /**
   *   @desc The specific data value of the queried dataType, with the value type determined by the dataType
   */
  value: any;
}

/**
 *   @desc Return value
 */
declare interface Data {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
  /**
   *   @desc data
   */
  data: DataTypeValue;
}

/**
 * @desc input parameters
 */
declare interface PromiseGetRecentSamplesParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: Array<string>;
}

/**
 * @desc input parameters
 */
declare interface GetRecentSamplesParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: Array<string>;

  /**
   * @desc success callback
   * @param {data} sampling data {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface SubscribeSampleParams {
  /**
   * @desc data type
   */
  dataType: number;

  /**
   * 	@desc callback function
   * 	@param {data} return value of the callback {Array<string>}
   */
  callback: (data: Array<string>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface UnsubscribeSampleParams {
  /**
   * @desc data type
   */
  dataType: number;
}

/**
 * @desc input parameters
 */
declare interface PromiseGetTodayStatisticParams {
  /**
   *   @desc data type
   */
  dataType: number;
  /**
   *   @desc The dimensions of statistics vary by manufacturer, and different dataTypes support different dimensions
   */
  statisticType: string;
}

/**
 * @desc input parameters
 */
declare interface GetTodayStatisticParams {
  /**
   *   @desc data type
   */
  dataType: number;
  /**
   *   @desc The dimensions of statistics vary by manufacturer, and different dataTypes support different dimensions
   */
  statisticType: string;
  /**
   * @desc success callback
   * @param {data} sampling data {Array<string>}
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseGetStatisticParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
  /**
   *   @desc Dimensions of statistics, with some data types supporting detailed statistical chart data
   */
  statisticType: string;

  /**
   *   @desc Start time: Activities that occur after this time are included, as well as activities that began before this time period but have not yet ended
   */
  startTime: number;

  /**
   *   @desc End time: Activities that occur before this time are included, as well as activities that are ongoing but not yet fully completed
   */
  endTime: number;
}

/**
 * @desc input parameters
 */
declare interface GetStatisticParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
  /**
   *   @desc Dimensions of statistics, with some data types supporting detailed statistical chart data
   */
  statisticType: string;

  /**
   *   @desc Start time: Activities that occur after this time are included, as well as activities that began before this time period but have not yet ended
   */
  startTime: number;

  /**
   *   @desc End time: Activities that occur before this time are included, as well as activities that are ongoing but not yet fully completed
   */
  endTime: number;
  /**
   * @desc success callback
   * @param {data} sampling data {Array<string>}
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface SubscribeTodayStatisticParams {
  /**
   * @desc The dimensions of statistics vary by manufacturer, and different data types support different dimensions
   */
  statisticType: number;
  /**
   * @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;

  /**
   * 	@desc callback function
   * 	@param {data} return value of the callback {Array<string>}
   */
  callback: (data: Array<string>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface UnsubscribeTodayStatisticParams {
  /**
   * @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
}
