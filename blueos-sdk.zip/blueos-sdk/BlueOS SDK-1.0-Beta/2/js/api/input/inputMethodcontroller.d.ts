/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodController" }
 */
declare module "@blueos.inputMethod.inputMethodController" {
  /**
   * @desc Close the input method's soft keyboard; after calling this method, the input component will also lose focus
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const dismissKeyboard: () => void;

  /**
   * @desc Monitor the input method's soft keyboard
   * @param {params} Input parameters for monitoring the input method's soft keyboard {SubscribeType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  const subscribeSoftKeyboardSizeChange: (params: SubscribeType) => number;

  /**
   * @desc Cancel monitoring of the input method's soft keyboard
   * @param {params} Parameters for canceling monitoring of the input method's soft keyboard {number}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const unsubscribeSoftKeyboardSizeChange: (params: number) => void;
}

/**
 * @desc input parameters.
 */
declare interface SubscribeType {
  /**
   * @desc monitor callback
   * @param {width} parameter {number}
   * @param {heigth} parameter {number}
   */
  callback: (width: number, heigth: number) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
