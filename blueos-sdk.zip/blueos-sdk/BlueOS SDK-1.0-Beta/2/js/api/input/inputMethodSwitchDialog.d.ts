/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodSwitchDialog" }
 */
declare module "@blueos.inputMethod.inputMethodSwitchDialog" {
  /**
   * @desc Pop up the input method switch component
   * @param {params} Input parameters for popping up the input method switch component {ShowType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const show: (params?: ShowType) => void;

  /**
   * @desc Pop up the input method switch component
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const show: () => Promise<void>;
}

/**
 * @desc input parameters.
 */
declare interface ShowType {
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
