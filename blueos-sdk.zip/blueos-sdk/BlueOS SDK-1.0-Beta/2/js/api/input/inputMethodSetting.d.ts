/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodSetting" }
 */
declare module "@blueos.inputMethod.inputMethodSetting" {
  /**
   * @desc Get current input method information
   * @param {params} Input parameters for getting current input method information {CurrentInputMethodInfoParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getCurrentInputMethodInfo: (
    params: CurrentInputMethodInfoParams
  ) => void;

  /**
   * @desc Get current input method information
   * @param {params} Input parameters for getting current input method information {PromiseCurrentInputMethodInfoParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<InputMethodInfo>}
   */
  const getCurrentInputMethodInfo: (
    params: PromiseCurrentInputMethodInfoParams
  ) => Promise<InputMethodInfo>;

  /**
   * @desc Get the current input method's subtype
   * @param {params} Input parameters for getting the current input method's subtype {GetMethodSubtypeParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getCurrentInputMethodSubtype: (params?: GetMethodSubtypeParams) => void;

  /**
   * @desc Get the current input method's subtype
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<InputMethodSubtype>}
   */
  const getCurrentInputMethodSubtype: () => Promise<InputMethodSubtype>;

  /**
   * @desc Set the current input method's subtype
   * @param {params} Input parameters for setting the current input method's subtype {SetMethodSubtypeParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const setCurrentInputMethodSubtype: (params: SetMethodSubtypeParams) => void;

  /**
   * @desc Set the current input method's subtype
   * @param {params} Input parameters for setting the current input method's subtype {PromiseSetMethodSubtypeParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const setCurrentInputMethodSubtype: (
    params: PromiseSetMethodSubtypeParams
  ) => Promise<void>;

  /**
   * @desc Callback triggered when the current input method's subtype changes
   * @param {params} Input parameters for the callback triggered when the current input method's subtype changes {InputMethodSubtype}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onInputMethodSubtypeChanged: (params: InputMethodSubtype) => void;

  /**
   * @desc Get the list of enabled input methods
   * @param {params} Input parameters for getting the list of enabled input methods {EnabledInputMethodListtype}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getEnabledInputMethodList: (
    params?: EnabledInputMethodListtype
  ) => void;

  /**
   * @desc Get the list of enabled input methods
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Array<InputMethodInfo>>}
   */
  const getEnabledInputMethodList: () => Promise<Array<InputMethodInfo>>;

  /**
   * @desc Get the list of installed input methods
   * @param {params} Input parameters for getting the list of installed input methods {InputMethodListType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getInputMethodList: (params: InputMethodListType) => void;

  /**
   * @desc Get the list of installed input methods
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Array<InputMethodInfo>>}
   */
  const getInputMethodList: () => Promise<Array<InputMethodInfo>>;

  /**
   * @desc Switch input method
   * @param {params} Input parameters for switching input methods {InputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const switchInputMethod: (params: InputMethodType) => void;

  /**
   * @desc Switch input method
   * @param {params} Input parameters for switching input methods {InputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const switchInputMethod: (params: PromiseInputMethodType) => Promise<void>;

  /**
   * @desc Switch input method to the specified subtype
   * @param {params} nput parameters for switching input method to the specified subtype {InputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const switchInputMethodAndSubtype: (params: InputMethodAndSubtype) => void;

  /**
   * @desc Switch input method to the specified subtype
   * @param {params} nput parameters for switching input method to the specified subtype {InputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const switchInputMethodAndSubtype: (
    params: PromiseInputMethodAndSubtype
  ) => Promise<void>;

  /**
   * @desc Get the subtypes of the specified input method
   * @param {params} Input parameters for getting the subtypes of the specified input method {InputMethodSubtypeListType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getInputMethodSubtypeList: (params: InputMethodSubtypeListType) => void;

  /**
   * @desc Get the subtypes of the specified input method
   * @param {params} Input parameters for getting the subtypes of the specified input method {PromiseInputMethodSubtypeListType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<InputMethodSubtype>}
   */
  const getInputMethodSubtypeList: (
    params: PromiseInputMethodSubtypeListType
  ) => Promise<InputMethodSubtype>;

  /**
   * @desc Enable input method
   * @param {params} Input parameters for enabling the input method {EnableInputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const enableInputMethod: (params: EnableInputMethodType) => void;

  /**
   * @desc Enable input method
   * @param {params} Input parameters for enabling the input method {PromiseEnableInputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const enableInputMethod: (
    params: PromiseEnableInputMethodType
  ) => Promise<void>;

  /**
   * @desc Disable input method
   * @param {params} Input parameters for disabling the input method {DisableInputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const disableInputMethod: (params: DisableInputMethodType) => void;

  /**
   * @desc Disable input method
   * @param {params} Input parameters for disabling the input method {PromiseDisableInputMethodType}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const disableInputMethod: (
    params: PromiseDisableInputMethodType
  ) => Promise<void>;
}

/**
 * @desc input parameters
 */
declare interface PromiseDisableInputMethodType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
}

/**
 * @desc input parameters
 */
declare interface DisableInputMethodType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseEnableInputMethodType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
}

/**
 * @desc input parameters
 */
declare interface EnableInputMethodType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

declare interface PromiseInputMethodSubtypeListType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
}

/**
 * @desc input parameters
 */
declare interface InputMethodSubtypeListType {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   */
  success?: (data: InputMethodSubtype) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseInputMethodAndSubtype {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
  /**
   * @desc input method subtype ID
   */
  subtypeId: number;
}

/**
 * @desc input parameters
 */
declare interface InputMethodAndSubtype {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
  /**
   * @desc input method subtype ID
   */
  subtypeId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseInputMethodType {
  /**
   * @desc input method subtype ID
   */
  inputMethodId: number;
}

/**
 * @desc input parameters
 */
declare interface InputMethodType {
  /**
   * @desc input method subtype ID
   */
  inputMethodId: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface InputMethodListType {
  /**
   * @desc Success callback
   * @param {imInfos} callback return value {Array<InputMethodInfo>}
   */
  success?: (imInfos: Array<InputMethodInfo>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface EnabledInputMethodListtype {
  /**
   * @desc Success callback
   */
  success?: (imInfos: Array<InputMethodInfo>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseSetMethodSubtypeParams {
  /**
   * @desc input method subtype ID
   */
  inputMethodSubtypeId: number;
}

/**
 * @desc input parameters
 */
declare interface SetMethodSubtypeParams {
  /**
   * @desc input method subtype ID
   */
  inputMethodSubtypeId: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface GetMethodSubtypeParams {
  /**
   * @desc Success callback
   * @param {data} callback parameters {InputMethodSubtype}
   */
  success?: (data: InputMethodSubtype) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface InputMethodSubtype {
  /**
   * @desc input subtype identifier
   */
  id: string;

  /**
   * @desc BCP 47 format, such as 'zh-CN' or 'en-US'
   */
  languageTag: string;

  /**
   * @desc display name of the input method subtype
   */
  displayName: string;

  /**
   * @desc input method icon
   */
  icon: string;
}

/**
 * @desc input parameters
 */
declare interface CurrentInputMethodInfoParams {
  /**
   * @desc Success callback
   * @param {data} callback parameters {InputMethodInfo}
   */
  success?: (data: InputMethodInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface InputMethodInfo {
  /**
   * @desc  input method ID
   */
  id: string;

  /**
   * @desc input method display name
   */
  displayName: string;

  /**
   * @desc nput method name
   */
  name: string;

  /**
   * @desc input method icon
   */
  icon: string;
}
