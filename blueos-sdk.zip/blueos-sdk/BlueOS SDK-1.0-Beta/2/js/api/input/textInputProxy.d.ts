/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.textInputProxy" }
 */
declare module "@blueos.inputMethod.textInputProxy" {
  /**
   * @desc Insert text into the input component
   * @param {params} input parameters {TextParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const insertText: (param: TextParam) => void;

  /**
   * @desc Insert text into the input component
   * @param {params} input parameters {PromiseTextParam}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const insertText: (param: PromiseTextParam) => Promise<void>;

  /**
   * @desc trigger a function key
   * @param {params} input parameters {ActionParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const sendKeyAction: (param: ActionParam) => void;

  /**
   * @desc trigger a function key
   * @param {params} input parameters {PromiseActionParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const sendKeyAction: (param: PromiseActionParam) => Promise<void>;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {params} input parameters {BackwardParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const deleteBackward: (param: BackwardParam) => void;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {params} input parameters {PromiseBackwardParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const deleteBackward: (param: PromiseBackwardParam) => Promise<void>;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {params} input parameters {ForwardParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const deleteForward: (params: ForwardParam) => void;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {params} input parameters {PromiseForwardParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const deleteForward: (params: PromiseForwardParam) => Promise<void>;

  /**
   * @desc Get the currently selected text (if any)
   * @param {params} input parameters {BackwardParam}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getSelectedText: (params?: SelectedTextParam) => void;

  /**
   * @desc Get the currently selected text (if any)
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getSelectedText: () => Promise<string>;

  /**
   * @desc Set selected text.
   * @param {params} input parameters {SelectionParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const setSelection: (params: SelectionParams) => void;

  /**
   * @desc Set selected text.
   * @param {params} input parameters {PromiseSelectionParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const setSelection: (params: PromiseSelectionParams) => Promise<void>;

  /**
   * @desc Get the text of n characters after the current cursor position
   * @param {params} input parameters {TextAfterCursorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getTextAfterCursor: (params: TextAfterCursorParams) => void;

  /**
   * @desc Get the text of n characters after the current cursor position
   * @param {params} input parameters {PromiseTextAfterCursorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getTextAfterCursor: (
    params: PromiseTextAfterCursorParams
  ) => Promise<string>;

  /**
   * @desc Get the text of n characters before the current cursor position
   * @param {params} input parameters {TextBeforeCursorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getTextBeforeCursor: (params: TextBeforeCursorParams) => void;

  /**
   * @desc Get the text of n characters before the current cursor position
   * @param {params} input parameters {PromiseTextBeforeCursorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getTextBeforeCursor: (
    params: PromiseTextBeforeCursorParams
  ) => Promise<string>;

  /**
   * @desc Callback for changes in the text of the input field
   * @param {params} input parameters {string}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onUpdateText: (params: string) => void;

  /**
   * @desc Callback for changes in the selected text
   * @param {params} input parameters {UpdateSelectionParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onUpdateSelection: (params: UpdateSelectionParams) => void;

  /**
   * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
   */
  const inputType: InputType;

  /**
   * @desc A read-only property that retrieves the enter button type set for the input field; returns an empty string if not set
   */
  const enterKeyType: EnterKeyType;
}

/**
 * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
 */
type InputType = "text" | "email";

/**
 * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
 */
type EnterKeyType = "search" | "send";

/**
 * @desc input parameters
 */
declare interface UpdateSelectionParams {
  /**
   * @desc starting index of the selection before the change
   */
  oldSelStart: number;

  /**
   * @desc ending index of the selection before the change
   */
  oldSelEnd: number;

  /**
   * @desc starting index of the selection after the change
   */
  newSelStart: number;

  /**
   * @desc ending index of the selection after the change
   */
  newSelEnd: number;
}

/**
 * @desc input parameters
 */
declare interface PromiseTextBeforeCursorParams {
  /**
   * @desc Get character length
   */
  length: number;
}

/**
 * @desc input parameters
 */
declare interface TextBeforeCursorParams {
  /**
   * @desc Get character length
   */
  length: number;

  /**
   * @desc success callback
   * @param {text} return value {string}
   */
  success?: (text: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseTextAfterCursorParams {
  /**
   * @desc get character length
   */
  length: number;
}

/**
 * @desc input parameters
 */
declare interface TextAfterCursorParams {
  /**
   * @desc get character length
   */
  length: number;

  /**
   * @desc success callback
   * @param {text} return value {string}
   */
  success?: (text: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseSelectionParams {
  /**
   * @desc starting index, beginning from 0
   */
  start: number;
  /**
   * @desc  ending index, beginning from 0
   */
  end: number;
}

/**
 * @desc input parameters
 */
declare interface SelectionParams {
  /**
   * @desc starting index, beginning from 0
   */
  start: number;
  /**
   * @desc  ending index, beginning from 0
   */
  end: number;

  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface SelectedTextParam {
  /**
   * @desc success callback
   * @param {text} return value {string}
   */
  success?: (text: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseForwardParam {
  /**
   * @desc deletion length, default value is 1
   */
  length?: number;
}

/**
 * @desc input parameters
 */
declare interface ForwardParam {
  /**
   * @desc deletion length, default value is 1
   */
  length?: number;

  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseBackwardParam {
  /**
   * @desc deletion length, default is 1
   */
  length?: number;
}

/**
 * @desc input parameters
 */
declare interface BackwardParam {
  /**
   * @desc deletion length, default is 1
   */
  length?: number;

  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseActionParam {
  /**
   * @desc text data to be inserted
   */
  value: string;
}

/**
 * @desc input parameters
 */
declare interface ActionParam {
  /**
   * @desc text data to be inserted
   */
  value: string;

  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface TextParam {
  /**
   * @desc text data to be inserted
   */
  value: string;

  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseTextParam {
  /**
   * @desc text data to be inserted
   */
  value: string;
}
