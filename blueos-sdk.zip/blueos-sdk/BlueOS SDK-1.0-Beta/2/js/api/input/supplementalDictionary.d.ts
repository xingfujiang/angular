/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.supplementalDictionary" }
 */
declare module "@blueos.inputMethod.supplementalDictionary" {
  /**
   * @desc get value
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} input parameters {DictionaryType}
   */
  const getDictionary: (params?: DictionaryType) => void;

  /**
   * @desc get value
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Dictionary[]>}
   */
  const getDictionary: () => Promise<Dictionary[]>;
}

declare interface DictionaryType {
  /**
   * @desc success callback
   * @param {data} return value {Dictionary[]}
   */
  success?: (data: Dictionary[]) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc return value
 */
declare interface Dictionary {
  /**
   * @desc icon
   */
  lexicon: string;
}
