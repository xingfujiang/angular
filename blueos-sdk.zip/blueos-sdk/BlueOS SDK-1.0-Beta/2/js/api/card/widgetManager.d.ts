/**
 * WidgetProvider refreshes the uiData on the card UI page through the WidgetManager. The WidgetManager can also be used by the main application to refresh the uiData
 * Interface declaration: {"name": "blueos.app.widgetManager"}
 */
declare module "@blueos.app.widgetManager" {
  /**
   * @desc Update card UI data
   * @param {params} Input parameter: { UpdateUiDataParams }
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const updateUiData: (params: UpdateUiDataParams) => void;

  /**
   * @desc Set the card refresh interval, which can override the refreshDuration configuration in the manifest
   * @param {params} Input parameter: {SetRefreshDurationParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const setRefreshDuration: (params: SetRefreshDurationParams) => void;

  /**
   * @desc Set the card refresh interval, which can override the refreshDuration configuration in the manifest
   * @param {params} Input parameter: {SetRefreshDurationParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const setRefreshDuration: (
    params: PromiseSetRefreshDurationParams
  ) => Promise<void>;
}

/**
 * @desc Data being passed
 */
declare interface UpdateUiDataParams {
  /**
   * @desc Widget instance ID
   */
  instanceId: number | string;

  /**
   * @desc Data being passed
   */
  uiData?: Record<string, any>;
}

/**
 * @desc Data being passed
 */
declare interface SetRefreshDurationParams {
  /**
   * @desc Card URI, formatted as: hap://widget/$packageName/$moduleName
   */
  uri: string;
  /**
   * @desc Scheduled data refresh interval, in seconds
   */
  refreshDuration: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSetRefreshDurationParams {
  /**
   * @desc Card URI, formatted as: hap://widget/$packageName/$moduleName
   */
  uri: string;
  /**
   * @desc Scheduled data refresh interval, in seconds
   */
  refreshDuration: number;
}
