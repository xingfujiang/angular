/**
 * statvfs is a module used to obtain application space, including interfaces to get available space and total space, and supports both synchronous and asynchronous operations
 * Interface declaration: { "name": "blueos.storage.statvfs" }
 */
declare module "@blueos.storage.statvfs" {
  /**
   * @desc Query the available space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter  {GetFreeSizeParams}
   */
  const getFreeSize: (params: GetFreeSizeParams) => void;

  /**
   * @desc Query the available space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter  {PromiseGetFreeSizeParams}
   * @returns {Promise<number>}
   */
  const getFreeSize: (params: PromiseGetFreeSizeParams) => Promise<number>;

  /**
   * @desc Query the available space size of the specified file system, synchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {path} Input parameter  {string}
   * @returns {number}
   */
  const getFreeSizeSync: (path: string) => number;

  /**
   * @desc Query the total space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter  {GetTotalSizeParams}
   */
  const getTotalSize: (params: GetTotalSizeParams) => void;

  /**
   * @desc Query the total space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter  {PromiseGetTotalSizeParams}
   * @returns {Promise<number>}
   */
  const getTotalSize: (params: PromiseGetTotalSizeParams) => Promise<number>;

  /**
   * @desc Query the total space size of the specified file system, synchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {path} Input parameter  {string}
   * @returns {number}
   */
  const getTotalSizeSync: (path: string) => number;
}

/**
 * @desc input parameter
 */
declare interface PromiseGetFreeSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
}

/**
 * @desc input parameter
 */
declare interface GetFreeSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
  /**
   * @desc success callback
   * @param {size} callback function return value {number}
   */
  success?: (size: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseGetTotalSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
}

/**
 * @desc input parameter
 */
declare interface GetTotalSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
  /**
   * @desc success callback
   * @param {size} callback function return value {number}
   */
  success?: (size: number) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
