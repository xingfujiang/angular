/**
 * File storage, the application can only access the storage space within its sandbox. See URI for details{@link SandboxURI}
 * Interface declaration: {"name": "blueos.storage.file"}
 */
declare module "@blueos.storage.file" {
  /**
   * @desc File moving
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {MoveParams}
   */
  const move: (params: MoveParams) => void;

  /**
   * @desc File moving
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseMoveParams}
   * @returns {Promise<string>}
   */
  const move: (params: PromiseMoveParams) => Promise<string>;

  /**
   * @desc File copy" or "File copying
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {CopyParams}
   */
  const copy: (params: CopyParams) => void;

  /**
   * @desc File copy" or "File copying
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseCopyParams}
   * @returns {Promise<string>}
   */
  const copy: (params: PromiseCopyParams) => Promise<string>;

  /**
   * @desc Retrieve the list of files in the specified directory; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter {ListParams}
   */
  const list: (params: ListParams) => void;

  /**
   * @desc Retrieve the list of files in the specified directory; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseListParams}
   * @returns {Promise<ListData>}
   */
  const list: (params: PromiseListParams) => Promise<ListData>;

  /**
   * @desc Retrieve file information; please refer to the URI description used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {GetDataParams}
   */
  const get: (params: GetDataParams) => void;

  /**
   * @desc Retrieve file information; please refer to the URI description used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseGetDataParams}
   * @returns {Promise<DataInfo>}
   */
  const get: (params: PromiseGetDataParams) => Promise<DataInfo>;

  /**
   * @desc Delete locally stored files; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {DelParams}
   */
  const del: (params: DelParams) => void;

  /**
   * @desc Delete locally stored files; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseDelParams}
   * @returns {Promise<any>}
   */
  const del: (params: PromiseDelParams) => Promise<any>;

  /**
   * @desc Write text to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {CopyParams}
   */
  const writeText: (params: WriteTextParams) => void;

  /**
   * @desc Write text to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseWriteTextParams}
   * @returns {Promise<void>}
   */
  const writeText: (params: PromiseWriteTextParams) => Promise<void>;

  /**
   * @desc Write buffer to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {WriteArrayBufferParams}
   */
  const writeArrayBuffer: (params: WriteArrayBufferParams) => void;

  /**
   * @desc Write buffer to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseWriteArrayBufferParams}
   * @returns {Promise<void>}
   */
  const writeArrayBuffer: (
    params: PromiseWriteArrayBufferParams
  ) => Promise<void>;

  /**
   * @desc Read text from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {ReadTextParams}
   */
  const readText: (params: ReadTextParams) => void;

  /**
   * @desc Read text from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseReadTextParams}
   */
  const readText: (params: PromiseReadTextParams) => Promise<ValueText>;

  /**
   * @desc Read buffer from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {ReadArrayBufferParams}
   */
  const readArrayBuffer: (params: ReadArrayBufferParams) => void;

  /**
   * @desc Read buffer from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseReadArrayBufferParams}
   * @returns {Promise<BufferData>}
   */
  const readArrayBuffer: (
    params: PromiseReadArrayBufferParams
  ) => Promise<BufferData>;

  /**
   * @desc Check if a file or directory exists
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {AccessParams}
   */
  const access: (params: AccessParams) => void;

  /**
   * @desc Check if a file or directory exists
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseAccessParams}
   * @returns {Promise<void>}
   */
  const access: (params: PromiseAccessParams) => Promise<void>;

  /**
   * @desc Create directory
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameter  {MkdirParams}
   */
  const mkdir: (params: MkdirParams) => void;

  /**
   * @desc Create directory
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {PromiseMkdirParams}
   */
  const mkdir: (params: PromiseMkdirParams) => Promise<void>;

  /**
   * @desc Delete directory
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter {RmdirParams}
   */
  const rmdir: (params: RmdirParams) => void;

  /**
   * @desc Delete directory
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseRmdirParams}
   * @returns {Promise<void>}
   */
  const rmdir: (params: PromiseRmdirParams) => Promise<void>;

  export {
    del as delete,
    rmdir,
    mkdir,
    access,
    readArrayBuffer,
    readText,
    writeArrayBuffer,
    writeText,
    get,
    list,
    copy,
    move,
  };
}

/**
 * @desc input parameter
 */
declare interface PromiseMoveParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
}

/**
 * @desc input parameter
 */
declare interface MoveParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
  /**
   * @desc success callback
   * @param {uri} callback function return value {string}
   */
  success?: (uri: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseCopyParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
}

/**
 * @desc input parameter
 */
declare interface CopyParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
  /**
   * @desc success callback
   * @param {uri} callback function return value {string}
   */
  success?: (uri: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseListParams {
  /**
   *  @desc The URI of the directory, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
}

/**
 * @desc Return value
 */
declare interface FileListData {
  /**
   * @desc  File URI
   */
  uri: string;
  /**
   * @desc File size, in bytes
   */
  length: number;
  /**
   * @desc  The timestamp of the last modification of the file, in milliseconds since 1970/01/01 00:00:00 GMT to the current time
   */
  lastModifiedTime: number;
}

/**
 * @desc Return value
 */
declare interface ListData {
  /**
   * @desc File list, where each file is formatted as {uri:'file1', lastModifiedTime:1234456, length:123456}.
   */
  fileList: Array<FileListData>;
}

/**
 * @desc input parameter
 */
declare interface ListParams {
  /**
   *  @desc The URI of the directory, which cannot be an application resource path or a tmp type URI.
   */
  uri: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {ListData}
   */
  success?: (data: ListData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface DataInfo {
  /**
   * @desc  File URI
   */
  uri: string;
  /**
   * @desc File size, in bytes
   */
  length: number;
  /**
   * @desc  The timestamp of the last modification of the file, in milliseconds since 1970/01/01 00:00:00 GMT to the current time
   */
  lastModifiedTime: number;
  /**
   * @desc File type, dir: directory; file: file
   */
  type: string;
  /**
   * @desc File list, recursively returning detailed information for files in subdirectories when recursive is true and type is dir; otherwise, it does not return
   */
  subFiles: string[];
}

/**
 * @desc input parameter
 */
declare interface PromiseGetDataParams {
  /**
   * @desc The URI of the file, which cannot be an application resource path
   */
  uri: string;
  /**
   *
   * @desc Whether to recursively retrieve the file list of subdirectories. Default is false
   */
  recursive?: boolean;
}

/**
 * @desc input parameter
 */
declare interface GetDataParams {
  /**
   * @desc The URI of the file, which cannot be an application resource path
   */
  uri: string;
  /**
   *
   * @desc Whether to recursively retrieve the file list of subdirectories. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   * @param {data} callback function return value {DataInfo}
   */
  success?: (data: DataInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseDelParams {
  /**
   * @desc The URI of the file to be deleted, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
}

/**
 * @desc input parameter
 */
declare interface DelParams {
  /**
   * @desc The URI of the file to be deleted, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {any}
   */
  success?: (data: any) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseWriteTextParams {
  /**
   * @desc Local file path, resource file paths and tmp partitions are not supported. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc The string to be written
   */
  text: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
  /**
   * @desc Whether to use append mode, default is false
   */
  append?: boolean;
}

/**
 * @desc input parameter
 */
declare interface WriteTextParams {
  /**
   * @desc Local file path, does not support resource file paths and tmp partitions. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc he string to be written
   */
  text: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
  /**
   * @desc Whether to use append mode, default is false
   */
  append?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseWriteArrayBufferParams {
  /**
   * @desc Local file path; resource file paths and tmp partitions are not supported. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc The buffer to be written
   */
  buffer: Uint8Array;
  /**
   * @desc The offset position in the file where data writing begins, default is 0.
   */
  position?: number;
  /**
   * @desc Whether to use append mode, default is false. When true, the position parameter is ignored
   */
  append?: boolean;
}

/**
 * @desc input parameter
 */
declare interface WriteArrayBufferParams {
  /**
   * @desc Local file path; resource file paths and tmp partitions are not supported. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc The buffer to be written
   */
  buffer: Uint8Array;
  /**
   * @desc The offset position where data writing begins in the file, default is 0.
   */
  position?: number;
  /**
   * @desc Whether to use append mode, default is false. When true, the position parameter is ignored
   */
  append?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseReadTextParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
}

/**
 * @desc Return value
 */
declare interface ValueText {
  /**
   * @desc Read text
   */
  text: string;
}

/**
 * @desc input parameter
 */
declare interface ReadTextParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {ValueText}
   */
  success?: (data: ValueText) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseReadArrayBufferParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Starting position for reading, default is the beginning of the file
   */
  position?: number;
  /**
   * @desc Length to read; if not specified, reads until the end of the file
   */
  length?: number;
}

/**
 * @desc Return value
 */
declare interface BufferData {
  /**
   * The content read from the file
   */
  buffer: Uint8Array;
}

/**
 * @desc input parameter
 */
declare interface ReadArrayBufferParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Starting position for reading, default is the beginning of the file
   */
  position?: number;
  /**
   * @desc Length to read; if not specified, reads until the end of the file
   */
  length?: number;
  /**
   * @desc success callback
   * @param {data} callback function return value {BufferData}
   */
  success?: (data: BufferData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseAccessParams {
  /**
   * @desc Directory or file URI, which cannot be an application resource path or a tmp type URI.
   */
  uri: string;
}

/**
 * @desc input parameter
 */
declare interface AccessParams {
  /**
   * @desc Directory or file URI, which cannot be an application resource path or a tmp type URI.
   */
  uri: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseMkdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
}

/**
 * @desc input parameter
 */
declare interface MkdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseRmdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
}

/**
 * @desc input parameter
 */
declare interface RmdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
