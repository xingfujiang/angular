/**
 * Key-value format data storage
 * Interface declaration: {"name": "blueos.storage.storage"}
 */
declare module "@blueos.storage.storage" {
  /**
   * @desc The number of data items in the storage
   */
  const length: number;

  /**
   * @desc Read storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {GetStorageParams}
   */
  const get: (params: GetStorageParams) => void;

  /**
   * @desc Read storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseGetStorageParams}
   * @returns {Promise<any>}
   */
  const get: (params: PromiseGetStorageParams) => Promise<any>;

  /**
   * @desc Set storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {SetStorageParams}
   */
  const set: (params: SetStorageParams) => void;

  /**
   * @desc Set storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseSetStorageParams}
   * @returns {Promise<void>}
   */
  const set: (params: PromiseSetStorageParams) => Promise<void>;

  /**
   * @desc Clear storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {ClearStorageParams}
   */
  const clear: (params?: ClearStorageParams) => void;

  /**
   * @desc Clear storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const clear: () => Promise<void>;

  /**
   * @desc Delete storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {DelStorageParams}
   */
  const del: (params: DelStorageParams) => void;

  /**
   * @desc Delete storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseDelStorageParams}
   * @returns {Promise<any>}
   */
  const del: (params: PromiseDelStorageParams) => Promise<any>;

  /**
   * @desc Return the key name of an index in the storage
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {KeyStorageParams}
   */
  const key: (params: KeyStorageParams) => void;

  /**
   * @desc Return the key name of an index in the storage
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseKeyStorageParams}
   * @returns {Promise<string>}
   */
  const key: (params: PromiseKeyStorageParams) => Promise<string>;

  /**
   * @desc Synchronously read storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {GetSyncStorageParams}
   * @returns {TypeValue}
   */
  const getSync: (params: GetSyncStorageParams) => TypeValue;

  export { del as delete, get, set, getSync, key, clear, length };
}

/**
 * @desc Return value type
 */
type TypeValue = string | boolean | number | object | Array<string>;

/**
 * @desc input parameter
 */
declare interface PromiseGetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc If the key does not exist, return default. If default is not specified, return a zero-length empty string
   */
  default?: string;
}

/**
 * @desc input parameter
 */
declare interface GetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc If the key does not exist, return default. If default is not specified, return a zero-length empty string
   */
  default?: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {any}
   */
  success?: (data: any) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseSetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc New value. If the new value is a zero-length empty string, the data item indexed by the key will be deleted
   */
  value?: any;
}

/**
 * @desc input parameter
 */
declare interface SetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc New value. If the new value is a zero-length empty string, the data item indexed by the key will be deleted
   */
  value?: any;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface ClearStorageParams {
  /**
   * @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseDelStorageParams {
  /**
   * @desc index
   */
  key: string;
}

/**
 * @desc input parameter
 */
declare interface DelStorageParams {
  /**
   * @desc index
   */
  key: string;

  /**
   * @desc success callback
   * @param {data} callback function return value {any}
   */
  success?: (data: any) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseKeyStorageParams {
  /**
   * @desc The index corresponding to the key name to be queried
   */
  index: number;
}

/**
 * @desc input parameter
 */
declare interface KeyStorageParams {
  /**
   * @desc The index corresponding to the key name to be queried.
   */
  index: number;

  /**
   * @desc success callback
   * @param {data} callback function return value {string}
   */
  success?: (data: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface GetSyncStorageParams {
  /**
   * @desc index
   */
  key: string;
}
