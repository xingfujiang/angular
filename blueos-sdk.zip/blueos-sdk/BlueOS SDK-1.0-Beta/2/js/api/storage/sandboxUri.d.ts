/**
 * Application sandbox directory enumeration
 */
declare enum SandboxURI {
  /**
   * This directory is used to store small but important data. It is long-lasting and can hold text files
   */
  Files = "internal://files/",
  /**
   * This directory is used to store large but less important data. It is long-lasting
   */
  Cache = "internal://cache/",
  /**
   * This directory is used to store cache files, suitable for saving unimportant cache data
   */
  Mass = "internal://mass/",
  /**
   * This directory is used to store temporary files that may be cleared after the application exits
   */
  Tmp = "internal://tmp/",
}
