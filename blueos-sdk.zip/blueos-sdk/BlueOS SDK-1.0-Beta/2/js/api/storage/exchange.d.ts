/**
 * Data sharing between applications
 * Interface declaration: { "name": "blueos.storage.exchange" }
 */
declare module "@blueos.storage.exchange" {
  /**
   * @desc Read the application's shared data
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Read data input parameters {GetParams}
   */
  const get: (params: GetParams) => void;

  /**
   * @desc Read the application's shared data
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Read data input parameters {PromiseGetParams}
   * @returns {Promise<ValueData>}
   */
  const get: (params: PromiseGetParams) => Promise<ValueData>;

  /**
   * @desc Set shared data
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for setting shared data {SetParams}
   */
  const set: (params: SetParams) => void;

  /**
   * @desc Set shared data
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for setting shared data {PromiseSetParams}
   * @returns {Promise<void>}
   */
  const set: (params: PromiseSetParams) => Promise<void>;

  /**
   * @desc Synchronously read the application's shared data to access data from the application space, vendor space, or global space
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters {GetSyncParams}
   * @returns {ValueType}
   */
  const getSync: (params: GetSyncParams) => ValueType;
}

/**
 * @desc Return value type
 */
type ValueType = string | boolean | number | object | Array<string>;

/**
 * @desc Return value
 */
declare interface ValueData {
  /**
   * @desc Return value
   */
  value: string;
}

/**
 * @desc input parameter
 */
declare interface PromiseGetParams {
  /**
   * @desc Key of the data
   */
  key: string;
  /**
   * @desc The package name of the data publisher must be provided when the scope is set to application, and it must be empty when the scope is set to global.
   */
  package?: string;
  /**
   * @desc The SHA-256 hash of the data publisher's signature must be provided when the scope is set to application, and it must be empty when the scope is set to global
   */
  sign?: string;
  /**
   * @desc The data publishing space type supports 'application' and 'global', with 'application' as the default
   */
  scope?: string;
}

/**
 * @desc input parameter
 */
declare interface GetParams {
  /**
   * @desc Key of the data
   */
  key: string;
  /**
   * @desc The package name of the data publisher must be provided when the scope is set to application, and it must be empty when the scope is set to global
   */
  package?: string;
  /**
   * @desc The SHA-256 hash of the data publisher's signature must be provided when the scope is set to application, and it must be empty when the scope is set to global
   */
  sign?: string;
  /**
   * @desc The space type for data publishing supports 'application' and 'global', with 'application' as the default
   */
  scope?: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {ValueData}
   */
  success?: (data: ValueData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseSetParams {
  /**
   * @desc Key of the data
   */
  key: string;
  /**
   * @desc Value of the data
   */
  value: string;
  /**
   * @desc The space type for data publishing supports 'application', 'vendor', and 'global', with 'application' as the default
   */
  scope?: string;
  /**
   *@desc  The package name of the application that needs to write data to the application space of a particular app. This is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'
   */
  package?: string;
  /**
   * @desc The SHA-256 hash of the application signature is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'.
   */
  sign?: string;
}

/**
 * @desc input parameter
 */
declare interface SetParams {
  /**
   * @desc Key of the data
   */
  key: string;
  /**
   * @desc Value of the data
   */
  value: string;
  /**
   * @desc The space type for data publishing supports 'application', 'vendor', and 'global', with 'application' as the default
   */
  scope?: string;
  /**
   *@desc  The package name of the application that needs to write data to the application space of a particular app. This is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'
   */
  package?: string;
  /**
   * @desc The SHA-256 hash of the application signature is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'.
   */
  sign?: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface GetSyncParams {
  /**
   * @desc Key of the data
   */
  key: string;
  /**
   * @desc The space type for data publishing supports 'application', 'vendor', and 'global', with 'application' as the default
   */
  scope?: string;
  /**
   *@desc  The package name of the application that needs to write data to the application space of a particular app. This is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'
   */
  package?: string;
  /**
   * @desc The SHA-256 hash of the application signature is effective only when the scope parameter is unset or set to 'application'. It can be set to null when the scope is 'global'.
   */
  sign?: string;
}
