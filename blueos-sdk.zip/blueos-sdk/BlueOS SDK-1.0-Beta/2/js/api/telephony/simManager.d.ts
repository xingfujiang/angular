/**
 * SIM card management
 * Interface declaration: {"name": "blueos.telephony.simManager"}
 */
declare module "@blueos.telephony.simManager" {
  /**
   * @desc Obtain SIM card operator information; requires phone permissions
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {GetSimOperatorsParams}
   */
  const getSimOperators: (params?: GetSimOperatorsParams) => void;

  /**
   * @desc Obtain SIM card operator information; requires phone permissions
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<OperatorsData>}
   */
  const getSimOperators: () => Promise<OperatorsData>;
}

/**
 * @desc Return value
 */
declare interface OperatorsData {
  /**
   * @desc SIM card list information
   */
  operators: Array<OperatorData>;
  /**
   * @desc Number of SIM cards
   */
  size: string;
}

/**
 * @desc Return value
 */
declare interface OperatorData {
  /**
   * @desc Return the SIM card operator information. Operator information explanation: this returns MCC+MNC, which is the Mobile Country Code + Mobile Network Code; China Mobile: 46000, 46002, 46004, 46007; China Unicom: 46001, 46006, 46009; China Telecom: 46003, 46005, 46011
   */
  operator: string;
  /**
   * @desc Slot number
   */
  slotIndex: number;
}

/**
 * @desc input parameter
 */
declare interface GetSimOperatorsParams {
  /**
   * @desc success callback
   * @param {data} callback function return value {OperatorsData}
   */
  success?: (data: OperatorsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
