/**
 * package management
 * Interface declaration: {"name": "blueos.package.packageManager"}
 */
declare module "@blueos.package.packageManager" {
  /**
   * @desc Check if the application is installed
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Check if the application has input parameters {HasInstalledParams}
   */
  const hasInstalled: (params: HasInstalledParams) => void;

  /**
   * @desc Detect if the application is installed
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Check if there are input parameters for the application {PromiseHasInstalledParams}
   * @returns {Promise<ResData>}
   */
  const hasInstalled: (params: PromiseHasInstalledParams) => Promise<ResData>;

  /**
   * @desc Install the application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Install application input parameters {InstallParams}
   */
  const install: (params: InstallParams) => void;

  /**
   * @desc Install application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Install application input parameters {PromiseInstallParams}
   * @returns {Promise<ResData>}
   */
  const install: (params: PromiseInstallParams) => Promise<ResData>;

  /**
   * @desc Uninstall application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Uninstall application input parameters {UninstallParams}
   */
  const uninstall: (params: UninstallParams) => void;

  /**
   * @desc Uninstall application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Uninstall application input parameters {PromiseUninstallParams}
   * @returns {Promise<ResData>}
   */
  const uninstall: (params: PromiseUninstallParams) => Promise<ResData>;

  /**
   * @desc Retrieve application version code and version name information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Retrieve input parameters for application version code and version name information {GetInfoParams}
   */
  const getInfo: (params: GetInfoParams) => void;

  /**
   * @desc Retrieve application version code and version name information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Retrieve input parameters for application version code and version name information {PromiseGetInfoParams}
   * @returns {Promise<Packages>}
   */
  const getInfo: (params: PromiseGetInfoParams) => Promise<Packages>;

  /**
   * @desc Retrieve application signature digest information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Parameters for retrieving application signature digest information {GetSignatureDigestsParams}
   */
  const getSignatureDigests: (params: GetSignatureDigestsParams) => void;

  /**
   * @desc Retrieve application signature digest information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Parameters for retrieving application signature digest information {PromiseGetSignatureDigestsParams}
   * @returns {Promise<SignatureDigestsData>}
   */
  const getSignatureDigests: (
    params: PromiseGetSignatureDigestsParams
  ) => Promise<SignatureDigestsData>;

  /**
   * @desc Get the list of currently installed applications
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for retrieving the list of currently installed applications {GetInstalledPackagesParams}
   */
  const getInstalledPackages: (params?: GetInstalledPackagesParams) => void;

  /**
   * @desc Get the list of currently installed applications
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<PackagesData>}
   */
  const getInstalledPackages: () => Promise<PackagesData>;

  /**
   * @desc Get the list of installed cards
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for retrieving the list of installed cards {GetInstalledWidgetsParams}
   */
  const getInstalledWidgets: (params?: GetInstalledWidgetsParams) => void;

  /**
   * @desc Get the list of installed cards
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Widget>}
   */
  const getInstalledWidgets: () => Promise<Widget>;

  /**
   * @desc Synchronously get application categories
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {package} Input parameters for synchronously getting application categories {string}
   * @returns {Array<string>}
   */
  const getAppCategory: (package: string) => Array<string>;

  /**
   * @desc Asynchronously get application categories
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for asynchronously getting application categories {GetAppCategoryAsyncParams}
   */
  const getAppCategoryAsync: (params: GetAppCategoryAsyncParams) => void;

  /**
   * @desc Asynchronously get application categories
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for asynchronously getting application categories {PromiseGetAppCategoryAsyncParams}
   * @returns {Promise<string[]>}
   */
  const getAppCategoryAsync: (
    params: PromiseGetAppCategoryAsyncParams
  ) => Promise<string[]>;
}

/**
 * @desc card type
 */
type CardType = "js" | "lite";

/**
 * @desc Widget information
 */
declare interface Widget {
  /**
   *  @desc package name
   */
  package: string;
  /**
   *  @desc card module name
   */
  moduleName: string;
  /**
   *  @desc card type
   */
  type: CardType;
  /**
   *  @desc Card name, supports multiple languages
   */
  name: string;
  /**
   *  @desc Card description, supports multiple languages
   */
  description: string;
  /**
   *  @desc Minimum supported platform version number
   */
  minPlatformVersion: number;
  /**
   *  @desc Represents the timed data refresh interval, in seconds
   */
  refreshDuration: number;
  /**
   *  @desc Indicates the scheduled refresh times for the card, using the 24-hour format, accurate to the minute, e.g., ['10:30', '21:30']
   */
  scheduledRefreshTime: string[];
  /**
   *  @desc card size
   */
  sizes: string[];
  /**
   *  @desc Supported device types for the card
   */
  deviceTypeList: DeviceType[];
  /**
   *  @desc Card preview image
   */
  previewImages: PreviewImage[];
}

/**
 * @desc device type
 */
type DeviceType = "watch" | "tv" | "car" | "phone" | "band";

/**
 * @desc application type
 */
type ApplicationType = "widget" | "package";

/**
 * @desc return result
 */
declare interface ResData {
  /**
   * @desc whether the application exists
   */
  result: boolean;
}

/**
 * @desc return result
 */
declare interface SignatureDigestsData {
  /**
   * @desc list of signature digest information using SHA-256
   */
  signatureDigests: string[];
}

/**
 * @desc return result
 */
declare interface PackagesData {
  /**
   * @desc The category of the application; see the above application classifications for details
   */
  packages: Packages[];
}

/**
 * @desc preview information
 */
declare interface PreviewImage {
  /**
   * @desc size
   */
  size: string;
  /**
   * @desc image information
   */
  images: string[];
}

/**
 * @desc List of installed application package information
 */
declare interface Packages {
  /**
   *  @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for widget in the manifest, e.g., widgets/widget.
   */
  moduleName: string;

  /**
   *  @desc application name
   */
  name: string;
  /**
   *  @desc application icon path
   */
  icon: string;
  /**
   *  @desc version number
   */
  versionCode: number;
  /**
   *  @desc version name
   */
  versionName: string;
}

/**
 * @desc Input parameter
 */
declare interface PromiseHasInstalledParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc 默认值为 package，package 表示普通应用，widget 表示卡片
   */
  type?: ApplicationType;
}

/**
 * @desc Input parameter
 */
declare interface HasInstalledParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {data} callback function return value {ResData}
   */
  success?: (data: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseInstallParams {
  /**
   * @desc package URI, sandbox directory
   */
  path: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
}

/**
 * @desc Input parameter
 */
declare interface InstallParams {
  /**
   * @desc installation package URI, sandbox directory
   */
  path: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {data} callback function return value {ResData}
   */
  success?: (data: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseUninstallParams {
  /**
   * @desc specify the package name of the application to uninstall
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
}

/**
 * @desc Input parameter
 */
declare interface UninstallParams {
  /**
   * @desc specify the package name of the application to uninstall
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {data} callback function return value {ResData}
   */
  success?: (data: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseGetInfoParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
}

/**
 * @desc Input parameter
 */
declare interface GetInfoParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
  /**
   * @desc success callback
   * @param {data} callback function return value {Packages}
   */
  success?: (data: Packages) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseGetSignatureDigestsParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
}

/**
 * @desc Input parameter
 */
declare interface GetSignatureDigestsParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
  /**
   * @desc success callback
   * @param {data} callback function return value {SignatureDigestsData}
   */
  success?: (data: SignatureDigestsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface GetInstalledPackagesParams {
  /**
   * @desc success callback
   * @param {data} callback function return value {PackagesData}
   */
  success?: (data: PackagesData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface GetInstalledWidgetsParams {
  /**
   * @desc success callback
   * @param {data} callback function return value {Widget}
   */
  success?: (widget: Widget) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseGetAppCategoryAsyncParams {
  /**
   * @desc application package name
   */
  package: string;
}

/**
 * @desc Input parameter
 */
declare interface GetAppCategoryAsyncParams {
  /**
   * @desc application package name
   */
  package: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {string[]}
   */
  success?: (appCategory: string[]) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
