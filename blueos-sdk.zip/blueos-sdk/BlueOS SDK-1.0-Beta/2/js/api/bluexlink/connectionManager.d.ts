/**
 * device communication
 * Interface declaration: {"name": "blueos.bluexlink.connectionManager"}
 */
declare module "@blueos.bluexlink.connectionManager" {
  /**
   * @desc get the connection status between the watch and the phone
   * @param {params} get the connection status between the watch and the phone input parameters {GetPeerDeviceStatusParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getPeerDeviceStatus: (params: GetPeerDeviceStatusParams) => void;

  /**
   * @desc create connection instance
   * @param {params} create connection instance input parameters {InstanceParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Instance}
   */
  const instance: (params: InstanceParams) => Instance;
}

/**
 *  @desc input parameter
 */
declare interface GetPeerDeviceStatusParams {
  /**
   *  @desc success callback
   *  @param {data} return value {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface GetPeerDeviceClientVersionParams {
  /**
   *  @desc success callback
   *  @param {data}  return value {VersionData}
   */
  success?: (data: VersionData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc return value
 */
declare interface Data {
  /**
   *  @desc 0: not connected. 1: connected
   */
  status: number;
}

/**
 *  @desc return value
 */
declare interface VersionData {
  /**
   *  @desc mobile application version number, returns normally if available, -1: not installed
   */
  version: number;
}

/**
 *  @desc input parameter
 */
declare interface InstanceParams {
  /**
   *  @desc mobile app package name
   */
  package: string;
  /**
   *  @desc certificate fingerprint information of the mobile app
   */
  fingerprint: string;
}

/**
 *  @desc input parameter
 */
declare interface SendParams {
  /**
   *  @desc data to be sent
   */
  data: Record<any, any>;

  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface PromiseSendParams {
  /**
   *  @desc data to be sent
   */
  data: Record<any, any>;
}

/**
 *  @desc input parameter
 */
declare interface SendFileParams {
  /**
   *  @desc URI of the directory
   */
  uri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface PromiseSendFileParams {
  /**
   *  @desc directory URI
   */
  uri: string;
}

/**
 *  @desc return value
 */
declare interface MessageParams {
  /**
   * @desc whether it is a file
   */
  isFileType: boolean;
  /**
   * @desc file storage path
   */
  fileUri: string;
  /**
   * @desc file name
   */
  fileName: string;
}

/**
 *  @desc input parameter
 */
declare interface CloseParams {
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface GetReadyStateParams {
  /**
   *  @desc success callback
   *  @param {data} return value {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc return value
 */
declare interface Instance {
  /**
   * @desc get app connection status
   * @param {params}  get app connection status input parameters {GetReadyStateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  getReadyState(params?: GetReadyStateParams): void;

  /**
   * @desc get app connection status
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Data>}
   */
  getReadyState(): Promise<Data>;

  /**
   * @desc query app version status
   * @param {params} query app version status input parameters {GetPeerDeviceClientVersionParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  getPeerDeviceClientVersion(params: GetPeerDeviceClientVersionParams): void;

  /**
   * @desc query app version status
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<VersionData>}
   */
  getPeerDeviceClientVersion(): Promise<VersionData>;

  /**
   * @desc used to specify the callback function when the connection is opened
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onOpen: () => void;

  /**
   * @desc used to specify the callback function when the connection is closed
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onClose: () => void;

  /**
   * @desc used to specify the callback function after the connection fails
   * @param {data} error message {string}
   * @param {code} return status code of the failure callback {number}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onError: (data: string, code: number) => void;

  /**
   * @desc send information
   * @param {params} send information input parameters {SendParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  send(params: SendParams): void;

  /**
   * @desc send information
   * @param {params} send information input parameters {PromiseSendParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  send(params: PromiseSendParams): Promise<void>;

  /**
   * @desc send data to the mobile app end
   * @param {params} input parameters {SendFileParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  sendFile(params: SendFileParams): void;

  /**
   * @desc send data to the mobile app end
   * @param {params} input parameters {PromiseSendFileParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  sendFile(params: PromiseSendFileParams): Promise<void>;

  /**
   * @desc close the current connection
   * @param {params} function input parameters for closing the current connection{CloseParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  close(params?: CloseParams): void;

  /**
   * @desc close the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  close(): Promise<void>;

  /**
   * @desc receive data from the mobile app end.
   * @param {params} function input parameters for closing the current connection {MessageParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onMessage: (params: MessageParams) => void;
}
