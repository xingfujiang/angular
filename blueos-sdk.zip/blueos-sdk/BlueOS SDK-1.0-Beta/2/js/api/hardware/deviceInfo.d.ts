/**
 * Device information
 * Interface declaration: {"name": "blueos.hardware.deviceInfo"}
 */
declare module "@blueos.hardware.deviceInfo" {
  /**
   * @desc Get device information
   * @param {params} Get device information with input parameter {GetInfoParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getInfo: (params?: GetInfoParams) => void;

  /**
   * @desc Get device information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<InfoData>}
   */
  const getInfo: () => Promise<InfoData>;

  /**
   * @desc Batch get device identifiers
   * @param {params} Batch get device identifiers with input parameter {GetIdParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getId: (params: GetIdParams) => void;

  /**
   * @desc Batch get device identifiers
   * @param {params} Batch get device identifiers with input parameter {PromiseGetIdParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<DataValue>}
   */
  const getId: (params: PromiseGetIdParams) => Promise<DataValue>;

  /**
   * @desc Get the device's unique identifier
   * @param {params}  Get the device's unique identifier parameter {GetDeviceIdParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getDeviceId: (params?: GetDeviceIdParams) => void;

  /**
   * @desc Get the device's unique identifier
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<DeviceIdData>}
   */
  const getDeviceId: () => Promise<DeviceIdData>;

  /**
   * @desc Get the user's unique identifier
   * @param {params} Get the user's unique identifier input parameter {GetUserIdParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getUserId: (params?: GetUserIdParams) => void;

  /**
   * @desc Get the user's unique identifier
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<UserIdData>}
   */
  const getUserId: () => Promise<UserIdData>;

  /**
   * @desc Get the total size of the storage space
   * @param {params}  Get the total size of the storage space input parameter {GetTotalStorageParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getTotalStorage: (params?: GetTotalStorageParams) => void;

  /**
   * @desc Get the total size of the storage space
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<TotalStorageData>}
   */
  const getTotalStorage: () => Promise<TotalStorageData>;

  /**
   * @desc Get the available size of the storage space
   * @param {params} Get the available size of the storage space input parameter {GetAvailableStorageParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getAvailableStorage: (params?: GetAvailableStorageParams) => void;

  /**
   * @desc Get the available size of the storage space
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<AvailableStorageData>}
   */
  const getAvailableStorage: () => Promise<AvailableStorageData>;

  /**
   * @desc Get CPU information
   * @param {params} Get CPU information input parameter {GetCpuInfoParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getCpuInfo: (params?: GetCpuInfoParams) => void;

  /**
   * @desc Get CPU information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<CpuInfoData>}
   */
  const getCpuInfo: () => Promise<CpuInfoData>;

  /**
   * @desc Get the device serial number
   * @param {params} Get the device serial number input parameter {GetSerialParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getSerial: (params?: GetSerialParams) => void;

  /**
   * @desc Get the device serial number
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<SerialData>}
   */
  const getSerial: () => Promise<SerialData>;

  /**
   * @desc Get card identification code
   * @param {params}  Get card identification code input parameter {GetDeviceICCIDParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getDeviceICCID: (params?: GetDeviceICCIDParams) => void;

  /**
   * @desc Get card identification code
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<IccidData>}
   */
  const getDeviceICCID: () => Promise<IccidData>;

  /**
   * @desc Determine whether the hardware device capabilities are supported
   * @param {name} Determine hardware device capability support with input parameters, possible values include 'sys.modem.support' and 'sys.sensor.ecg.support'
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {boolean}
   */
  const isSupported: (name: string) => boolean;

  /**
   * @desc Get the complete list of hardware features
   * @param {params}  Get the complete list of hardware features input parameter {GetFeatureListParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getFeatureList: (params?: GetFeatureListParams) => void;

  /**
   * @desc Get the complete list of hardware features
   * @param {params}  Get the complete list of hardware features input parameter {GetFeatureListParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<string>>}
   */
  const getFeatureList: () => Promise<Array<string>>;

  /**
   * @desc Get information about connected devices (such as phones, tablets)
   * @param {params}  Get connected device information input parameter {GetPeerDeviceInfoParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getPeerDeviceInfo: (params?: GetPeerDeviceInfoParams) => void;

  /**
   * @desc Get information about connected devices (such as phones, tablets)
   * @param {params}  Get connected device information input parameter {GetPeerDeviceInfoParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<BrandAndOsType>}
   */
  const getPeerDeviceInfo: () => Promise<BrandAndOsType>;

  /**
   * @desc Synchronously get device information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {InfoData}
   */
  const getInfoSync: () => InfoData;
}

/**
 * 	@desc Input parameter
 */
declare interface GetInfoParams {
  /**
   * @desc Success callback
   * @param {data} Success callback return value {InfoData}
   */
  success?: (data: InfoData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Input parameter
 */
declare interface PromiseGetIdParams {
  /**
   * @desc Supports four types: device, mac, user, and advertising, and can provide one or more of these
   */
  type: string[];
}

/**
 * 	@desc Input parameter
 */
declare interface GetIdParams {
  /**
   * @desc Supports four types: device, mac, user, and advertising, and can provide one or more of these
   */
  type: string[];
  /**
   * 	@desc Success callback
   * 	@param {data} Callback function input parameter {DataValue}
   */
  success?: (data: DataValue) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface DataValue {
  /**
   * @desc Device unique identifier. On Android, it returns IMEI or MEID; after Android Q, it returns aaid (Anonymous Application Device Identifier) for Huawei phones, and for other manufacturers, it returns oaid (Open Anonymous Device Identifier) if supported, otherwise it returns an empty value
   */
  device?: string;
  /**
   * @desc Device's MAC address. On Android M and above, it returns a fixed value: 02:00:00:00:00:00
   */
  mac?: string;
  /**
   * @desc User unique identifier. On Android, it returns the androidid
   */
  user?: string;
  /**
   * @desc Advertising unique identifier
   */
  advertising?: string;
}

/**
 * 	@desc Return value
 */
declare interface InfoData {
  /**
   * @desc Device brand
   */
  brand: string;
  /**
   * @desc Device manufacturer
   */
  manufacturer: string;
  /**
   * @desc Device model
   */
  model: string;
  /**
   * @desc Device codename
   */
  product: string;
  /**
   * @desc Operating system name
   */
  osType: string;
  /**
   * @desc Operating system version name
   */
  osVersionName: string;
  /**
   * @desc Operating system version number
   */
  osVersionCode: number;
  /**
   * @desc Runtime platform version name
   */
  platformVersionName: string;
  /**
   * @desc Runtime platform version number
   */
  platformVersionCode: number;
  /**
   * @desc System language
   */
  language: string;
  /**
   * @desc System region
   */
  region: string;
  /**
   * @desc Hardware version
   */
  hardwareVersion: string;
  /**
   * @desc Software version
   */
  softwareVersion: string;
  /**
   * @desc Screen width
   */
  screenWidth: number;
  /**
   * @desc Screen height
   */
  screenHeight: number;
  /**
   * @desc Usable window width
   */
  windowWidth: number;
  /**
   * @desc Usable window height
   */
  windowHeight: number;
  /**
   * @desc Status bar height
   */
  statusBarHeight: number;
  /**
   * @desc Device screen density
   */
  screenDensity: number;
  /**
   * @desc Name of the phone manufacturer's system
   */
  vendorOsName: string;
  /**
   * @desc Version number of the phone manufacturer's system
   */
  vendorOsVersion: string;
  /**
   * @desc For notched screens (such as a notch, waterdrop, or hole-punch screen), it returns the position and size of the notched area. Each item in the array represents a description of a notched area.
   */
  cutout: any[];
  /**
   * @desc The current device type for the vivo watch engine is 'watch' for the watch version
   */
  deviceType: string;

  /**
   * @desc Get the screen display refresh rate (the frame rate obtained may not be the standard 60, 90, 144, etc.)
   */
  screenRefreshRate: number;
}

/**
 * 	@desc Input parameter
 */
declare interface GetDeviceIdParams {
  /**
   * 	@desc Success callback
   * 	@param {data} Callback function input parameter {DeviceIdData}
   */
  success?: (data: DeviceIdData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface DeviceIdData {
  /**
   * @desc Device unique identifier
   */
  deviceId: string;
}

/**
 * 	@desc Return value
 */
declare interface UserIdData {
  /**
   * Device unique identifier. On Android, it returns the androidid
   */
  userId: string;
}

/**
 * 	@desc Input parameter
 */
declare interface GetUserIdParams {
  /**
   * 	@desc Success callback
   * 	@param {data} Callback function input parameter {UserIdData}
   */
  success?: (data: UserIdData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface TotalStorageData {
  /**
   *  @desc Total size of the storage space, in bytes. On Android, it returns the total size of the external storage
   */
  totalStorage: number;
}

/**
 * 	@desc Input parameter
 */
declare interface GetTotalStorageParams {
  /**
   * @desc Success callback
   * @param {data}  Callback function input parameter {TotalStorageData}
   */
  success?: (data: TotalStorageData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   *  @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface AvailableStorageData {
  /**
   * @desc Available size of the storage space, in bytes. On Android, it returns the available size of the external storage
   */
  availableStorage: number;
}

/**
 * 	@desc Input parameter
 */
declare interface GetAvailableStorageParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {AvailableStorageData}
   */
  success?: (data: AvailableStorageData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface CpuInfoData {
  /**
   * @desc CPU information。
   */
  cpuInfo: string;
}

/**
 * 	@desc Input parameter
 */
declare interface GetCpuInfoParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {CpuInfoData}
   */
  success?: (data: CpuInfoData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface SerialData {
  /**
   * @desc CPU information. On Android, it returns the contents of the /proc/cpuinfo file
   */
  serial: string;
}

/**
 * 	@desc Input parameter
 */
declare interface GetSerialParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {SerialData}
   */
  success?: (data: SerialData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface IccidData {
  /**
   * @desc Card identification code
   */
  iccid: string;
}

/**
 * 	@desc Input parameter
 */
declare interface GetDeviceICCIDParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {IccidData}
   */
  success?: (data: IccidData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Input parameter
 */
declare interface GetFeatureListParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {Array<string>}
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface BrandAndOsType {
  /**
   * @desc Device brand
   */
  brand: string;
  /**
   * @desc Operating system name
   */
  osType: string;
}

/**
 * 	@desc Input parameter
 */
declare interface GetPeerDeviceInfoParams {
  /**
   * @desc Success callback
   * @param {data} Callback function input parameter {BrandAndOsType}
   */
  success?: (data: BrandAndOsType) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
