/**
 * Vibration
 * Interface declaration: {"name": "blueos.hardware.vibrator.vibrator"}
 */
declare module "@blueos.hardware.vibrator.vibrator" {
  /**
   * @desc Trigger vibration
   * @param {params} Trigger vibration with input parameter {VibrateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const vibrate: (params: VibrateParams) => void;

  /**
   * @desc Start vibration
   * @param {params} Start vibration with input parameter {StartParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const start: (params: StartParams) => void;

  /**
   * @desc Start vibration
   * @param {params} Start vibration with input parameter {PromiseStartParams}.
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<IdData>}
   */
  const start: (params: PromiseStartParams) => Promise<IdData>;

  /**
   * @desc Stop vibration
   * @param {key} Stop vibration with input parameter {number}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {boolean}
   */
  const stop: (key: number) => boolean;

  /**
   * @desc Get the system default vibration pattern
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getSystemDefaultMode: () => number;
}

/**
 * @desc Input parameter
 */
declare interface VibrateParams {
  /**
   * @desc Vibration pattern, where "long" indicates a long vibration and "short" indicates a short vibration. The default is long
   */
  mode?: string;
}

/**
 * @desc Input parameter
 */
declare interface StartParams {
  /**
   * @desc Vibration priority ranges from 0 to 8, with lower numbers indicating higher priority
   */
  priority: number;
  /**
   * @desc Vibration duration (in milliseconds)
   */
  duration: number;
  /**
   * @desc Vibration interval time (in milliseconds)
   */
  interval: number;
  /**
   * @desc Number of vibrations
   */
  count: number;
  /**
   * @desc Success callback
   * @param {data} Return value of the success callback {IdData}
   */
  success?: (data: IdData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseStartParams {
  /**
   * @desc Vibration priority ranges from 0 to 8, with smaller numbers representing higher priority
   */
  priority: number;
  /**
   * @desc Vibration duration (in ms)
   */
  duration: number;
  /**
   * @desc Vibration interval time (in ms)
   */
  interval: number;
  /**
   * @desc Number of vibrations
   */
  count: number;
}

/**
 * @desc Return value
 */
declare interface IdData {
  /**
   * @desc The underlying system assigns a unique ID and returns it to the caller
   */
  id: number;
}
