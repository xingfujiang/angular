/**
 * This module is used for input method response to external physical keyboard input
 * Interface declaration: {"name": "blueos.hardware.keyboard"}
 */
declare module "@blueos.hardware.keyboard" {
  /**
   * @desc Key press event callback
   * @param {keyEvent} Parameter {KeyEvent}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onKeyDown: (keyEvent: KeyEvent) => void;

  /**
   * @desc Key release event callback
   * @param {keyEvent} Parameter {KeyEvent}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onKeyUp: (keyEvent: KeyEvent) => void;
}

/**
 * @desc Event parameters
 */
declare interface KeyEvent {
  /**
   * @desc Keycode
   */
  KeyCode: number;

  /**
   * @desc  Event timestamp, in milliseconds (ms)
   */
  eventTime: number;

  /**
   * @desc Device ID
   */
  deviceId: number;

  /**
   * @desc Set of simultaneously pressed keys
   */
  keys: any;

  /**
   * @desc Returns true if the key is being held down; otherwise, returns false
   */
  repeat: boolean;

  /**
   * @desc Whether the Alt key was pressed when the event occurred
   */
  isAltPressed: boolean;

  /**
   * @desc Whether the Shift key was pressed when the event occurred
   */
  isShiftPressed: boolean;

  /**
   * @desc Whether the Ctrl key was pressed when the event occurred
   */
  isCtrlPressed: boolean;

  /**
   * @desc Whether the Fn key was pressed when the event occurred
   */
  isFnPressed: boolean;

  /**
   * @desc Returns the pressed state of the Meta key, such as the Windows key or the Command key on a Mac
   */
  isMetaPressed: boolean;

  /**
   * @desc Lock state of the NumLock key
   */
  isNumLockOn: boolean;

  /**
   * @desc Lock state of the ScrollLock key
   */
  isScrollLockOn: boolean;

  /**
   * @desc Lock state of the CapsLock key
   */
  isCapsLockOn: boolean;
}
