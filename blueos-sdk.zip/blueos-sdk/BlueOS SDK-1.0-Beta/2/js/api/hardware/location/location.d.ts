/**
 * Geolocation
 * Interface declaration: {"name": "blueos.hardware.location.location"}
 */
declare module "@blueos.hardware.location.location" {
  /**
   * @desc Get geolocation
   * @param {params} Get geolocation with input parameter {GetLocationParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getLocation: (params: GetLocationParams) => void;

  /**
   * @desc Get geolocation
   * @param {params} Get geolocation with input parameter {PromiseGetLocationParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data>}
   */
  const getLocation: (params: PromiseGetLocationParams) => Promise<Data>;

  /**
   * @desc Listen for geolocation changes. If called multiple times, only the last call takes effect
   * @param {params} Listen for geolocation with input parameter {SubscribeDataParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (params: SubscribeDataParams) => void;

  /**
   * @desc Unsubscribe from geolocation updates
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Get supported coordinate system types
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {string[]}
   */
  const getSupportedCoordTypes: () => string[];
}

/**
 * @desc Input parameter
 */
declare interface GetLocationParams {
  /**
   * @desc Set the timeout period in milliseconds (ms), with a default value of 30000. If the system denies permissions or if the location settings are incorrect, a result may never be returned, so a timeout is necessary. The fail callback will be used after the timeout.
   */
  timeout?: number;
  /**
   * @desc Coordinate system type, with optional values available through getSupportedCoordTypes, defaults to wgs84
   */
  coorType?: string;
  /**
   * @desc Success callback
   * @param {data} Return value of the success callback {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;

  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Longitude
   */
  longitude: number;
  /**
   * @desc Latitude
   */
  latitude: number;
  /**
   * @desc Accuracy
   */
  accuracy: number;
  /**
   * @desc Time
   */
  time: number;
}

/**
 * @desc Input parameter
 */
declare interface PromiseGetLocationParams {
  /**
   * @desc Set the timeout period in milliseconds (ms), with a default value of 30000. If permissions are denied by the system or if location settings are incorrect, a result may never be returned, hence setting a timeout is necessary. If a timeout occurs, the fail callback will be used
   */
  timeout?: number;
  /**
   * @desc Coordinate system type, optional values can be obtained through getSupportedCoordTypes, default is wgs84
   */
  coorType?: string;
}

/**
 * @desc Input parameter
 */
declare interface SubscribeDataParams {
  /**
   * @desc Whether to persist the subscription, default is false. Mechanism: If set to true, navigation between pages will not automatically cancel the subscription; it must be manually unsubscribed
   */
  reserved?: boolean;
  /**
   * @desc Coordinate system type, optional values can be obtained via getSupportedCoordTypes, default is wgs84
   */
  coorType?: string;
  /**
   * @desc The callback is triggered each time the location information changes
   * @param {data} Listen for geolocation with input parameter {Data}
   */
  callback: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
