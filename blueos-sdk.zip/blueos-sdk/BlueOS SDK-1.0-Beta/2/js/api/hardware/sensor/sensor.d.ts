/**
 * Sensor
 * Interface declaration: {"name": "blueos.hardware.sensor.sensor"}
 */
declare module "@blueos.hardware.sensor.sensor" {
  /**
   * @desc Listen for gravity sensor data. If called multiple times, only the last call takes effect
   * @param {params} Listen for gravity sensor data with input parameter {SubscribeAccelerometerParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeAccelerometer: (params: SubscribeAccelerometerParams) => void;

  /**
   * @desc Unsubscribe from gravity sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeAccelerometer: () => void;

  /**
   * @desc Listen for compass data. If called multiple times, only the last call takes effect
   * @param {params} Listen for compass data with input parameter {SubscribeCompassParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeCompass: (params: SubscribeCompassParams) => void;

  /**
   * @desc Unsubscribe from compass data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeCompass: () => void;

  /**
   * @desc Listen for pedometer sensor data. If called multiple times, only the last call takes effect
   * @param {params} Listen for pedometer sensor data with input parameter {SubscribeStepCounterParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeStepCounter: (params: SubscribeStepCounterparams) => void;

  /**
   * @desc Unsubscribe from pedometer sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeStepCounter: () => void;

  /**
   * @desc Listen for device wear status sensor data. If called multiple times, only the last call takes effect
   * @param {params} Listen for device wear status sensor data with input parameter {SubscribeOnBodyStateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeOnBodyState: (params: SubscribeOnBodyStateParams) => void;

  /**
   * @desc Unsubscribe from pedometer sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeOnBodyState: () => void;

  /**
   * @desc Get device wear status
   * @param {params} Get device wear status with input parameter {GetOnBodyStateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getOnBodyState: (params?: GetOnBodyStateParams) => void;

  /**
   * @desc Get device wear status
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<DataValue>}
   */
  const getOnBodyState: () => Promise<DataValue>;

  /**
   * @desc Listen for gyroscope sensor data. If called multiple times, only the last call takes effect
   * @param {params} Listen for gyroscope sensor data with input parameter {SubscribeGyroscopeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeGyroscope: (params: SubscribeGyroscopeParams) => void;

  /**
   * @desc Unsubscribe from gyroscope data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeGyroscope: () => void;

  /**
   * @desc Listen for barometric sensor data. If called multiple times, only the last call takes effect
   * @param {params} Listen for barometric sensor data with input parameter {SubscribeBarometerParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeBarometer: (params: SubscribeBarometerParams) => void;

  /**
   * @desc Unsubscribe from pressure sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeBarometer: () => void;

  /**
   * @desc Listen for wrist raise. If called multiple times, only the last call takes effect
   * @param {params} Listen for wrist raise with input parameter {SubscribeWristLiftParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeWristLift: (params: SubscribeWristLiftParams) => void;

  /**
   * @desc Unsubscribe from wrist raise detection
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeWristLift: () => void;

  /**
   * @desc Listen for continuous wrist rotation. If called multiple times, only the last call takes effect
   * @param {params} Listen for continuous wrist rotation with input parameter {SubscribeContinuousWristTurnParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeContinuousWristTurn: (
    params: SubscribeContinuousWristTurnParams
  ) => void;

  /**
   * @desc Unsubscribe from wrist raise detection
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeContinuousWristTurn: () => void;

  /**
   * @desc Subscribe to proximity sensor user presence status
   * @param {params} Input parameter {SubscribeProximityStateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const subscribeProximityState: (
    params: SubscribeProximityStateParams
  ) => number;

  /**
   * @desc Unsubscribe from the proximity sensor user presence status
   * @param {subscribeId} Input parameter {number}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeProximityState: (subscribeId: number) => void;

  /**
   * @desc Subscribe to light sensor data
   * @param {params} Input parameter {SubscribeLightParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const subscribeLight: (params: SubscribeLightParams) => number;

  /**
   * @desc Unsubscribe from light sensor data.
   * @param {subscribeId} Input parameter {number}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeLight: (subscribeId: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeProximityStateParams {
  /**
   * @desc Listen for callback
   * @param {data} Return value {IsCloseData}
   */
  callback: (data: IsCloseData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface IsCloseData {
  /**
   *  @desc Is the proximity sensor near the user
   */
  isClose: boolean;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeContinuousWristTurnParams {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  callback: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeAccelerometerParams {
  /**
   * @desc This function is called back after changes in gravity sensor data are detected
   * @param {ret} Callback function return value {RetData}
   */
  callback: (ret: RetData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface RetData {
  /**
   * @desc x Axis coordinates
   */
  x: number;
  /**
   * @desc y Axis coordinates
   */
  y: number;
  /**
   * @desc z Axis coordinates
   */
  z: number;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeCompassParams {
  /**
   * @desc This function is called back after changes in compass data are detected
   * @param {ret} Callback function return value {ResData}
   */
  callback: (ret: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface ResData {
  /**
   * @desc ndicates the angle between the device's Y-axis and the magnetic north pole. When facing north, the angle is 0; facing south, the angle is π; facing east, the angle is π/2; and facing west, the angle is -π/2.
   */
  direction: number;
  /**
   * @desc Accuracy
   */
  accuracy: number;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeStepCounterparams {
  /**
   *  @desc This function is called back after changes in pedometer sensor data are detected
   *  @param {ret} Callback function return value {StepsData}
   */
  callback: (ret: StepsData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface StepsData {
  /**
   * @desc The pedometer sensor records the current cumulative number of steps. This value resets to 0 each time the phone restarts
   */
  steps: number;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeOnBodyStateParams {
  /**
   *  @desc This function is called back after changes in device wear status sensor data are detected
   *  @param {ret} Callback function return value {RetValue}
   */
  callback: (ret: RetValue) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface RetValue {
  /**
   * @desc Is it worn
   */
  value: number;
}

/**
 *  @desc Input parameter
 */
declare interface GetOnBodyStateParams {
  /**
   * @desc Success callback
   * @param {data} Return value of the success callback {DataValue}
   */
  success?: (data: DataValue) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc Return value
 */
declare interface DataValue {
  /**
   * @desc Is it worn
   */
  value: boolean;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeGyroscopeParams {
  /**
   * @desc This function is called back after changes in gyroscope sensor data are detected
   * @param {ret} Callback function return value {RetData}
   */
  callback: (ret: RetData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface PressureData {
  /**
   * @desc Pressure value, unit: pascal
   */
  pressure: number;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeBarometerParams {
  /**
   *  @desc This function is called back after changes in the device wear status sensor data are detected
   *  @param {ret} Callback function return value {PressureData}
   */
  callback: (ret: PressureData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface SubscribeWristLiftParams {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  callback: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

declare interface SubscribeLightParams {
  /**
   * @desc Callback function
   * @param {data} Return value {IntensityData}
   */
  callback: (data: IntensityData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface IntensityData {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  intensity: number;
}
