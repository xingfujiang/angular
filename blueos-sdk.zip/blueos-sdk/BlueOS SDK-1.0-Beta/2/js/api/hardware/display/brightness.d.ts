/**
 * Screen brightness
 * Interface declaration: {"name": "blueos.hardware.display.brightness"}
 */
declare module "@blueos.hardware.display.brightness" {
  /**
   * @desc Obtain the current screen brightness value
   * @param {params} Obtain the current screen brightness value with input parameter {GetValueParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getValue: (params?: GetValueParams) => void;

  /**
   * @desc Obtain the current screen brightness value
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data>}
   */
  const getValue: () => Promise<Data>;

  /**
   * @desc Get the current screen brightness value
   * @param {params} Set the current screen brightness value with input parameter {SetValueParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setValue: (params: SetValueParams) => void;

  /**
   * @desc Get the current screen brightness value
   * @param {params} Set the current screen brightness value with input parameter {SetValueParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setValue: (params: PromiseSetValueParams) => Promise<void>;

  /**
   * @desc Obtain the current screen brightness mode
   * @param {params} Obtain the current screen brightness mode with input parameter {GetModeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getMode: (params?: GetModeParams) => void;

  /**
   * @desc Obtain the current screen brightness mode
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data>}
   */
  const getMode: () => Promise<Data>;

  /**
   * @desc Set the current screen brightness mode
   * @param {params} Obtain the current screen brightness mode with input parameter {SetModeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setMode: (params: SetModeParams) => void;

  /**
   * @desc Set the current screen brightness mode
   * @param {params} Obtain the current screen brightness mode with input parameter {SetModeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const setMode: (params: PromiseSetModeParams) => Promise<void>;

  /**
   * @desc Turn the screen on or off
   * @param {params} Turn the screen on or off with input parameter {SetKeepScreenOnParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setKeepScreenOn: (params: SetKeepScreenOnParams) => void;

  /**
   * @desc Turn the screen on or off
   * @param {params} Turn the screen on or off with input parameter {PromiseSetKeepScreenOnParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const setKeepScreenOn: (
    params: PromiseSetKeepScreenOnParams
  ) => Promise<void>;

  /**
   * @desc Listen for the current screen brightness data. If called multiple times, only the last call takes effect
   * @param {params} Listen for the current screen brightness data with input parameter {SubscribeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (params: SubscribeParam) => void;

  /**
   * @desc Unsubscribe from screen brightness data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Synchronously obtain the current screen brightness value
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {number}
   */
  const getValueSync: () => number;

  /**
   * @desc Turn the screen on or off
   * @param {params} Turn the screen on or off with input parameter {WakeScreenOnParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const wakeScreenOn: (params: WakeScreenOnParams) => void;

  /**
   * @desc Turn the screen on or off
   * @param {params} Turn the screen on or off with input parameter {PromiseWakeScreenOnParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const wakeScreenOn: (params: PromiseWakeScreenOnParams) => Promise<void>;
}

/**
 * @desc Input parameter
 */
declare interface GetValueParams {
  /**
   * @desc Success callback
   * @param {data} Return value {Data}
   */
  success?: (data: Data) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Screen brightness, range 0-255
   */
  value: number;
}

/**
 * @desc Input parameter
 */
declare interface SetValueParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  value: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSetValueParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  value: number;
}

/**
 * @desc Input parameter
 */
declare interface GetModeParams {
  /**
   * @desc Success callback
   * @param {data} Callback return value {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc  0 for manual screen brightness adjustment, 1 for automatic screen brightness adjustment
   */
  mode: number;
}

/**
 * @desc Input parameter
 */
declare interface SetModeParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  mode: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSetModeParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  mode: number;
}

/**
 * @desc Input parameter
 */
declare interface SetKeepScreenOnParams {
  /**
   * @desc Keep the screen always on
   */
  screenOn: boolean;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSetKeepScreenOnParams {
  /**
   * @desc Keep the screen always on
   */
  screenOn: boolean;
}

/**
 * @desc Input parameter
 */
declare interface SubscribeParam {
  /**
   * @desc Callback function
   * @param {data} Return value {ValueData}
   */
  callback: (data: ValueData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface ValueData {
  /**
   * @desc Screen brightness, range 0–255
   */
  value: number;
}

/**
 * @desc Input parameter
 */
declare interface WakeScreenOnParams {
  /**
   * @desc Is it on
   */
  screenOn: boolean;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseWakeScreenOnParams {
  /**
   * @desc  Is it on
   */
  screenOn: boolean;
}
