/**
 * Power information" or "Battery information
 * Interface declaration: {"name": "blueos.hardware.battery.battery"}
 */
declare module "@blueos.hardware.battery.battery" {
  /**
   * @desc Retrieve the current device's battery information
   * @param {params} Retrieve the current device's battery information with input parameter {GetStatusParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getStatus: (params: GetStatusParams) => void;

  /**
   * @desc Retrieve the current device's battery information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data>}
   */
  const getStatus: () => Promise<Data>;

  /**
   * @desc Synchronously retrieve the current device's battery information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {Data}
   */
  const getStatusSync: () => Data;
}

/**
 * @desc Input parameter
 */
declare interface GetStatusParams {
  /**
   * @desc Success callback
   * @param {data} Return value of the callback {object}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Is it charging
   */
  charging: boolean;
  /**
   * @desc Current battery level, between 0.0 and 1.0
   */
  level: number;
}
