/**
 * get device information
 * Interface declaration: {"name": "blueos.app.context"}
 */
declare module "@blueos.app.context" {
  /**
   * @desc get current application information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {InfoParams}
   */
  const getInfo: () => InfoParams;

  /**
   * @desc Load static library, requires cooperation with the vendor
   * @param {name} static library name {string}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {LoadLibraryData}
   */
  const loadLibrary: (name: string) => LoadLibraryData;

  /**
   * @desc exit the current application
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const terminate: () => void;
}

/**
 * @desc input parameter
 */
declare interface InfoParams {
  /**
   * @desc application package name
   */
  packageName: string;
  /**
   * @desc application icon path
   */
  icon: string;
  /**
   * @desc application name
   */
  name: string;
  /**
   * @desc application version name
   */
  versionName: string;
  /**
   * @desc application version number
   */
  versionCode: number;
}

/**
 * @desc return value
 */
declare interface LoadLibraryData {
  /**
   * @desc listener callback function
   * @param {js_task_callback} callback function name {Function}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  on: (js_task_callback: () => void) => void;
}
