/**
 * application configuration
 * Interface declaration: {"name": "blueos.app.configuration"}
 */
declare module "@blueos.app.configuration" {
  /**
   * @desc Get the current locale of the application. By default, it uses the system locale, which may change based on settings or system locale changes
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {LocaleParams}
   */
  const getLocale: () => LocaleParams;

  /**
   * @desc Set the application's locale. After the setting is completed, the application will update the page according to the new locale and invoke the onConfigurationChanged lifecycle callback. When the system language changes or the application is reopened, the current locale will be reset to the system language
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} set locale information {LocaleParams}
   */
  const setLocale: (params: LocaleParams) => void;
}

/**
 * @desc input parameter
 */
declare interface LocaleParams {
  /**
   * @desc language
   */
  language: string;

  /**
   * @desc country or region
   */
  countryOrRegion: string;
}
