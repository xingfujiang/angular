/**
 * Page stack management.
 * Interface declaration: {"name": "blueos.app.appmanager.pageStack"}
 */
declare module "@blueos.app.appmanager.pageStack" {
  /**
   *  @desc  Get page stack information.
   *  @param  {params} Input parameters for getting page stack information {AppStacksParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const getAppStacks: (params: AppStacksParams) => void;

  /**
   *  @desc  Get page stack information.
   *  @param  {params} Input parameters for getting page stack information {AppStacksParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<Array<AppStackPages>>}
   */
  const getAppStacks: (
    params: PromiseAppStacksParams
  ) => Promise<Array<AppStackPages>>;

  /**
   *  @desc  Close page
   *  @param  {params} Input parameters for closing page {CloseParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const close: (params: CloseParams) => void;

  /**
   *  @desc  Close page
   *  @param  {params} Input parameters for closing page {PromiseCloseParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   * @returns  {Promise<void>}
   */
  const close: (params: PromiseCloseParams) => Promise<void>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseCloseParams {
  /**
   * @desc Close application configuration item
   */
  pageList: Array<PageList>;
}

/**
 * @desc Application configuration item
 */
declare interface PageList {
  /**
   * @desc Application package name
   */
  package: string;
  /**
   * @desc Page ID
   */
  pageIds: Array<string>;
  /**
   * @desc Page path
   */
  paths: Array<string>;
}

/**
 * @desc Input parameter
 */
declare interface CloseParams {
  /**
   * @desc Close application configuration item
   */
  pageList: Array<PageList>;

  /**
   *  @desc Successful callback
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  success?: () => void;

  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
      @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc Callback after execution completion
   * @devices (phone,watch)
   * @apiLevel 2
   */
  complete?: () => void;
}

/**
 * @desc Application information
 */
declare interface AppInfo {
  /**
   * @desc Hierarchy of the associated application
   */
  zIndex: number;
  /**
   * @desc Application package name
   */
  package: string;
}

/**
 * @desc Application page stack information
 */
declare interface Pages {
  /**
   * @desc Page ID
   */
  pageId: number;
  /**
   * @desc Page path
   */
  path: string;
}

/**
 * @desc Return value
 */
declare interface AppStackPages {
  /**
   * @desc Application information
   */
  appInfo: AppInfo;
  /**
   * @desc Application page stack information
   */
  pages: Array<Pages>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseAppStacksParams {
  /**
   *   @desc Application package name. By default, it retrieves page stack information for all applications, or can be specified as ['com.vivo.app1', 'com.vivo.app2'] or 'com.vivo.app1'.
   */
  package: Array<string> | string;
}

/**
 * @desc Input parameter
 */
declare interface AppStacksParams {
  /**
   *   @desc Application package name. By default, it retrieves page stack information for all applications, or can be specified as ['com.vivo.app1', 'com.vivo.app2'] or 'com.vivo.app1'.
   */
  package: Array<string> | string;
  /**
   *   @desc Successful callback
   *   @param {appStackPages} Return value of the successful callback {Array<AppStackPages>}
   *   @devices (phone,watch)
   *   @apiLevel 2
   */
  success?: (appStackPages: Array<AppStackPages>) => void;

  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
  /**
   *  @desc Callback after execution completion
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  complete?: () => void;
}
