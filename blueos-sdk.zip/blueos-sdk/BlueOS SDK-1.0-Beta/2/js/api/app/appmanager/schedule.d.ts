/**
 * scheduled task
 * Interface declaration: {"name": "blueos.app.appmanager.schedule"}
 */
declare module "@blueos.app.appmanager.schedule" {
  /**
   * @desc set scheduled task
   * @param {params} Set scheduled task input parameters {ScheduleJobParams}.
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const scheduleJob: (params: ScheduleJobParams) => void;

  /**
   * @desc Set scheduled task
   * @param {params} Set scheduled task input parameters {PromiseScheduleJobParams}.
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<Data>>}
   */
  const scheduleJob: (params: PromiseScheduleJobParams) => Promise<Array<Data>>;

  /**
   * @desc Cancel scheduled task
   * @param {id} Cancel scheduled task input parameter {number}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {boolean}
   */
  const cancel: (id: number) => boolean;
}

/**
 *  @desc return value
 */
declare interface Data {
  /**
   *  @desc uniquely allocated ID by the underlying system
   */
  id: number;
}

/**
 *  @desc  input parameter
 */
declare interface PromiseScheduleJobParams {
  /**
   *  @desc  Hardware time and real elapsed time: the former can trigger the triggerMethod by modifying the system time, whereas the latter relies on the actual passage of time. Even in sleep mode, time is still accounted for
   */
  type: number;
  /**
   *  @desc If type is 1, it represents the timestamp of the first execution time, which is the number of milliseconds from 1970/01/01 00:00:00 GMT to the current time. If type is 2, it represents the interval from the current time to the first execution time in milliseconds
   */
  timeout: number;
  /**
   *  @desc The method name defined in app.ux, which is called when initiated by the background
   */
  triggerMethod: string;
  /**
   *  @desc The interval for periodic execution, in milliseconds. If not specified, it will not execute repeatedly
   */
  interval: number;
  /**
   *  @desc task parameters
   */
  params: Record<any, any>;
}

/**
 *  @desc  input parameter
 */
declare interface ScheduleJobParams {
  /**
   *  @desc  Hardware time and real elapsed time: the former can trigger the triggerMethod by modifying the system time, whereas the latter relies on the actual passage of time. Even in sleep mode, time is still accounted for
   */
  type: number;
  /**
   *  @desc If type is 1, it represents the timestamp of the first execution time, which is the number of milliseconds from 1970/01/01 00:00:00 GMT to the current time. If type is 2, it represents the interval from the current time to the first execution time in milliseconds
   */
  timeout: number;
  /**
   *  @desc The method name defined in app.ux, which is called when initiated by the background
   */
  triggerMethod: string;
  /**
   *  @desc The interval for periodic execution, in milliseconds. If not specified, it will not execute repeatedly
   */
  interval: number;
  /**
   *  @desc task parameters
   */
  params: Record<any, any>;
  /**
   *  @desc success callback
   *  @param {data} return value {Data}
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
