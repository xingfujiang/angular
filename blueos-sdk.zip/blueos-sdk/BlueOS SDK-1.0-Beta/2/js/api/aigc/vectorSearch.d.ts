/**
 * ai
 * Interface declaration: {"name": "blueos.ai.vectorSearch"}
 */
declare module "@blueos.ai.vectorSearch" {
  /**
   * @desc Generate a corresponding vector from the input content.
   * @param {params} Successful return value {EmbeddingParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const textEmbedding: (params: EmbeddingParams) => void;

  /**
   * @desc Generate a corresponding vector from the input content.
   * @param {params} Successful return value {PromiseEmbeddingParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<EmbeddingObject>}
   */
  const textEmbedding: (
    params: PromiseEmbeddingParams
  ) => Promise<EmbeddingObject>;

  /**
   * @desc Generate a corresponding vector from the input image
   * @param {params} Successful return value {EmbeddingParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const imageEmbedding: (params: EmbeddingParams) => void;

  /**
   * @desc Generate a corresponding vector from the input image
   * @param {params} Successful return value {EmbeddingParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<EmbeddingObject>}
   */
  const imageEmbedding: (
    params: PromiseEmbeddingParams
  ) => Promise<EmbeddingObject>;

  /**
   * @desc object
   */
  const vectorDB: {
    /**
     * @desc Create an index; if the index already exists, directly return the index object instance
     * @param {params} Input parameter {CreateParams}
     * @devices (phone,watch)
     * @apiLevel 2
     * @returns {VectorIndex}
     */
    createIndex: (params: CreateParams) => VectorIndex;
  };
}

/**
 * @desc Input parameter
 */
declare interface PromiseEmbeddingParams {
  /**
   * @desc Input text
   */
  input: any;
  /**
   * @desc Model used
   */
  model?: string;
  /**
   * @desc Dimension of the vector
   */
  dimension?: number;
}

/**
 * @desc Input parameter
 */
declare interface PromiseVectorParams {
  /**
   * @desc Vector list
   */
  vectorList: Array<Embedding>;
  /**
   * @desc Vector ID, when the index uses non-auto-increment IDs
   */
  ids?: Array<number>;
  /**
   * @desc Meta is used to store additional information beyond the vector itself
   */
  metaList?: Array<Meta>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSearchParams {
  /**
   * @desc Vector
   */
  vector: Embedding;
  /**
   * @desc Top K closest search results
   */
  topK?: number;
  /**
   * @desc Search minimum threshold; only results above this threshold will be returned
   */
  thresholdScore?: number;

  /**
   * @desc An array of fixed length 4, used to indicate whether to return the Meta data information at the corresponding index positions. If a value at a certain index position in the array is true, then the Meta data information corresponding to that index will be returned
   */
  IncludeMeta?: boolean[];
}

/**
 * @desc Input parameter
 */
declare interface PromiseByIdsParams {
  /**
   * @desc Vector ID set
   */
  ids: number[];
}

/**
 * @desc Input parameter
 */
declare interface PromiseByMetaParams {
  /**
   * @desc Represents the index position of the Meta information in the database
   */
  index: number;

  /**
   * @desc It's an array containing meta information to be matched, with a variable length. When any meta value in the metas matches the meta value at the database index position, the corresponding data will be deleted.
   */
  metas: Array<number>;
}

/**
 * @desc object
 */
declare interface VectorIndex {
  /**
   * @desc Obtain index object
   * @param {params} Input parameter {VectorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  insert(params: VectorParams): void;

  /**
   * @desc Obtain index object
   * @param {params} Input parameter {PromiseVectorParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  insert(params: PromiseVectorParams): Promise<number>;

  /**
   * @desc Get index object
   * @param {params} Input parameter {SearchParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  search(params: SearchParams): void;

  /**
   * @desc Get index object
   * @param {params} Input parameter {PromiseSearchParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Array<SearchResult>>}
   */
  search(params: PromiseSearchParams): Promise<Array<SearchResult>>;

  /**
   * @desc Delete vector data corresponding to the ID list
   * @param {params} Input parameter {ByIdsParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteByIds(params: ByIdsParams): void;

  /**
   * @desc Delete vector data corresponding to the ID list
   * @param {params} Input parameter {PromiseByIdsParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  deleteByIds(params: PromiseByIdsParams): Promise<number>;

  /**
   * @desc Delete vector data based on matching meta information
   * @param {params} Input parameter {ByMetaParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteByMeta(params: ByMetaParams): void;

  /**
   * @desc Delete vector data based on matching meta information
   * @param {params} Input parameter {PromiseByMetaParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  deleteByMeta(params: PromiseByMetaParams): Promise<number>;

  /**
   * @desc Delete all data under this index
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteAll: () => void;

  /**
   * @desc  Get the data volume of this index
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  size: () => number;

  /**
   * @desc  Release index instance object
   * @devices (phone,watch)
   * @apiLevel 2
   */
  release: () => void;
}

/**
 * @desc Input parameter
 */
declare interface ByMetaParams {
  /**
   * @desc Represents the index position of the Meta information in the database
   */
  index: number;

  /**
   * @desc It's an array containing meta information to be matched, with a variable length. When any meta value in the metas matches the meta value at the database index position, the corresponding data will be deleted.
   */
  metas: Array<number>;

  /**
   * @desc Successful callback, returns the number of deleted entries. If it is 0 or a negative number, it indicates that the deletion failed
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {count} Successful return value {number}
   */
  success?: (count: number) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface ByIdsParams {
  /**
   * @desc Vector ID set
   */
  ids: number[];
  /**
   * @desc Successful callback, returning the number of entries deleted. If it is 0 or a negative number, it indicates that the deletion failed.
   * @param {count} Successful return value {number}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (count: number) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface SearchParams {
  /**
   * @desc Vector
   */
  vector: Embedding;
  /**
   * @desc Top K closest search results
   */
  topK?: number;
  /**
   * @desc Search minimum threshold; only results above this threshold will be returned
   */
  thresholdScore?: number;

  /**
   * @desc An array of fixed length 4, used to indicate whether to return the Meta data information at the corresponding index positions. If a value at a certain index position in the array is true, then the Meta data information corresponding to that index will be returned
   */
  IncludeMeta?: boolean[];

  /**
   * @desc Successful callback
   * @param {result} Successful return value {Array<SearchResult>}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (result: Array<SearchResult>) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface SearchResult {
  /**
   * @desc Vector ID.
   */
  id: number;
  /**
   * @desc Represents the degree of match; the higher the value, the closer the match
   */
  score: number;
  /**
   * @desc Return the corresponding field values based on the input IncludeMeta. The maximum length of the returned array is 4
   */
  meta: Array<number>;
}

/**
 * @desc Input parameter
 */
declare interface VectorParams {
  /**
   * @desc Vector list
   */
  vectorList: Array<Embedding>;
  /**
   * @desc Vector ID, when the index uses non-auto-increment IDs
   */
  ids?: Array<number>;
  /**
   * @desc Meta is used to store additional information beyond the vector itself
   */
  metaList?: Array<Meta>;

  /**
   * @desc Successful callback
   * @param {count} Successful return value {number}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (count: number) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Vector list
 */
type Embedding = Array<number>;

/**
 * @desc Meta is used to store additional information beyond the vector itself
 */
type Meta = Array<number>;

/**
 * @desc Input parameter
 */
declare interface CreateParams {
  /**
   * @desc Index name
   */
  name: string;
  /**
   * @desc Whether to enable auto-increment ID.
   */
  autoId?: boolean;
  /**
   * @desc Vector dimensions
   */
  dimension?: number;
  /**
   * @desc Algorithm used for similarity search. Default value: dotproduct (inner product similarity)
   */
  metric?: string;
}

/**
 * @desc Input parameter
 */
declare interface EmbeddingParams {
  /**
   * @desc Input text
   */
  input: any;
  /**
   * @desc Model used
   */
  model?: string;
  /**
   * @desc Dimensions of the vector
   */
  dimension?: number;
  /**
   * @desc Successful callback
   * @param {data} Successful return value {EmbeddingObject}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (data: EmbeddingObject) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data} Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
      @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface EmbeddingObject {
  /**
   * @desc The output is an array composed of EmbeddingData, with each element in the array containing the algorithm's output for a corresponding input
   */
  embeddings: Array<EmbeddingData>;
  /**
   * @desc Model used
   */
  model: string;
}

/**
 * @desc Each array contains the algorithm's output content corresponding to an input.
 */
declare interface EmbeddingData {
  /**
   * @desc The vectorized output result value of the input
   */
  embedding: Array<number>;
  /**
   * @desc Index of the corresponding input in the array
   */
  index: number;
}
