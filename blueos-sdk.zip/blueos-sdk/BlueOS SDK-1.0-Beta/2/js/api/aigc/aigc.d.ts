/**
 * aigc
 * Interface Declaration: {"name": "blueos.ai.aigc"}
 */
declare module "@blueos.ai.aigc" {
  /**
   * @desc AI drawing can generate high-quality images in various styles and sizes, such as colorful comics, game character CGs, anime, and cyberpunk, through either text description (text-to-image) or using a reference image (image-to-image).
   */
  const painterFactory: {
    /**
     * @desc Create a painter instance.
     * @param {params} Input parameter {createParams}
     * @apiLevel 2
     * @devices (phone,watch)
     * @returns {Painter}
     */
    create: (params: createParams) => Painter;
  };
}

/**
 * @desc Input parameter
 */
declare interface createParams {
  /**
   * @desc Request a service code by contacting the administrator through the Vivo Developer Platform for configuration.
   */
  businessCode: string;
  /**
   * @desc 	Unique user identifiers such as vaid, openid, etc.
   */
  userAccount: string;
  /**
   * @desc Request authentication information to ensure the legitimacy of the request source
   */
  auth: Auth;
}

/**
 * @desc Request authentication information to ensure the legitimacy of the request source.
 */
declare interface Auth {
  /**
   * @desc Application appId.
   */
  appId: string;
  /**
   * @desc Application appKey
   */
  appKey: string;
}

/**
 * @desc Input parameter
 */
declare interface PromisePaintParams {
  /**
   * @desc Drawing configuration parameters
   */
  options: PaintOptions;
}

/**
 * @desc Input parameter
 */
declare interface PaintParams {
  /**
   * @desc Drawing configuration parameters
   */
  options: PaintOptions;
  /**
   * @desc Success callback
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {data} Successful return value {PaintTask}
   */
  success?: (data: PaintTask) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseExtendPaintParams {
  /**
   * @desc Drawing configuration parameters
   */
  options: ExtendPaintOptions;
}

/**
 * @desc Input parameter
 */
declare interface ExtendPaintParams {
  /**
   * @desc Drawing configuration parameters
   */
  options: ExtendPaintOptions;
  /**
   * @desc Success callback
   * @param {data} Successful return value {PaintTask}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (data: PaintTask) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseCancelParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  task_id: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
}

/**
 * @desc Input parameter
 */
declare interface PromiseQueryResultParams {
  /**
   * @desc Drawing configuration parameters
   */
  task_id: string;
}

/**
 * @desc Input parameter
 */
declare interface QueryResultParams {
  /**
   * @desc Drawing configuration parameters
   */
  task_id: string;
  /**
   * @desc Success callback
   * @param {data} Successful return value {TaskResult}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (data: TaskResult) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseRetryParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  task_id: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
}

/**
 * @desc Input parameter
 */
declare interface RetryParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  task_id: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Success callback
   * @param {task_id} Successful return value {string}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (task_id: string) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface CancelParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  task_id: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Success callback
   * @param {task_id} Successful return value {string}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (task_id: string) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSupportedStylesParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  styleType?: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
}

/**
 * @desc Input parameter
 */
declare interface SupportedStylesParams {
  /**
   * @desc Task ID, the task_id returned by the interface after submitting the task
   */
  styleType?: string;

  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Success callback
   * @param {data} Successful return value {Array<StyleInfo>}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (data: Array<StyleInfo>) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {number}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseAdvicePromptsParams {
  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
}

/**
 * @desc Input parameter
 */
declare interface AdvicePromptsParams {
  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Success callback
   * @param {data} Successful return value {Array<PromptInfo>}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  success?: (data: Array<PromptInfo>) => void;
  /**
   * 	@desc Failure callback function
   * 	@param {data} Return value of the failure callback {any}
   *	@param {code} Return status code of the failure callback {FailCodeEnum}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  fail?: (data: any, code: FailCodeEnum) => void;
}

/**
 * @desc Painter instance
 */
declare interface Painter {
  /**
   * @desc Submit a drawing task
   * @param {params} Submit drawing task input parameters {PaintParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  paint(params: PaintParams): void;

  /**
   * @desc Submit a drawing task
   * @param {params} Submit drawing task input parameters {PromisePaintParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<PaintTask>}
   */
  paint(params: PromisePaintParams): Promise<PaintTask>;
  /**
   * @desc Submit image outpainting task
   * @param {params} Submit image outpainting task input parameters {ExtendPaintParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  extendPaint(params: ExtendPaintParams): void;

  /**
   * @desc Submit image outpainting task
   * @param {params} Submit image outpainting task input parameters {PromiseExtendPaintParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<PaintTask>}
   */
  extendPaint(params: PromiseExtendPaintParams): Promise<PaintTask>;
  /**
   * @desc Query drawing task
   * @param {params} Query drawing task input parameters {QueryResultParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  queryResult(params: QueryResultParams): void;

  /**
   * @desc Query drawing task
   * @param {params} Query drawing task input parameters {PromiseQueryResultParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<TaskResult>}
   */
  queryResult(params: PromiseQueryResultParams): Promise<TaskResult>;

  /**
   * @desc Query drawing task
   * @param {params} Query drawing task input parameters {CancelParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  cancel(params: CancelParams): void;

  /**
   * @desc Query drawing task
   * @param {params} Query drawing task input parameters {PromiseCancelParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<string>}
   */
  cancel(params: PromiseCancelParams): Promise<string>;

  /**
   * @desc Retry drawing task; only completed tasks (failed processing, successful processing, or failed review) can be retried
   * @param {params} Retry drawing task input parameters {RetryParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  retry(params: RetryParams): void;

  /**
   * @desc Retry drawing task; only completed tasks (failed processing, successful processing, or failed review) can be retried
   * @param {params} Retry drawing task input parameters {PromiseRetryParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<string>}
   */
  retry(params: PromiseRetryParams): Promise<string>;
  /**
   * @desc Get the list of supported styles for drawing types
   * @param {params} Get supported style list for drawing types input parameters {SupportedStylesParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  getSupportedStyles(params: SupportedStylesParams): void;

  /**
   * @desc Get the list of supported styles for drawing types
   * @param {params} Get supported style list for drawing types input parameters {PromiseSupportedStylesParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<Array<StyleInfo>>}
   */
  getSupportedStyles(
    params: PromiseSupportedStylesParams
  ): Promise<Array<StyleInfo>>;
  /**
   * @desc Get text-to-image recommended keyword list
   * @param {params} Get text-to-image recommended keyword list input parameters {AdvicePromptsParams}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  getAdvicePrompts(params: AdvicePromptsParams): void;

  /**
   * @desc Get text-to-image recommended keyword list
   * @param {params} Get text-to-image recommended keyword list input parameters {PromiseAdvicePromptsParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<Array<PromptInfo>>}
   */
  getAdvicePrompts(
    params: PromiseAdvicePromptsParams
  ): Promise<Array<PromptInfo>>;
}

/**
 * @desc Error code
 */
type FailCodeEnum = 201 | 202 | 203 | 204 | 429;

/**
 * @desc Return an array composed of PromptInfo
 */
declare interface PromptInfo {
  /**
   * @desc Recommended keyword
   */
  long_text: string;
  /**
   * @desc Brief recommended keyword
   */
  short_text: string;
}

/**
 * @desc Return an array composed of StyleInfo
 */
declare interface StyleInfo {
  /**
   * @desc Style name
   */
  style_name: string;
  /**
   * @desc Style ID
   */
  style_id: string;
  /**
   * @desc Text relevance
   */
  cfg_scale: number;
  /**
   * @desc Image relevance
   */
  denoising_strength: number;
  /**
   * @desc Control strength
   */
  ctrl_net_strength: number;
  /**
   * @desc Sampling steps
   */
  steps: number;
}

/**
 * @desc Return drawing task result
 */
declare interface TaskResult {
  /**
   * @desc Drawing task ID
   */
  task_id: string;
  /**
   * @desc Drawing task type: img2img (image-to-image), txt2img (text-to-image)
   */
  task_type: string;
  /**
   * @desc Drawing task status: 0: In queue, waiting to be processed 1: Processing 2: Processed successfully 3: Processing failed 4: Canceled
   */
  status: number;
  /**
   * @desc Model version: "General v5.2"
   */
  model: string;
  /**
   * @desc Is the task completed
   */
  finished: boolean;
  /**
   * @desc Generated image URL list: ["image_url1", "image_url2"]
   */
  images_url: Array<string>;
  /**
   * @desc Generated image key list: ["xxxxxxxx-0.jpg", "xxxxxxx-1.jpg"]
   */
  image_gaia_key: Array<string>;
  /**
   * @desc Number of people waiting
   */
  queue_ahead: number;
  /**
   * @desc Estimated waiting time
   */
  task_eta: number;
  /**
   * @desc Generated image review status description: ["Normal", "Prohibited"]. This field is returned only for services with review configured
   */
  images_audit: Array<string>;
  /**
   * @desc Generated image review status
   */
  images_audit_status: Array<AuditStatusEnum>;
}

/**
 * @desc Generated image review status
 */
type AuditStatusEnum = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

/**
 * @desc Drawing configuration parameters
 */
declare interface PaintOptions {
  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Image description
   */
  prompt?: string;

  /**
   * @desc Image description
   */
  initImages?: string;

  /**
   * @desc Style template ID
   */
  styleConfig: string;

  /**
   * @desc Generated image height, a multiple of 8, [400, 1200]
   */
  height: number;

  /**
   * @desc Generated image width, a multiple of 8, [400, 1200]
   */
  width: number;

  /**
   * @desc Random seed
   */
  seed?: number;

  /**
   * @desc Text relevance, [3, 15]
   */
  cfgScale?: number;

  /**
   * @desc Image relevance, [0, 1]
   */
  denoisingStrength?: number;

  /**
   * @desc Control strength, [0, 1]
   */
  ctrlNetStrength?: number;

  /**
   * @desc Sampling steps, [20, 50]
   */
  steps?: number;

  /**
   * @desc Negative keywords
   */
  negativePrompt?: string;
}

/**
 * @desc Submit image outpainting task parameters
 */
declare interface ExtendPaintOptions {
  /**
   * @desc Request unique ID, a 32-character string
   */
  dataId?: string;
  /**
   * @desc Image description
   */
  prompt?: string;
  /**
   * @desc Initial image. Supports base64 and online images
   */
  initImages?: string;
  /**
   * @desc Style template ID
   */
  styleConfig: string;
  /**
   * @desc Outpainting mode: 1: Expand by multiplication factor; 2: Expand by proportion; 3: Expand by pixels
   */
  outpaintMode: number;
  /**
   * @desc Random seed
   */
  seed?: number;
  /**
   * @desc Expansion factor
   */
  padFactor?: number;
  /**
   * @desc Expansion ratio, only the following ratios are supported
   */
  padRatio?: string;
  /**
   * @desc Expansion pixels
   */
  padPixel?: PadPixelConfig;
  /**
   * @desc Format of the generated image, supports PNG and JPEG
   */
  imageFormat: string;
}

/**
 * @desc Expansion pixels. Note: The values for pad_up, pad_down, pad_left, pad_right, and pad_all should be in the range of 0 to 2048
 */
declare enum PadPixelConfig {
  /**
   * @desc Left edge expansion pixels
   */
  pad_left = 0,
  /**
   * @desc Right edge expansion pixels
   */
  pad_right = 0,
  /**
   * @desc When this value exists and is not 0, pad_up, pad_down, pad_left, and pad_right become invalid, and this value takes precedence
   */
  pad_all = 0,
  /**
   * @desc Bottom edge expansion pixels
   */
  pad_down = 0,
  /**
   * @desc Top edge expansion pixels
   */
  pad_up = 0,
}

/**
 * @desc Drawing task information
 */
declare interface PaintTask {
  /**
   * @desc Drawing task ID
   */
  task_id: string;
  /**
   * @desc Drawing type. img2img: image-to-image; txt2img: text-to-image
   */
  task_type: string;
  /**
   * @desc Drawing configuration
   */
  task_params: string;
  /**
   * @desc Model version used
   */
  model: string;
}
