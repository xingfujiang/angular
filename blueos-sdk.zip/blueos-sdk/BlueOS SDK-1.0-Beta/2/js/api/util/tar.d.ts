/**
 * Unpack
 * Interface declaration: {"name": "blueos.util.tar"}
 */
declare module "@blueos.util.tar" {
  /**
   * @desc Unpack
   * @devices (phone,watch)
   * @apiLevel 1
   * @param  {params} Input parameter {UntarParams}
   */
  const untar: (params: UntarParams) => void;

  /**
   * @desc Unpack
   * @devices (phone,watch)
   * @apiLevel 1
   * @param  {params} Input parameter {PromiseUntarParams}
   * @returns {Promise<void>}
   */
  const untar: (params: PromiseUntarParams) => Promise<void>;
}

/**
 * @desc input parameter
 */
declare interface PromiseUntarParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type.
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory, which cannot be an application resource path or of tmp type
   */
  dstUri: string;
}

/**
 * @desc input parameter
 */
declare interface UntarParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type.
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory, which cannot be an application resource path or of tmp type
   */
  dstUri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
