/**
 * Extract file" or "Unzip file
 * Interface declaration: {"name": "blueos.util.fastlz"}
 */
declare module "@blueos.util.fastlz" {
  /**
   * @desc Extract file" or "Unzip file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {DecompressParams}
   */
  const decompress: (params: DecompressParams) => void;

  /**
   * @desc Extract file" or "Unzip file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameter  {PromiseDecompressParams}
   * @returns {Promise<void>}
   */
  const decompress: (params: PromiseDecompressParams) => Promise<void>;
}

/**
 * @desc input parameter
 */
declare interface PromiseDecompressParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory must be a complete file name
   */
  dstUri: string;
}

/**
 * @desc input parameter
 */
declare interface DecompressParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory must be a complete file name
   */
  dstUri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
