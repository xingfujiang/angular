/**
 * llm
 * Interface declaration: {"name": "blueos.ai.blueLM"}
 */
declare module "@blueos.ai.blueLM" {
  /**
   * @desc dialog interface object
   */
  const chat: {
    /**
     * @desc Check whether the current terminal supports a specific edge model
     * @param {modelName} input parameters {string}
     * @devices (phone,watch)
     * @apiLevel 2
     * @returns {boolean}
     */
    isModelSupported: (modelName: string) => boolean;

    /**
     * @desc Initialize a dialogue instance
     * @param {config} input parameters {LLMConfig}
     * @devices (phone,watch)
     * @apiLevel 2
     * @returns {ChatInstance}
     */
    create: (config: LLMConfig) => ChatInstance;
  };
}

/**
 * @desc input parameters
 */
declare interface LLMConfig {
  /**
   * @desc enabled model name
   */
  modelName?: string;
  /**
   * @desc model generative response parameter configuration
   */
  generationConfig?: GenerationConfig;
  /**
   * @desc the set of system tools available for the large model
   */
  tools?: Array<FunctionTool>;
  /**
   * @desc  Used to adjust the content control level. This is a private interface and is not yet open
   */
  contentControl?: Array<ContentControl>;
}

/**
 * @desc control classification
 */
declare enum ControleCategoryEnum {
  /**
   * @desc Content that expresses, incites, or promotes hatred based on race, gender, ethnicity, religion, nationality, sexual orientation, disability status, or caste
   */
  HATE = 0,
  /**
   * @desc Negative or harmful comments about any target or individual
   */
  HARASSMENT = 1,

  /**
   * @desc Pornographic or other obscene content, such as descriptions of sexual activities or promotion of sexual services (excluding sex education and health)
   */
  SEXUAL = 2,
  /**
   * @desc Content describing death, violence, or physical harm
   */
  VIOLENCE = 3,
}

/**
 * @desc control level
 */
declare enum ControlLevelEnum {
  /**
   * @desc default control level
   */
  DEFAULT = 0,
  /**
   * @desc Lowest control level, which only filters content with a high likelihood of being unsafe
   */
  LOW = 1,
  /**
   * @desc Moderate control level, which filters content that may be unsafe
   */
  MEDIUM = 2,
  /**
   * @desc Strictest control level, which filters all potentially unsafe content
   */
  HEIGHT = 3,
  /**
   * @desc Disable control. Note: This is a private interface and not intended for public release
   */
  NONE = 4,
}

/**
 * @desc Used to adjust the content control level. This is a private interface and is not publicly available
 */
declare interface ContentControl {
  /**
   * @desc control classification
   */
  category: ControleCategoryEnum;
  /**
   * @desc control level
   */
  level: ControlLevelEnum;
}

/**
 * @desc the set of system tools available for the large model
 */
declare interface FunctionTool {
  /**
   * @desc Fixed 'function', specifies the developer-defined function capabilities available to the large model
   */
  type: "function";
  /**
   * @desc Define function names, descriptions, etc.
   */
  function: FunctionDeclare;
}

/**
 * @desc the set of system tools available to the large model
 */
declare interface FunctionDeclare {
  /**
   * @desc The name of the function to be called must consist of a-z, A-Z, 0-9, and can include underscores and hyphens, with a maximum length of 64.
   */
  name: string;
  /**
   * @desc Developer-defined function that can be called within the API scope
   */
  function: Function;
  /**
   * @desc A description of the function, used for the model to determine when and how to call the function. This is an optional attribute
   */
  description: string;
  /**
   * @desc Used to process the parameters returned by the large model to provide them to your function; otherwise, the parameters will be passed to your function as strings
   */
  parse?: Function;
  /**
   * @desc Parameters accepted by the function
   */
  parameters?: FunctionParameters;
  /**
   * @desc Description of the function's return value
   */
  returnValues?: ParametersProperties;

  /**
   * @desc Whether to enable strict mode when generating function calls. If set to true, the model will follow the exact schema defined in the parameters field
   */
  strict?: boolean;
}

/**
 * @desc Description of the function's return value
 */
declare interface ParametersProperties {
  /**
   * @desc A clear description of the parameter's purpose and expected format
   */
  description: string;
  /**
   * @desc Specify the data type of the parameter, such as string, integer, or boolean.
   */
  type: string;
}

/**
 * @desc Parameters accepted by the function
 */
declare interface FunctionParameters {
  /**
   * @desc Specify the overall data type of the parameter, such as object
   */
  type: string;
  /**
   * @desc A description of the function, used for the model to determine when and how to call the function. This is an optional attribute
   */
  properties: ParametersProperties;
  /**
   * @desc A string array listing the parameter names that are necessary for the function to run.
   */
  required?: Array<string>;
}

/**
 * @desc Model generative response parameter configuration
 */
declare interface GenerationConfig {
  /**
   * @desc The number of responses generated per prompt, currently only supports 1
   */
  count?: number;
  /**
   * @desc Stop tokens: when these symbols are encountered in the generated text, generation stops. For example, ['\n'].
   */
  stop?: Array<string>;
  /**
   * @desc The maximum number of tokens that the large model response can generate
   */
  maxTokens?: number;
  /**
   * @desc Controls the randomness of the generated text, with a range of (0,2], not including 0. Lower values (close to 0.0) make the generated text more deterministic and consistent, while higher values (close to 2.0) increase randomness and creativity, potentially resulting in some unusual word combinations. The default value is typically 1.0. For example, a value of 0.1 means only the top 10% of tokens are considered for generating responses
   */
  temperature?: number;
  /**
   * @desc  The top_p parameter is used for nucleus sampling, with a range of (0 to 1.0], not including 0. It controls the range of candidate words the model considers when generating each word. The higher the top_p value, the fewer candidate words the model considers, focusing on the most probable words. A lower top_p value makes the model consider more candidate words, increasing the diversity of the generated text. For example, top_p = 0.1 typically generates more diverse text because it allows the model to explore a wider range of word choices; top_p = 0.9 usually generates more coherent text because the model is more likely to select higher probability words that are more relevant to the context
   */
  topP?: number;
  /**
   * @desc TopK sampling is a strategy where, at each step of generation, only the top K most likely words predicted by the model are considered, and the rest are filtered out. Explanation: Smaller K values result in more focused generated text but may lack diversity, while larger K values increase diversity in the generated text but might introduce more uncertainty
   */
  topK?: number;
  /**
   * @desc Control the penalty factor for repetition in generated text, with a range of (-2.0 to 2.0), not including -2.0 and 2.0. Positive values increase the penalty for repetitive content, while negative values decrease the penalty
   */
  repeatPenalty?: number;
  /**
   * @desc In text generation, it is used to ensure the repeatability of results. When you set a specific seed value, the model will strive to produce the same output each time under the same input (prompt) and parameter configuration. This is very useful for experiments or when consistent output is needed
   */
  seed?: number;
}

/**
 * @desc Returns after initializing a dialogue instance
 */
declare interface ChatInstance {
  /**
   * @desc Initialize a dialogue instance and return.
   * @param {feature} input parameters {FeatureEnum}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {boolean}
   */
  isFeaturedSupported: (feature: FeatureEnum) => boolean;

  /**
   * @desc Supports single-turn tasks and multi-turn dialogues with streaming response
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} input parameters {ChatParams}
   */
  send(params: ChatParams): void;

  /**
   * @desc Supports single-turn tasks and multi-turn dialogues with streaming response
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} input parameters {PromiseChatParams}
   * @returns {Promise<ModelCompletion>}
   */
  send(params: PromiseChatParams): Promise<ModelCompletion>;

  /**
   * @desc Note: The internally maintained history array has a maximum of 100 entries, and any entries beyond this will result in the oldest records being automatically deleted.
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Array<ChatMessage>}
   */
  getHistory: () => Array<ChatMessage>;

  /**
   * @desc Returns the maximum token context supported by the current model instance
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  getSupportedMaxToken: () => number;

  /**
   * @desc Calculate the tokens actually required to be consumed when sending the current parameters to the model
   * @param {tokenRequest} 入参 {ChatParams | Array<ChatMessage> | string}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  countToken: (
    tokenRequest: ChatParams | Array<ChatMessage> | string
  ) => number;

  /**
   * @desc Note that tokens consumed by streaming responses are only tallied when the streaming response concludes
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {TokenUsage}
   */
  getUsedToken: () => TokenUsage;

  /**
   * @desc Listen for model responses; this event is triggered when new dialogue is generated. It returns the original message from the model's reply
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ModelCompletion}
   */
  onCompletion: (res: ModelCompletion) => void;

  /**
   * @desc Monitor the dialogue; this event is triggered whenever any participant generates a new dialogue, and it returns the dialogue message
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ChatMessage}
   */
  onMessage: (res: ChatMessage) => void;

  /**
   * @desc Monitor model rejection status; this event is triggered when the large model's filtering criteria are met, returning a rejection reply message and the reason for the model's rejection
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {res} callback result {string}
   */
  onRefusal: (res: string) => void;

  /**
   * @desc Monitor the dialogue; this event is triggered whenever any participant generates a new dialogue, returning the dialogue message
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {res} callback result {string}
   */
  onSteamCompletion: (res: ModelCompletion) => void;

  /**
   * @desc Effective when streaming dialogue is enabled, listen for model responses; this event is triggered when new dialogue is generated, returning the model's original response message
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {res} callback result {string}
   * @param {accumulated} callback result {string}
   */
  onStreamContent: (res: string, accumulated: string) => void;

  /**
   * @desc Streaming dialogue has been created. When the large model's rejection mechanism is triggered, the model will refuse to generate the related content and will return the reason for the rejection. Generally, the rejection mechanism helps prevent the model from generating content that does not meet safety and ethical standards
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {res} callback result {string}
   * @param {accumulated} callback result {string}
   */
  onStreamRefusal: (res: string, accumulated: string) => void;

  /**
   * @desc Effective when streaming dialogue is enabled, listen for the streaming reply end event; this event is triggered when the streaming reply concludes the session
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onStreamFinish: () => void;

  /**
   * @desc Monitor function call response; this callback is triggered when a function call is needed in the model's reply
   * @param {res} callback result {FunctionCall}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onFunctionCall: (res: FunctionCall) => void;

  /**
   * @desc Monitor function call results; the result obtained by using FunctionCall within the API to call the user-defined tool function
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} callback result {CallParams}
   */
  onFunctionCallResult: (params: CallParams) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  onError: (data: any, code: number) => void;
}

/**
 * @desc Input parameters
 */
declare interface PromiseChatParams {
  /**
   * @desc The body of the dialogue message. An array supports initializing dialogue context and multimodal input, while the string format conveniently supports subsequent multi-turn dialogues
   */
  messages: Array<ChatMessage> | string;
  /**
   * @desc The API internally automatically maintains history. This history parameter can override the internally maintained history value, mainly used for resetting and initializing the dialogue context. Note: The internally maintained history array has a maximum of 100 entries, and any entries beyond 100 will automatically result in the deletion of the oldest records
   */
  history?: Array<ChatMessage>;
  /**
   * @desc Whether to enable large model streaming response
   */
  isStream?: boolean;
  /**
   * @desc 	The set of system tools available to the large model; the input value will override the value set during model initialization.
   */
  tools?: Array<FunctionTool>;
  /**
   * @desc Model generative response parameter configuration; the input value will override the value set during model initialization
   */
  generationConfig?: GenerationConfig;
}

/**
 * @desc Input parameters for sending a message to the large model
 */
declare interface ChatParams {
  /**
   * @desc The body of the dialogue message. An array supports initializing dialogue context and multimodal input, while the string format conveniently supports subsequent multi-turn dialogues
   */
  messages: Array<ChatMessage> | string;
  /**
   * @desc The API internally automatically maintains history. This history parameter can override the internally maintained history value, mainly used for resetting and initializing the dialogue context. Note: The internally maintained history array has a maximum of 100 entries, and any entries beyond 100 will automatically result in the deletion of the oldest records
   */
  history?: Array<ChatMessage>;
  /**
   * @desc Whether to enable large model streaming response
   */
  isStream?: boolean;
  /**
   * @desc 	The set of system tools available to the large model; the input value will override the value set during model initialization.
   */
  tools?: Array<FunctionTool>;
  /**
   * @desc Model generative response parameter configuration; the input value will override the value set during model initialization
   */
  generationConfig?: GenerationConfig;
  /**
   * @desc success callback
   * @param {data} successful return value {ModelCompletion}
   */
  success?: (data: ModelCompletion) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc dialogue role
 */
type MessageRoleEnum = "system" | "user" | "model" | "tool";

/**
 * @desc content type
 */
type ChatTextContentTypeEnum = "text" | "image" | "refusal";

/**
 * @desc The body of the dialogue message. An array supports initializing the dialogue context and multimodal input, while a string format conveniently supports subsequent multi-turn dialogues
 */
declare interface ChatMessage {
  /**
   * @desc dialogue role
   */
  role: MessageRoleEnum;
  /**
   * @desc content corresponding to the dialogue role
   */
  content: Array<ChatContent> | string;
}

declare interface ChatContent {
  /**
   * @desc content type
   */
  type: ChatTextContentTypeEnum;
  /**
   * @desc When the type is imageSrc, the content is of the ChatImageContent type
   */
  content: string | ImageContent;
}

/**
 * @desc When the type is imageSrc, the content is of the ChatImageContent type
 */
declare interface ImageContent {
  /**
   * @desc Supports local image URI, base64, and Bitmap. Note: Online images are not currently supported.
   */
  from: any;
  /**
   * @desc Large model image interpretation level: the higher the level, the more detailed the conversion of the image to text, and the more time-consuming it becomes
   */
  level: ImageLevelEnum;
}

/**
 * @desc 	large model image interpretation level
 */
declare enum ImageLevelEnum {
  /**
   * @desc 	Automatically select based on the size of the uploaded image: low or high
   */
  auto = 0,
  /**
   * @desc 	The "low resolution" mode will be enabled. The model will receive a low-resolution 512px x 512px version of the image and represent it with a budget of 85 tokens. This allows the API to return faster responses and consume fewer input tokens in use cases where high detail is not required
   */
  low = 1,
  /**
   * @desc 	Enable "high resolution" mode, which allows the model to first view a low-resolution image (using 85 tokens) and then create detailed crops using 170 tokens for each 512px x 512px tile
   */
  height = 2,
}

/**
 * @desc 	Whether function calls are supported
 */
declare enum FeatureEnum {
  /**
   * @desc 	Whether function calls are supported
   */
  FunctionTool = 0,
}

/**
 * @desc 	return value
 */
declare interface ModelCompletion {
  /**
   * @desc 	unique identifier for this round of dialogue
   */
  id: number;
  /**
   * @desc 	When the initialization parameter count is configured to be greater than 1, a corresponding number of candidates will be generated.
   */
  candidates: Array<Candidate>;
  /**
   * @desc 	Unix timestamp (in seconds) when the large model's response was completed
   */
  created: number;
  /**
   * @desc 	Token statistics used in this round of dialogue
   */
  tokenUsage: TokenUsage;
}

/**
 * @desc 	Token statistics used in this round of dialogue
 */
declare interface TokenUsage {
  /**
   * @desc 	Number of tokens generated by the large model for candidate responses
   */
  candidateToken: number;

  /**
   * @desc 	Number of tokens in the prompt
   */
  promptToken: number;

  /**
   * @desc 	Total number of tokens used in this round of requests
   */
  totalToken: number;
}

/**
 * @desc 	When the initialization parameter count is set to greater than 1, a corresponding number of candidates is generated
 */
declare interface Candidate {
  /**
   * @desc 	index
   */
  index: number;

  /**
   * @desc 	Reason for the model stopping token generation
   */
  finishReason: FinishReasonEnum;

  /**
   * @desc 	Chat message generated by the model.
   */
  message: ModelMessage;
}

/**
 * @desc 	Chat message generated by the model
 */
declare interface ModelMessage {
  /**
   * @desc 	Fixed string 'model
   */
  role: "model";

  /**
   * @desc 	Content of the message
   */
  content: string | null;

  /**
   * @desc 	Rejection message generated by the model.
   */
  refusal?: string | null;

  /**
   * @desc 	Tool invocation message generated by the model.
   */
  toolCalls?: Array<FunctionCall> | null;
}

/**
 * @desc 	Tool invocation message generated by the model
 */
declare interface FunctionCall {
  /**
   * @desc 	Fixed 'function
   */
  type: "function";

  /**
   * @desc 	ID of the tool invocation
   */
  id: number;

  /**
   * @desc 	Name of the method to be called
   */
  name: string;

  /**
   * @desc 	Parameters of the method to be called
   */
  args: string;
}

/**
 * @desc 	Reason for the model stopping token generation
 */
declare enum FinishReasonEnum {
  /**
   * @desc 	unknown reason
   */
  UNKNOWN = 0,

  /**
   * @desc 	Model reached a natural stopping point or a provided stop sequence
   */
  STOP = 1,

  /**
   * @desc 	The maximum number of tokens specified in the request has been reached.
   */
  MAX_TOKENS = 2,

  /**
   * @desc 	he model invoked a tool
   */
  TOOL = 3,

  /**
   * @desc 	Content was filtered by the filter
   */
  FILTER = 4,
}

/**
 * @desc input parameters
 */
declare interface CallParams {
  /**
   * @desc 	Content was filtered by the filter
   */
  call: FunctionCall;
  /**
   * @desc 	Content was filtered by the filter
   */
  result: string;
}
