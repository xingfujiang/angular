/**
 * encryption algorithm.
 * Interface declaration: {"name": "blueos.security.cipher"}
 */
declare module "@blueos.security.cipher" {
  /**
   * @desc RSA encryption and decryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} RSA encryption and decryption, input parameters {RsaParams}
   */
  const rsa: (params: RsaParams) => void;

  /**
   * @desc RSA encryption and decryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} RSA RSA encryption and decryption, input parameters {PromiseRsaParams}
   * @returns {Promise<DataText>}
   */
  const rsa: (params: PromiseRsaParams) => Promise<DataText>;

  /**
   * @desc AES encryption and decryption, supports segmented encryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for AES encryption and decryption{AesParams}
   */
  const aes: (params: AesParams) => void;

  /**
   * @desc AES encryption and decryption, supports block encryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for AES encryption and decryption {PromiseAesParams}
   */
  const aes: (params: PromiseAesParams) => Promise<DataText>;

  /**
   * @desc Base64 encoding and decoding
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} Input parameters for Base64 encoding and decoding{Base64Params}
   * @returns {string}
   */
  const base64: (params: Base64Params) => string;

  /**
   * @desc crc32 encryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} encryption input parameters {Crc32Params}
   * @returns {number}
   */
  const crc32: (params: Crc32Params) => number;

  /**
   * @desc calculate hash value
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {params} input parameters for calculating the hash value {HashParams}
   * @returns {string}
   */
  const hash: (params: HashParams) => string;
}

/**
 * @desc Input parameter
 */
declare interface PromiseRsaParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
}

/**
 * @desc Input parameter
 */
declare interface RsaParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
  /**
   * @desc success callback
   * @param {data} callback function return value {DataText}
   */
  success?: (data: DataText) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseAesParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
  /**
   * @desc The initialization vector for AES encryption and decryption, which is a string encoded in base64. The default value is the key value
   */
  iv?: string;
  /**
   * @desc Initial vector offset for AES encryption and decryption, default value is 0
   */
  ivOffset?: number;
  /**
   * @desc Byte length of the initialization vector for AES encryption and decryption, default value is 16
   */
  ivLen?: number;
}

/**
 * @desc Input parameter
 */
declare interface AesParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
  /**
   * @desc The initialization vector for AES encryption and decryption, which is a string encoded in base64. The default value is the key value
   */
  iv?: string;
  /**
   * @desc Initial vector offset for AES encryption and decryption, default value is 0
   */
  ivOffset?: number;
  /**
   * @desc Byte length of the initialization vector for AES encryption and decryption, default value is 16
   */
  ivLen?: number;
  /**
   * @desc success callback
   * @param {data} callback function return value {DataText}
   */
  success?: (data: DataText) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc return value
 */
declare interface DataText {
  /**
   * @desc The text content generated after encryption or decryption. The encrypted content is a binary value encoded in base64, while the decrypted content is plain text. An error will occur (CODE: 200) if the decrypted content cannot be converted to a UTF-8 string
   */
  text: string;
}

/**
 * @desc Input parameter
 */
declare interface Base64Params {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text
   */
  text: string;
}

/**
 * @desc Input parameter
 */
declare interface Crc32Params {
  /**
   * @desc encrypted content
   */
  content: Buffer | string;
}

/**
 * @desc Input parameter
 */
declare interface HashParams {
  /**
   * @desc Hash algorithm, options are md5, sha256
   */
  algorithm: string;
  /**
   * @desc encrypted content
   */
  content: Buffer | string;
}
