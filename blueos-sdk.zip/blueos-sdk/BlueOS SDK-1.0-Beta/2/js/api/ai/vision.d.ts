/**
 * Visual technology
 * Interface declaration: {"name": "blueos.ai.vision"}
 */
declare module "@blueos.ai.vision" {
  /**
   * @desc Recognize all text in the image and return the position information of the text within the image, facilitating users in secondary processing for text layout.
   * @param {params} Input parameter {OcrParams}
   * @apiLevel 2
   * @devices (phone,watch)
   * @returns {Promise<OcrResult>}
   */
  const commonOcr: (params: OcrParams) => Promise<OcrResult>;

  /**
   * @desc Face segmentation, which uses AI cutout technology to segment the human head in an image, can be used for background swapping or face-swapping features
   * @apiLevel 2
   * @devices (phone,watch)
   * @param {params} Input parameter {SegmentFaceParams}
   * @returns {Promise<SegmentFaceResult>}
   */
  const segmentFace: (params: SegmentFaceParams) => Promise<SegmentFaceResult>;

  /**
   * @desc Foreground segmentation to distinguish images of people, cats, dogs, and cars
   * @apiLevel 2
   * @devices (phone,watch)
   * @param {params} Input parameter {SegmentForegroundParams}
   * @returns {Promise<SegmentForegroundResult>}
   */
  const segmentForeground: (
    params: SegmentForegroundParams
  ) => Promise<SegmentForegroundResult>;

  /**
   * @desc Foreground inpainting, a method of image editing. It uses segmentation algorithms to remove unwanted elements such as people, cats, dogs, and cars from an image and fills the area with natural patterns to minimize visible restoration traces.
   * @apiLevel 2
   * @devices (phone,watch)
   * @param {params} Input parameter {InpaintForegroundParams}
   * @returns {Promise<InpaintForegroundResult>}
   */
  const inpaintForeground: (
    params: InpaintForegroundParams
  ) => Promise<InpaintForegroundResult>;

  /**
   * @desc Composition cropping, which provides high-quality intelligent image cropping based on the main content of the image and framing requirements
   * @apiLevel 2
   * @devices (phone,watch)
   * @param {params} Input parameter {CropImageParams}
   * @returns {Promise<CropImageResult>}
   */
  const cropImage: (params: CropImageParams) => Promise<CropImageResult>;

  /**
   * @desc The API supports two platforms: the vivo AI platform and the Xuanji platform. By default, the API connects to the vivo AI platform. If you have already applied for an appId and appKey on the Xuanji platform and wish to use its services, you need to call this interface once to switch the API environment to the Xuanji platform.
   * @private
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const switch2xuanji: () => void;
}

/**
 * @desc Input parameter
 */
declare interface CropImageParams {
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;
  /**
   * @desc Cropped image information list. See the imageList description below for details
   */
  imageList: { imageUrl: string; imgSymbol: string };

  /**
   * @desc Crop ratio list, for example, ["10060", "10383"]
   */
  aspectRatio: Array<string>;
}

/**
 * @desc Result
 */
declare interface CropImageResult {
  /**
   * @desc Returned image information list. See the ImageResult description below for details
   */
  imageList: Array<ImageResult>;
}

/**
 * @desc Result
 */
declare interface ImageResult {
  /**
   * @desc Image name identifier
   */
  imageSymbol: string;

  /**
   * @desc Cropping result. See the CropResult description below for details
   */
  cropResult: Array<CropResult>;
}

declare interface CropResult {
  /**
   * @desc Input crop ratio
   */
  aspectRatio: string;
  /**
   * @desc Crop coordinates corresponding to the crop ratio
   */
  box: Array<number>;
}

/**
 * @desc Get result
 */
declare interface InpaintForegroundResult {
  /**
   * @desc Base64 encoding of the restored image result
   */
  inpaintImg: string;
}

/**
 * @desc Input parameter
 */
declare interface InpaintForegroundParams {
  /**
   * @desc Image base64 encoding
   */
  image: string;
  /**
   * @desc Base64 encoding of the mask
   */
  mask: string;
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;
}

/**
 * @desc Recognize all text in the image and return the position information of the text within the image, facilitating users in secondary processing for text layout
 */
declare interface OcrParams {
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;
  /**
   * @desc Base64 encoding of the image (currently, only jpg, png, and bmp formats are supported)
   */
  image: string;
  /**
   * @desc Request parameter configuration.
   */
  options?: OcrOptions;
}

/**
 * @desc Authentication information for the request to ensure the legitimacy of the request source
 */
declare interface Auth {
  /**
   * @desc 	Application appId
   */
  appId: string;
  /**
   * @desc Application appKey
   */
  appKey: string;
}

/**
 * @desc Request parameter configuration
 */
declare interface OcrOptions {
  /**
   * @desc Defaults to 2, with possible values of 0, 1, 2. 0 represents only text information, 1 represents providing both text information and coordinate information (absolute coordinates), and 2 represents providing both 0 and 1 information simultaneously
   */
  pos?: number;

  /**
   * @desc Choose whether to support rotated images and non-upright text recognition, default is false (not supported)
   */
  checkDirection?: number;
}

/**
 * @desc Obtain result
 */
declare interface OcrResult {
  /**
   * @desc Text information
   */
  words: Array<WordInfo>;

  /**
   * @desc Text and coordinate information
   */
  OCR: Array<OcrInfo>;

  /**
   * @desc Rotation angle
   */
  angle: number;
}

/**
 * @desc 	Text and coordinate information.
 */
declare interface OcrInfo {
  /**
   * @desc Recognized text information
   */
  words: number;
  /**
   * @desc Coordinate information related to the text
   */
  location: locationInfo;
}

/**
 * @desc Text information
 */
declare interface WordInfo {
  /**
   * @desc Text information.
   */
  words: string;
}

/**
 * @desc Coordinate information related to the text
 */
declare interface locationInfo {
  /**
   * @desc Top-left coordinate information
   */
  top_left: { x: number; y: number };
  /**
   * @desc Top-right coordinate information
   */
  top_right: { x: number; y: number };
  /**
   * @desc Bottom-left coordinate information
   */
  down_left: { x: number; y: number };
  /**
   * @desc Bottom-right coordinate information
   */
  down_right: { x: number; y: number };
}

/**
 * @desc Input parameter
 */
declare interface SegmentFaceParams {
  /**
   * @desc Image base64 encoding, with image dimensions not exceeding 1024 pixels
   */
  image: string;
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;
}

/**
 * @desc Obtain result
 */
declare interface SegmentFaceResult {
  /**
   * @desc Base64 encoding of the overall mask, the image is a single-channel grayscale image
   */
  originMask: string;
  /**
   * @desc The box category and position of partMask, including idx, xmax, xmin, ymax, ymin; representing the category idx and the proportion of the box's coordinates in the original image (between 0 and 1)
   */
  partBox: Array<string>;
  /**
   * @desc Base64 encoding of the mask corresponding to partBox, with the image also being a single-channel grayscale image
   */
  partMask: Array<string>;
  /**
   * @desc Contains height and width fields, dimensions of the originMask
   */
  size: { width: number; height: number };
}

/**
 * @desc Input parameter
 */
declare interface SegmentForegroundParams {
  /**
   * @desc Image base64 encoding, with image dimensions not exceeding a maximum of 1024 pixels
   */
  image: string;
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;
}

/**
 * @desc Obtain result
 */
declare interface SegmentForegroundResult {
  /**
   * @desc Base64 encoding of the overall mask, with the image being a single-channel grayscale image
   */
  orginMask: string;
  /**
   * @desc Mask for the inpainting area, as a single-channel grayscale image, with the background as 0 and the foreground as 255
   */
  inpaintMask: string;
  /**
   * @desc The box category and position of partMask, including idx, xmax, xmin, ymax, ymin; representing the category idx and the proportional coordinates of the box in the original image (between 0 and 1)
   */
  partBox: Array<string>;
  /**
   * @desc Base64 encoding of the mask corresponding to partBox, with the image also being a single-channel grayscale image
   */
  partMask: Array<string>;
  /**
   * @desc Contains height and width fields, dimensions of the originMask
   */
  size: { width: number; height: number };
}
