/**
 * Album invocation framework service
 * Interface declaration: {"name": "blueos.ai.mediaStore"}
 */
declare module "@blueos.ai.mediaStore" {
  /**
   * 	@desc Album invocation framework service searchPhotos interface, retrieve data matching the query
   *  @apiLevel 2
   *  @devices (phone,watch)
   * 	@param {params} Input parameter {SearchPhotosParams}
   */
  const searchPhotos: (params: SearchPhotosParams) => void;

  /**
   * 	@desc Album invocation framework service searchPhotos interface, retrieve data matching the query
   * 	@param {params} Input parameter {PromiseSearchPhotos}
   *  @apiLevel 2
   *  @devices (phone,watch)
   *  @returns {Promise<Array<TargetPhoto>>}
   */
  const searchPhotos: (
    params: PromiseSearchPhotos
  ) => Promise<Array<TargetPhoto>>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSearchPhotos {
  /**
   * @desc The original query content entered by the user.
   */
  query: string;
  /**
   * @desc JsonObject type, information about intent understanding passed through by the assistant from the cloud side
   */
  copilotJson: object;
}

/**
 * @desc Input parameter
 */
declare interface SearchPhotosParams {
  /**
   * @desc The original query content input by the user
   */
  query: string;
  /**
   * @desc JsonObject type, information on intent understanding passed through by the assistant from the cloud side
   */
  copilotJson: object;
  /**
   * @desc Successful callback
   * @param {data} Return value {Array<TargetPhoto>}
   * @apiLevel 2
   * @devices (phone,watch)
   */
  success?: (data: Array<TargetPhoto>) => void;
  /**
   * 	@desc Failed callback function
   * 	@param {data}Return value of the failed callback {any}
   *	@param {code} Return status code of the failed callback {number}
   *  @apiLevel 2
   *  @devices (phone,watch)
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc 0: represents a label, 1: represents semantics
 */
type SearchType = 0 | 1;

/**
 * @desc Return value
 */
declare interface TargetPhoto {
  /**
   * @desc 0: indicates a label, 1: indicates semantics
   */
  searchType: SearchType;
  /**
   * @desc Scores for label and semantic search results
   */
  score: number;
  /**
   * @desc Image name
   */
  name: string;
  /**
   * @desc Original image path
   */
  path: string;
  /**
   * @desc Thumbnail path
   */
  thumbnailPath: string;
  /**
   * @desc Image label
   */
  labelText: Array<string>;
  /**
   * @desc Image semantics
   */
  semanticText: Array<string>;
}
