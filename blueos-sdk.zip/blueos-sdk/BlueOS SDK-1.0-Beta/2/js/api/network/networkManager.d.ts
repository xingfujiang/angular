/**
 * network status
 * Interface declaration:{"name": "blueos.network.networkManager"}
 */
declare module "@blueos.network.networkManager" {
  /**
   * @desc get network type
   * @param {params} input parameters for getting network type {GetTypeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getType: (params?: GetTypeParams) => void;

  /**
   * @desc get network type
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Type>}
   */
  const getType: () => Promise<Type>;

  /**
   * 	@desc Monitor network connection status. If called multiple times, only the last call takes effect
   *  @param {params} input parameters for monitoring network connection status {SubscribeParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const subscribe: (params: SubscribeParams) => void;

  /**
   * @desc cancel monitoring of network connection status
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Get the SIM card's carrier information, phone permissions required
   * @param {params} input parameters for getting SIM card carrier information {GetSimOperatorsParams}
   * @deprecated deprecated, use instead'@blueos.telephony.simManager.getSimOperators()'
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getSimOperators: (params?: GetSimOperatorsParams) => void;

  /**
   * @desc Get the SIM card's carrier information, phone permissions required
   * @param {params} input parameters for getting SIM card carrier information {GetSimOperatorsParams}
   * @deprecated deprecated, use instead'@blueos.telephony.simManager.getSimOperators()'
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<OperatorsData>}
   */
  const getSimOperators: () => Promise<OperatorsData>;
}

/**
 * @desc callback after execution completion
 */
declare interface Type {
  /**
   * @desc Network types, possible values are 2g, 3g, 4g, wifi, none, 5g(), bluetooth(), others()
   */
  type: string;
}

/**
 * @desc input parameter
 */
declare interface GetTypeParams {
  /**
   * @desc success callback
   * @param {data} success callback return value {Type}
   */
  success?: (data: Type) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface SubscribeParams {
  /**
   * 	@desc Whether to persist subscription, default is false. Mechanism: set to true, and the subscription will not automatically cancel on page navigation, requiring manual cancellation
   */
  reserved?: boolean;
  /**
   * @desc Every time the network changes, a callback is triggered
   * @param {data} success callback return value {Type}
   */
  callback?: (data: Type) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc SIM card list information
 */
declare interface OperatorData {
  /**
   * @desc Return SIM card carrier information. Explanation of carrier information: Here, MCC+MNC (Mobile Country Code + Mobile Network Code) is uniformly returned. China Mobile: 46000, 46002, 46004, 46007; China Unicom: 46001, 46006, 46009; China Telecom: 46003, 46005, 46011
   */
  operator: string;
  /**
   * @desc Slot number
   */
  slotIndex: number;
}

/**
 * @desc SIM card list information
 */
declare interface OperatorsData {
  /**
   * @desc SIM card list information
   */
  operators: Array<OperatorData>;
  /**
   * @desc Number of SIM cards
   */
  size: string;
}

/**
 * @desc Input parameter
 */
declare interface GetSimOperatorsParams {
  /**
   * @desc Successful callback
   * @param {data} Successful callback return value {OperatorsData}
   */
  success?: (data: OperatorsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
