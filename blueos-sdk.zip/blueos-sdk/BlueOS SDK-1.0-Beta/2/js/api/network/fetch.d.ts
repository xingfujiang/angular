/**
 * data request
 * Interface declaration: {"name": "blueos.network.fetch"}
 */
declare module "@blueos.network.fetch" {
  /**
   * @desc HTTP request
   * @param {params} parameters for the network request {FetchParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const fetch: (params: FetchParams) => void;

  /**
   * @desc HTTP request
   * @param {params} parameters for the network request {PromiseFetchParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const fetch: (params: PromiseFetchParams) => Promise<HttpData>;
}

/**
 * @desc input parameter
 */
declare interface FetchParams {
  /**
   * @desc resource URL
   */
  url: string;
  /**
   * @desc Request parameters, which can be a string, a JS object, or an ArrayBuffer object. Refer to the section on the relationship between data and Content-Type
   */
  data?: string | Record<string, any> | ArrayBuffer;
  /**
   * @desc Request headers, which will have all its properties set in the request header section. User-Agent setting is supported from version 1040. Example: {"Accept-Encoding": "gzip, deflate","Accept-Language": "zh-CN,en-US;q=0.8,en;q=0.6"}
   */
  header?: Record<string, any>;
  /**
   * @desc Default is GET; it can be: OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
   */
  method?: string;
  /**
   * @desc Supported return types are text, json, file, and arraybuffer. By default, the return type is determined based on the Content-Type in the server's response header. See success return value for details
   */
  responseType?: string;
  /**
   * @desc callback function returned on success
   * @param {data}  return value of the callback function on success {HttpData}
   */
  success?: (data: HttpData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseFetchParams {
  /**
   * @desc resource URL
   */
  url: string;
  /**
   * @desc Request parameters, which can be a string, a JS object, or an ArrayBuffer object. Refer to the section on the relationship between data and Content-Type
   */
  data?: string | Record<string, any> | ArrayBuffer;
  /**
   * @desc Request headers, which will have all its properties set in the request header section. User-Agent setting is supported from version 1040. Example: {"Accept-Encoding": "gzip, deflate","Accept-Language": "zh-CN,en-US;q=0.8,en;q=0.6"}
   */
  header?: Record<string, any>;
  /**
   * @desc Default is GET; it can be: OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
   */
  method?: string;
  /**
   * @desc Supported return types are text, json, file, and arraybuffer. By default, the return type is determined based on the Content-Type in the server's response header. See success return value for details
   */
  responseType?: string;
}

/**
 * @desc return value
 */
declare interface HttpData {
  /**
   * @desc server status code
   */
  code: number;
  /**
   * @desc refer to the section on the relationship between responseType and data in success.
   */
  data: string | Record<string, any> | ArrayBuffer;
  /**
   * @desc all headers of the server response
   */
  headers: Record<string, any>;
}
