/**
 * WebSocket
 * Interface declaration:{"name": "blueos.network.webSocket"}
 */
declare module "@blueos.network.webSocket" {
  /**
   * @desc Create a WebSocket instance.
   * @param {params} Input parameters for creating a WebSocket instance {CreateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {CreateInstace}
   */
  const create: (params: CreateParams) => CreateInstance;
}

/**
 * @desc Input parameter
 */
declare interface CreateParams {
  /**
   *  @desc Request URL, must be using the wss or ws protocol
   */
  url: string;
  /**
   *  @desc Request headers, where Referer and User-Agent cannot be set in the header
   */
  header?: Record<string, any>;
  /**
   *  @desc Subprotocol group
   */
  protocols?: string[];
}

/**
 * @desc Input parameter
 */
declare interface PromiseSendParams {
  /**
   * @desc Sent message
   */
  data: string | ArrayBuffer;
}

/**
 * @desc Input parameter
 */
declare interface SendParams {
  /**
   * @desc Sent message
   */
  data: string | ArrayBuffer;
  /**
   * @desc Successful callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseCloseParams {
  /**
   * @desc Connection close status code, default is 1000
   */
  code?: number;
  /**
   * @desc Reason for closure
   */
  reason?: string;
}

/**
 * @desc Input parameter
 */
declare interface CloseParams {
  /**
   * @desc Connection close status code, default is 1000
   */
  code?: number;
  /**
   * @desc Reason for closure
   */
  reason?: string;
  /**
   * @desc Successful callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface MessageData {
  /**
   * @desc Message received by the listener; the message type is consistent with the sent type
   */
  data: string | ArrayBuffer;
}

/**
 * @desc Input parameter
 */
declare interface OnCloseParams {
  /**
   * @desc Status code returned by the server upon closure
   */
  code: number;
  /**
   * @desc Reason for closure returned by the server
   */
  reason: string;
  /**
   * @desc Was the closure normal?
   */
  wasClean: boolean;
}

/**
 * @desc Input parameter
 */
declare interface OnErrorParams {
  /**
   * @desc Message received by the listener
   */
  data: string;
}

/**
 * @desc Create instance
 */
declare interface CreateInstance {
  /**
   * @desc Send data to the server
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {params} Input parameters for sending data to the server {SendParams}
   */
  send(params: SendParams): void;

  /**
   * @desc Send data to the server
   * @param {params} Input parameters for sending data to the server {PromiseSendParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  send(params: PromiseSendParams): Promise<void>;

  /**
   * @desc Close the current connection
   * @param {params} Input parameters for closing the current connection {CloseParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  close(params: CloseParams): void;

  /**
   * @desc Close the current connection
   * @param {params} Input parameters for closing the current connection {PromiseCloseParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  close(params: PromiseCloseParams): Promise<void>;

  /**
   * @desc Used to specify the callback function after a successful connection
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onOpen: () => void;

  /**
   * @desc Used to specify the callback function when a message is received from the server
   * @param {data} Used to specify the return value of the callback function when a message is received from the server {MessageData}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onMessage: (data: MessageData) => void;

  /**
   * @desc Used to specify the callback function after the connection is closed
   * @param {data} Used to specify the return value of the callback function after the connection is closed {OnCloseParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onClose: (data: OnCloseParams) => void;

  /**
   *  @desc Used to specify the callback function after a connection failure
   *  @param {data} Used to specify the return value of the callback function after a connection failure {OnErrorParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  onError: (data: OnErrorParams) => void;
}
