/**
 * WiFiManager is a module used to manage basic Wi-Fi functions, including scanning for Wi-Fi networks, retrieving Wi-Fi information, and connecting to Wi-Fi
 * Interface declaration: { "name": "blueos.wifi.wifimanager" }
 */
declare module "@blueos.wifi.wifimanager" {
  /**
   * @desc Check if Wi-Fi is enabled
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {boolean}
   */
  const isEnabled: () => boolean;

  /**
   * @desc Check if Wi-Fi is connected
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {boolean}
   */
  const isConnected: () => boolean;

  /**
   * @desc Retrieve basic information about the connected Wi-Fi
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {ConnectedWifiData}
   */
  const getConnectedWifi: () => ConnectedWifiData;

  /**
   * @desc Register a listener for Wi-Fi status change events
   * @param {params} Input parameter {SubscribeDataParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  const subscribe: (params: SubscribeDataParams) => number;

  /**
   * @desc Unregister the listener for Wi-Fi status change events
   * @param {subscribeId} Input parameter {number}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const unsubscribe: (subscribeId: number) => void;

  /**
   * @desc Start Wi-Fi scan
   * @param {params} Input parameter {ScanParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const scan: (params?: ScanParams) => void;

  /**
   * @desc Initiate Wi-Fi scan
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const scan: () => Promise<void>;

  /**
   * @desc Retrieve Wi-Fi scan results
   * @param {params} Input parameter {GetScanResultsParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const getScanResults: (params: GetScanResultsParams) => void;

  /**
   * @desc Retrieve Wi-Fi scan results
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<ScannedInfo[]>}
   */
  const getScanResults: () => Promise<ScannedInfo[]>;

  /**
   * @desc Add suggested network configuration
   * @param {params} Input parameter {AddSuggestionConfigParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const addSuggestionConfig: (params: AddSuggestionConfigParams) => void;

  /**
   * @desc Add suggested network configuration
   * @param {params} Input parameter {PromiseAddSuggestionConfigParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  const addSuggestionConfig: (
    params: PromiseAddSuggestionConfigParams
  ) => Promise<number>;

  /**
   * @desc Remove suggested network configuration
   * @param {params} Input parameter {RemoveSuggestionConfigParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const removeSuggestionConfig: (params: RemoveSuggestionConfigParams) => void;

  /**
   * @desc Remove suggested network configuration
   * @param {params} Input parameter {PromiseRemoveSuggestionConfigParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const removeSuggestionConfig: (
    params: PromiseRemoveSuggestionConfigParams
  ) => Promise<void>;

  /**
   * @desc Retrieve suggested network configuration
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {SuggestionConfigsData}
   */
  const getSuggestionConfigs: () => SuggestionConfigsData;

  /**
   * @desc Connect to network configuration
   * @param {params} Input parameter {ConnectParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const connect: (params: ConnectParams) => void;

  /**
   * @desc Connect to the network configuration
   * @param {params} Input parameter {PromiseConnectParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  const connect: (params: PromiseConnectParams) => Promise<void>;
}

/**
 * @desc Wi-Fi security authentication method
 */
declare enum AuthType {
  /**
   * @desc Wi-Fi security authentication method
   */
  OPEN = 0,
  /**
   * @desc Wired Equivalent Privacy authentication method
   */
  WEP = 1,
  /**
   * @desc Pre-shared key authentication method
   */
  PSK = 2,
  /**
   * @desc Simultaneous Authentication of Equals authentication method
   */
  SAE = 3,
  /**
   * @desc WAPI-PSK authentication method
   */
  WAPI_PSK = 4,
}

/**
 * @desc Wi-Fi security authentication method
 */
declare enum WifiBandEnum {
  /**
   * @desc Auto-select
   */
  AUTO = 0,
  /**
   * @desc 2.4GHZ
   */
  "2.4GHZ" = 1,
  /**
   * @desc 5GHZ
   */
  "5GHZ" = 2,
}

/**
 * @desc MAC address type of the device
 */
declare enum MacType {
  /**
   * @desc Random MAC
   */
  RANDROM = 0,
  /**
   * @desc Device MAC
   */
  DEVICE = 1,
}

/**
 * @desc Technical standard of the Wi-Fi network
 */
declare type WifiStandard =
  | unknown
  | "Wi-Fi 1（802.11.b）"
  | "Wi-Fi 2（802.11.b）"
  | "Wi-Fi 3（802.11.b）"
  | "Wi-Fi 4（802.11.b）"
  | "Wi-Fi 5（802.11.b）"
  | "Wi-Fi 6（802.11.b）"
  | "Wi-Fi 7（802.11.b）"
  | "Wi-Fi 8（802.11.b）";

/**
 * @desc IP allocation method
 */
declare enum IpAssignment {
  /**
   * @desc Random MAC
   */
  DHCP = 0,
  /**
   * @desc Device MAC
   */
  STATIC = 1,
}

/**
 * @desc Status of the callback
 */
declare enum EnabledChange {
  /**
   * @desc Disabled
   */
  DISABLED = 0,
  /**
   * @desc Disabling
   */
  DISABLING = 1,
  /**
   * @desc In use
   */
  ENABLED = 2,
  /**
   * @desc In use
   */
  ENABLING = 3,
}

/**
 * @desc Monitored scan results
 */
declare interface ScannedInfo {
  /**
   * @desc SSID name of the Wi-Fi access point
   */
  ssid: string;
  /**
   * @desc BSSID value of the Wi-Fi access point
   */
  bssid: string;
  /**
   * @desc Is the Wi-Fi secure?
   */
  secure: Boolean;
  /**
   * @desc Signal strength of the Wi-Fi network, in dBm.
   */
  signalStrength: number;
  /**
   * @desc Authentication method of the Wi-Fi access point
   */
  authType: AuthType;
  /**
   * @desc Describe the authentication, key management, and encryption schemes supported by the access point
   */
  capabilities: string;
  /**
   * @desc Technical standard of the Wi-Fi network
   */
  wifiStandard: WifiStandard;
  /**
   * @desc Frequency band of the Wi-Fi access point
   */
  band: WifiBandEnum;
  /**
   * @desc Bandwidth of the Wi-Fi access point
   */
  channelWidth: number;
  /**
   * @desc Center frequency of the Wi-Fi access point
   */
  frequency: number;
  /**
   * @desc Frequency of the Wi-Fi access point. If the Wi-Fi access point uses 40, 80, 160, or 320 MHz, this is the center frequency (in MHz). If the Wi-Fi access point uses 80 + 80 MHz, this is the center frequency of the first segment (in MHz)
   */
  centerFrequency0: number;
  /**
   * @desc If the Wi-Fi access point uses 80 + 80 MHz, this is the center frequency of the second segment (in MHz)
   */
  centerFrequency1: number;
  /**
   * @desc Timestamp
   */
  timestamp: Date;
}

/**
 * @desc Input parameter
 */
declare interface SubscribeDataParams {
  /**
   * @desc Monitored event names: enabledChange (register listener for Wi-Fi status change events) scanned (register listener for Wi-Fi scan result change events)
   */
  type: "enabledChange" | "scanned";
  /**
   * @desc IP allocation method
   * @param {data} Return value {EnabledChange | ScannedInfo[]}
   */
  callback: (data: EnabledChange | ScannedInfo[]) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface ConnectedWifiData {
  /**
   * @desc SSID of the Wi-Fi network
   */
  ssid: string;
  /**
   * @desc BSSID of the Wi-Fi network
   */
  bssid: string;
  /**
   * @desc Is the Wi-Fi secure?
   */
  secure: boolean;
  /**
   * @desc Signal strength of the Wi-Fi network, in dBm
   */
  signalStrength: number;
  /**
   * @desc Authentication method of the Wi-Fi network
   */
  authType: AuthType;
  /**
   * @desc Frequency band of the Wi-Fi network
   */
  band: WifiBandEnum;
  /**
   * @desc Frequency of the Wi-Fi network
   */
  frequency: string;
  /**
   * @desc IPv4 address of the Wi-Fi network
   */
  ipV4: number;
  /**
   * @desc Connection speed of the Wi-Fi network, in bps
   */
  connectSpeed: number;
  /**
   * @desc Is the device allowed to automatically connect when near this Wi-Fi network?
   */
  isAutoConnect: boolean;
  /**
   * @desc MAC address of the device
   */
  macAdress: string;
  /**
   * @desc Type of the device's MAC address
   */
  macType: MacType;
  /**
   * @desc Technical standard of the Wi-Fi network
   */
  wifiStandard: WifiStandard;
  /**
   * @desc IP allocation method
   */
  ipAssignment: IpAssignment;
}

/**
 * @desc Input parameter
 */
declare interface ScanParams {
  /**
   * @desc callback after execution completes
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface GetScanResultsParams {
  /**
   * @desc callback after execution completes
   * @param {data} Successful return value {ScannedInfo[]}
   */
  success?: (data: ScannedInfo[]) => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseAddSuggestionConfigParams {
  /**
   * @desc SSID of the Wi-Fi device
   */
  ssid: string;
  /**
   * @desc BSSID of the Wi-Fi device
   */
  bssid: string;
  /**
   * @desc Wi-Fi device password
   */
  password?: string;
  /**
   * @desc 	Wi-Fi security authentication method
   */
  authType?: AuthType;
}

/**
 * @desc Input parameter
 */
declare interface AddSuggestionConfigParams {
  /**
   * @desc SSID of the Wi-Fi device
   */
  ssid: string;
  /**
   * @desc BSSID of the Wi-Fi device
   */
  bssid: string;
  /**
   * @desc Wi-Fi device password
   */
  password?: string;
  /**
   * @desc 	Wi-Fi security authentication method
   */
  authType?: AuthType;
  /**
   * @desc Successful callback
   * @param {wifiId} success callback return value {number}
   */
  success?: (wifiId: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface PromiseRemoveSuggestionConfigParams {
  /**
   * @desc ID of the network configuration
   */
  wifiId: number;
}

/**
 * @desc Input parameter
 */
declare interface RemoveSuggestionConfigParams {
  /**
   * @desc ID of the network configuration
   */
  wifiId: number;
  /**
   * @desc Successful callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface SuggestionConfigsData {
  /**
   * @desc SSID of the Wi-Fi device
   */
  ssid: string;
  /**
   * @desc BSSID of the Wi-Fi device
   */
  bssid: string;
  /**
   * @desc Wi-Fi device password
   */
  password?: string;
  /**
   * @desc 	Wi-Fi security authentication method
   */
  authType?: AuthType;
}

/**
 * @desc Input parameter
 */
declare interface PromiseConnectParams {
  /**
   * @desc ID of the network configuration
   */
  wifiId: number;
}

/**
 * @desc Input parameter
 */
declare interface ConnectParams {
  /**
   * @desc ID of the network configuration
   */
  wifiId: number;
  /**
   * @desc Successful callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
