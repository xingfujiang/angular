/**
 * Upload and download
 * Interface declaration: {"name": "blueos.network.request"}
 */
declare module "@blueos.network.request" {
  /**
   * @desc Upload file.
   * @param {params} File upload parameters {UploadParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const upload: (params: UploadParams) => void;

  /**
   * @desc Upload file.
   * @param {params} File upload parameters {PromiseUploadParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<SuccessData>}
   */
  const upload: (params: PromiseUploadParams) => Promise<SuccessData>;

  /**
   * 	@desc Download file.
   *  @param {params} Parameters for file download {DownloadParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const download: (params: DownloadParams) => void;

  /**
   * 	@desc Download file.
   *  @param {params} Parameters for file download {DownloadParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const download: (params: PromiseDownloadParams) => Promise<TokenData>;

  /**
   * 	@desc Monitor download task
   *  @param {params} Parameters for monitoring download tasks {OnDownloadCompleteParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const onDownloadComplete: (params: OnDownloadCompleteParams) => void;

  /**
   * 	@desc Monitor download task
   *  @param {params} Parameters for monitoring download tasks {PromiseOnDownloadCompleteParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<UriData>}
   */
  const onDownloadComplete: (
    params: PromiseOnDownloadCompleteParams
  ) => Promise<UriData>;

  /**
   * 	@desc Interrupt download task
   *  @param {params} Parameters for interrupting a download task{AbortDownloadParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const abortDownload: (params: AbortDownloadParams) => void;

  /**
   * 	@desc Interrupt download task
   *  @param {params} Parameters for interrupting a download task{PromiseAbortDownloadParams}
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const abortDownload: (params: PromiseAbortDownloadParams) => Promise<void>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseUploadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all of its properties will be set in the request's header section.
   */
  header?: Record<string, any>;
  /**
   * @desc The default is POST; it can be: POST, PUT
   */
  method?: string;
  /**
   * @desc List of files to be uploaded, submitted using multipart/form-data
   */
  files: Array<FilesArry>;
  /**
   * @desc Additional form data in the HTTP request
   */
  data?: Array<DataArry>;
}

/**
 * @desc Input parameter
 */
declare interface UploadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all of its properties will be set in the request's header section.
   */
  header?: Record<string, any>;
  /**
   * @desc The default is POST; it can be: POST, PUT
   */
  method?: string;
  /**
   * @desc List of files to be uploaded, submitted using multipart/form-data
   */
  files: Array<FilesArry>;
  /**
   * @desc Additional form data in the HTTP request
   */
  data?: Array<DataArry>;
  /**
   * @desc Successful callback
   * @param {data} success callback return value {SuccessData}
   */
  success?: (data: SuccessData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface FilesArry {
  /**
   * @desc Filename in the header when submitting multipart
   */
  filename?: string;
  /**
   * @desc Form item name for multipart submission, default is "file"
   */
  name?: string;
  /**
   * @desc Local address of the file
   */
  uri: string;
  /**
   * @desc Content-Type format of the file, which will be determined by the extension of the filename or URI by default
   */
  type?: string;
}

/**
 * @desc Input parameter
 */
declare interface DataArry {
  /**
   * @desc Name of the form element
   */
  name: string;
  /**
   * @desc Value of the form element
   */
  value: string;
}

/**
 * @desc Input parameter
 */
declare interface SuccessData {
  /**
   * @desc Server status code
   */
  code: number;
  /**
   * @desc If the type in the server's returned header is text/*, application/json, application/javascript, or application/xml, the value is text content. Otherwise, it is the URI of a stored temporary file. If the temporary file is an image or video content, it can be set to display on an image or video control
   */
  data: string;
  /**
   * @desc All headers of the server response
   */
  headers: Record<string, any>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseDownloadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all properties will be set in the request's header section. User-Agent setting is supported starting from version 1040
   */
  header?: string;
  /**
   * @desc Download description, used for the notification bar title. Defaults to the filename
   */
  description?: string;
  /**
   * @desc Download filename. By default, it is obtained from the network request or URL
   */
  filename?: string;
}

/**
 * @desc Input parameter
 */
declare interface DownloadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all properties will be set in the request's header section. User-Agent setting is supported starting from version 1040
   */
  header?: string;
  /**
   * @desc Download description, used for the notification bar title. Defaults to the filename
   */
  description?: string;
  /**
   * @desc Download filename. By default, it is obtained from the network request or URL
   */
  filename?: string;
  /**
   * @desc success callback
   * @param {data} success callback return value {TokenData}
   */
  success?: (data: TokenData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface TokenData {
  /**
   * @desc Download token, used to obtain the download status
   */
  token: string;
}

/**
 * @desc Input parameter
 */
declare interface PromiseOnDownloadCompleteParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
}

/**
 * @desc Input parameter
 */
declare interface OnDownloadCompleteParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
  /**
   * @desc success callback
   * @param {data} success callback return value {UriData}
   */
  success?: (data: UriData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface UriData {
  /**
   * @desc URI of the downloaded file
   */
  uri: string;
}

/**
 * @desc Input parameter
 */
declare interface PromiseAbortDownloadParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
}

/**
 * @desc Input parameter
 */
declare interface AbortDownloadParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
