/**
 * audio management
 * Interface declaration: {"name": "blueos.media.audio.audioManager"}
 */
declare module "@blueos.media.audio.audioManager" {
  /**
   * @desc Set volume
   * @param {params} Input parameters for setting volume {SetVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setVolume: (params: SetVolumeParams) => void;

  /**
   * @desc Set volume
   * @param {params} Input parameters {PromiseSetVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const setVolume: (params: PromiseSetVolumeParams) => Promise<void>;

  /**
   * @desc Get volume
   * @param {params} Input parameters for getting volume {GetVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getVolume: (params: GetVolumeParams) => void;

  /**
   * @desc Get volume
   * @param {params} Input parameters for getting volume {PromiseGetVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<number>}
   */
  const getVolume: (params: PromiseGetVolumeParams) => Promise<number>;

  /**
   * @desc Synchronously get volume
   * @param {params} Input parameters for synchronously getting volume {GetVolumeSyncParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getVolumeSync: (params: GetVolumeSyncParams) => number;

  /**
   * @desc Listen for volume changes
   * @param {params} Input parameters for listening to volume changes. {DataSubscribeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (params: DataSubscribeParams) => void;

  /**
   *  @desc Cancel listening to volume changes
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Get the minimum volume for the specified stream
   * @param {params} Input parameters for getting the minimum volume of the specified stream {GetMinVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getMinVolume: (params: GetMinVolumeParams) => number;

  /**
   * @desc Get the maximum volume for the specified stream
   * @param {params} nput parameters for getting the maximum volume of the specified stream {GetMaxVolumeParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getMaxVolume: (params: GetMaxVolumeParams) => number;

  /**
   * @desc Mute or unmute the specified volume stream
   * @param {params} Input parameters for muting or unmuting the specified volume stream {MuteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const mute: (params: MuteParams) => void;

  /**
   * @desc Mute or unmute the specified volume stream
   * @param {params} Input parameters for muting or unmuting the specified volume stream {PromiseMuteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void>}
   */
  const mute: (params: PromiseMuteParams) => Promise<void>;

  /**
   * @desc Check if the specified volume stream is muted
   * @param {params} Input parameters for checking if the specified volume stream is muted {IsMuteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const isMute: (params: IsMuteParams) => void;

  /**
   * @desc Check if the specified volume stream is muted
   * @param {params} Input parameters for checking if the specified volume stream is muted {IsMuteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<number>}
   */
  const isMute: (params: PromiseIsMuteParams) => Promise<number>;

  /**
   * @desc Check if the microphone is muted
   * @param {params} Input parameters for checking if the microphone is muted {IsMicrophoneMuteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const isMicrophoneMute: (params?: IsMicrophoneMuteParams) => void;

  /**
   * @desc Check if the microphone is muted
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<number>}
   */
  const isMicrophoneMute: () => Promise<number>;
}

/**
 * @desc input parameters
 */
declare interface SetVolumeParams {
  /**
   *  @desc volume stream type
   */
  volumeType: "RING" | "MEDIA";
  /**
   *  @desc Volume level, the set volume, between 0.00 and 1.00
   */
  volume: number;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseSetVolumeParams {
  /**
   *  @desc volume stream type
   */
  volumeType: "RING" | "MEDIA";
  /**
   *  @desc Volume level, the set volume, between 0.00 and 1.00
   */
  volume: number;
}

/**
 *  @desc audio stream type
 */
type VolumeType =
  | "SYSTEM"
  | "RING"
  | "MEDIA"
  | "VOICE_CALL"
  | "ALARM"
  | "NOTIFICATION"
  | "BLUETOOTH_SCO"
  | "TTS"
  | "SPORT_BROADCAST";

/**
 * @desc input parameters
 */
declare interface PromiseGetVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface GetVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc success callback
   *  @param {num} callback return value {number}
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface GetVolumeSyncParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 *  @desc success callback
 */
declare interface CallbackData {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc Volume level, with the set volume ranging between 0.00 and 1.00
   */
  value: number;
}

/**
 * @desc input parameters
 */
declare interface DataSubscribeParams {
  /**
   *  @desc volume: represents volume
   */
  type: string;
  /**
   *  @desc Monitor the execution of the volume change data callback function
   *  @param {data} callback return value for monitoring changes {CallbackData}
   */
  callback: (data: CallbackData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface GetMinVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface GetMaxVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface PromiseMuteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc Whether to mute the audio stream (1: set to mute; 0: set to unmute)
   */
  isMute: number;
}

/**
 * @desc input parameters
 */
declare interface MuteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc Whether to mute the audio stream (1: set to mute; 0: set to unmute)
   */
  isMute: number;

  /**
   *  @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseIsMuteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface IsMuteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc success callback
   *  @param {num} callback return value {number}
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface IsMicrophoneMuteParams {
  /**
   *  @desc success callback
   *  @param {num} Callback return value, 1: set to mute; 0: set to unmute). {number}
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
