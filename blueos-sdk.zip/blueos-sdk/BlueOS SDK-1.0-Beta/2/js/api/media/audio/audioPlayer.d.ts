/**
 * Simple interface for audio playback. If you want to achieve multi-audio playback, please visit {@link mediaManager}.
 * Interface declaration: {"name": "blueos.media.audio.audioPlayer"}
 */
declare module "@blueos.media.audio.audioPlayer" {
  /**
   * @desc URI of the audio media to be played
   */
  let src: string;

  /**
   * @desc The current progress of the audio, in seconds. Setting this value can adjust the playback position.
   */
  let currentTime: number;

  /**
   * @desc The duration of the audio playback, in seconds; returns NaN if unknown
   */
  let duration: number;

  /**
   * @desc Specify the audio type to use; possible values are 'music' and 'voicecall'. When set to 'music', the audio is played through the speaker, and when set to 'voicecall', it is played through the earpiece. The default is 'music
   */
  let streamType: string;

  /**
   * @desc A callback event triggered after the play method is called or when autoplay is set to true
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onPlay: () => void;

  /**
   * @desc A callback event triggered after the pause method is called
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onPause: () => void;

  /**
   * @desc A callback event triggered after the stop method is called
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onStop: () => void;

  /**
   * @desc The callback event triggered upon first receiving audio data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onLoadedData: () => void;

  /**
   * @desc A callback event triggered when playback ends
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onEnded: () => void;

  /**
   * @desc A callback event triggered when the playback duration changes
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onDurationChange: () => void;

  /**
   * @desc A callback event triggered when a playback error occurs
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onError: () => void;

  /**
   * @desc Triggered when the playback progress changes, with a trigger frequency of 4Hz
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onTimeUpdate: () => void;

  /**
   * @desc Start playing audio
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const play: () => void;

  /**
   * @desc Pause audio playback
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const pause: () => void;

  /**
   * @desc Stop audio playback, and audio can be replayed using the play method
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const stop: () => void;

  /**
   * @desc Get the current playback status data
   * @param {params} Input parameters for getting the current playback status data {GetPlayStateParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getPlayState: (params?: GetPlayStateParams) => void;

  /**
   * @desc Get the current playback status data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const getPlayState: () => Promise<AudioData>;
}

/**
 * @desc input parameters
 */
declare interface GetPlayStateParams {
  /**
   *  @desc success callback
   *  @param {data} Callback function return value {AudioData}
   */
  success?: (data: AudioData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc return value
 */
declare interface AudioData {
  /**
   * @desc Playback statuses, which are 'play', 'pause', and 'stop' respectively.
   */
  state: string;
  /**
   * @desc The URI of the currently playing audio media; returns an empty string when stopped.
   */
  src: string;
  /**
   * @desc The current progress of the audio, in seconds; returns -1 when stopped
   */
  currentTime: number;
}
