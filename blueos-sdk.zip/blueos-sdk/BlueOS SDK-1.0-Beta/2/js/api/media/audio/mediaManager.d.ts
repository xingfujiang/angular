/**
 * Provide functional interfaces for audio playback and recording
 * Interface declaration: {"name": "blueos.media.audio.mediaManager"}
 */
declare module "@blueos.media.audio.mediaManager" {
  /**
   * @desc Create an instance of audio playback
   * @param {params} Input parameters for creating an audio playback instance {CreateAudioPlayerParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {AudioInfoData}
   */
  const createAudioPlayer: (params?: CreateAudioPlayerParams) => AudioInfoData;

  /**
   * @desc Create an instance for audio streaming playback
   * @param {params} Input parameters for creating an audio streaming playback instance {CreateAudioTrackParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {AudioTrackInfo}
   */
  const createAudioTrack: (params?: CreateAudioTrackParams) => AudioTrackInfo;

  /**
   * @desc Create a recording instance
   * @param {params} Input parameters for creating a recording instance {CreateAudioRecordParams}
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {AudioRecordInfo}
   */
  const createAudioRecord: (
    params?: CreateAudioRecordParams
  ) => AudioRecordInfo;
}

declare interface CreateAudioPlayerParams {
  /**
   * @desc Used for volume policy, with a default value of music. The system can manage audio volume through different stream types, for example: setting music playback to music and message alerts to ring
   */
  streamType?: string;
  /**
   * @desc Used for audio post-processing, with a default value of music. The system optimizes sound based on different content types.
   */
  contentType?: string;
  /**
   * @desc Specify the audio type to use, with a default value of music. This is used for arbitrating audio conflicts; when multiple audio streams with the same stream usage are played simultaneously, the system will retain only one, and the others will be interrupted
   */
  streamUsage?: string;
}

/**
 * @desc Playback object
 */
declare interface AudioInfoData {
  /**
   * @desc URI of the audio media to be played.
   */
  src: string;
  /**
   * @desc The current progress of the audio, in seconds. Setting this value can adjust the playback position
   */
  currentTime: number;
  /**
   * @desc The total duration of the audio file, in seconds; returns NaN if unknown.
   */
  duration: number;
  /**
   * @desc Playback states are 'play', 'pause', 'stop', and 'idle'.
   */
  state: string;
  /**
   * @desc Control the looping of audio playback. playcount == 1 or playcount == 0: looping is off; playcount > 1: looping is on for the specified number of times; playcount == -1: looping is on indefinitely.
   */
  playcount: number;

  /**
   * @desc Start playing audio
   * @devices (phone,watch)
   * @apiLevel 1
   */
  play: () => void;
  /**
   * @desc Pause audio playback
   * @devices (phone,watch)
   * @apiLevel 1
   */
  pause: () => void;
  /**
   * @desc Stop audio playback, and you can replay the audio using the play method
   * @devices (phone,watch)
   * @apiLevel 1
   */
  stop: () => void;
  /**
   * @desc Release audio resources
   * @devices (phone,watch)
   * @apiLevel 1
   */
  release: () => void;

  /**
   * @desc Callback event after the audio starts playing
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onPlay: () => void;
  /**
   * @desc Callback event after the audio stops
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onStop: () => void;
  /**
   * @desc Callback event after the audio is paused
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onPause: () => void;
  /**
   * @desc Callback event when playback ends
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onEnded: () => void;
  /**
   * @desc Callback event when a playback error occurs
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onError: () => void;
  /**
   * @desc Callback event triggered when the currentTime property is updated
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onTimeUpdate: () => void;
  /**
   * @desc Audio interruption event, which includes notifications when the current audio is stopped or resumed due to being preempted by another audio with the same type, or when interrupted by external device operations
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onInterrupt: () => void;

  /**
   * @desc Callback event triggered upon first receiving audio data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onLoadedData: () => void;

  /**
   * @desc Triggered when the next track button on the music panel is clicked
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onNext: () => void;

  /**
   * @desc Triggered when the previous track button on the music panel is clicked
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onPrevious: () => void;

  /**
   * @desc Callback event triggered when the duration property is updated
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onDurationChange: () => void;
}

/**
 * @desc input parameter
 */
declare interface CreateAudioTrackParams {
  /**
   * @desc Used for volume strategy, with a default value of music. The system can manage audio volume through different stream types, for example: setting music playback to music and notification sounds to ring.
   */
  streamType?: string;
  /**
   * @desc Used for audio post-processing, with a default value of music. The system optimizes sound based on different content types
   */
  contentType?: string;
  /**
   * @desc Specify the audio type to use, with a default value of music. This is used for arbitrating audio conflicts; when multiple audio streams with the same streamUsage are played simultaneously, the system will retain only one, and the others will be interrupted.
   */
  streamUsage?: string;
  /**
   * @desc Sample rate, in Hertz, with optional values: 8000, 16000; default value is 16000
   */
  sampleRateInHz?: number;
  /**
   * @desc Number of audio capture channels, 1: mono, 2: stereo; default value is 1
   */
  channelConfig?: number;
  /**
   * @desc Sample resolution, in bits, with optional values: 8, 16; default value is 16
   */
  audioFormat?: number;
}

/**
 * @desc stream object
 */
declare interface AudioTrackInfo {
  /**
   * @desc Playback states, which are 'play', 'pause', and 'stop'.
   */
  state: string;

  /**
   * @desc Start playing audio
   * @devices (phone,watch)
   * @apiLevel 1
   */
  play: () => void;

  /**
   * @desc Pause audio playback
   * @devices (phone,watch)
   * @apiLevel 1
   */
  pause: () => void;

  /**
   * @desc Stop audio playback, and the audio can be replayed using the play method.
   * @devices (phone,watch)
   * @apiLevel 1
   */
  stop: () => void;

  /**
   * @desc Release audio resources
   * @devices (phone,watch)
   * @apiLevel 1
   */
  release: () => void;

  /**
   * @desc Write audio data
   * @param {params} Input parameters for writing audio data {WriteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  write: (params: WriteParams) => void;

  /**
   * @desc Write audio data
   * @param {params} Input parameters for writing audio data {WriteParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  write: (params: PromiseWriteParams) => Promise<StateData>;

  /**
   * @desc Callback event after the audio is played
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onPlay: () => void;
  /**
   * @desc Callback event after the audio stops
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onStop: () => void;
  /**
   * @desc Callback event after the audio is paused
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onPause: () => void;
  /**
   * @desc Callback event when playback ends
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onEnded: () => void;
  /**
   * @desc Callback event when a playback error occurs
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onError: () => void;
  /**
   * @desc Callback event triggered when the currentTime property is updated
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onTimeupdate: () => void;
  /**
   * @desc Audio interruption event, which includes notifications when the current audio is stopped or resumed due to being preempted by another audio with the same type, or when interrupted by external device operations
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onInterrupt: () => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseWriteParams {
  /**
   * @desc Sample resolution in bits, with optional values: 8, 16; default value is 16
   */
  buffer: Uint8Array;
}

/**
 * @desc input parameters
 */
declare interface WriteParams {
  /**
   * @desc Sample resolution in bits, with optional values: 8, 16; default value is 16
   */
  buffer: Uint8Array;
  /**
   *  @desc success callback
   *  @param {data} Callback function return value {StateData}
   */
  success?: (data: StateData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc status
 */
declare interface StateData {
  /**
   * @desc Write status: 1 - Success, 2 - Failure, 3 - Invalid Parameter.
   */
  state: number;
}

/**
 * @desc input parameters
 */
declare interface CreateAudioRecordParams {
  /**
   * @desc Sample rate in Hertz, optional values: 8000, 16000; default value is 16000
   */
  sampleRateInHz?: number;
  /**
   * @desc Number of audio channels, 1: mono, 2: stereo; default value is 1
   */
  channelConfig?: number;
  /**
   * @desc Sample resolution in bits, optional values: 8, 16; default value is 16
   */
  audioFormat?: number;
}

/**
 * @desc return object
 */
declare interface AudioRecordInfo {
  /**
   * @desc Start recording and generate an audio file after the recording ends
   * @param {params} Input parameters for starting a recording and generating an audio file after the recording ends {StartRecordParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  start: (params: StartRecordParams) => void;

  /**
   * @desc Start recording and generate an audio file after the recording ends
   * @param {params} Input parameters for starting a recording and generating an audio file after the recording ends {PromiseStartRecordParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  start: (params: PromiseStartRecordParams) => Promise<void>;

  /**
   * @desc Start recording, and return audio content in real-time during the recording process
   * @param {params} Start reading recording input parameters {ReadRecordParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  read: (params: ReadRecordParams) => void;

  /**
   * @desc Stop recording
   * @devices (phone,watch)
   * @apiLevel 1
   */
  stop: () => void;

  /**
   * @desc Release recording resources
   * @devices (phone,watch)
   * @apiLevel 1
   */
  release: () => void;

  /**
   * @desc Callback event when a recording error occurs.
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onError: () => void;

  /**
   * @desc Callback event when recording starts.
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onStart: () => void;

  /**
   * @desc Callback event when recording stops
   * @devices (phone,watch)
   * @apiLevel 1
   */
  onStop: () => void;
}

/**
 * @desc input parameters
 */
declare interface PromiseStartRecordParams {
  /**
   * @desc The URI to which the output file will be written
   */
  uri: string;
}

/**
 * @desc input parameters
 */
declare interface StartRecordParams {
  /**
   * @desc The URI to which the output file will be written
   */
  uri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface ReadRecordParams {
  /**
   * 	@desc callback function
   * 	@param {buffer} callback return value {Uint8Array}
   */
  callback: (buffer: Uint8Array) => void;
}
