/**
 * A simple interface for recording. If you need more complex functionality, please visit {@link mediaManager}
 * Interface declaration: {"name": "blueos.media.audio.audioRecorder"}
 */
declare module "@blueos.media.audio.audioRecorder" {
  /**
   * @desc Start recording. The default format is PCM, with a sample rate of 16000 Hz, 16-bit depth, and 2 channels.
   * @param {params} Input parameters for starting recording {StartDataParams}
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const start: (params: StartDataParams) => void;

  /**
   * @desc Start recording. The default format is PCM, with a sample rate of 16000 Hz, 16-bit depth, and 2 channels.
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const start: () => Promise<Uri>;

  /**
   * @desc Stop recording
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const stop: () => void;

  /**
   * @desc Release recording resources
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const release: () => void;

  /**
   * @desc A callback event triggered when a recording error occurs
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onError: () => void;

  /**
   * @desc A callback event triggered when recording starts
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onStart: () => void;

  /**
   * @desc A callback event triggered when recording stops
   * @devices (phone,watch)
   * @apiLevel 1
   */
  let onStop: () => void;
}

/**
 * @desc input parameters
 */
declare interface StartDataParams {
  /**
   *  @desc success callback
   *  @param {data} Callback function return value {Uri}
   */
  success?: (data: Uri) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Uri {
  /**
   * @desc The storage path of the recording file, located in the application's cache directory.
   */
  uri: string;
}
