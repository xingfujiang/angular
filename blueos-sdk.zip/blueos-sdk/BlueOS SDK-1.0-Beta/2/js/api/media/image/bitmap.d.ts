/**
 * A bitmap image is essentially an array composed of pixels, with each pixel representing a point in the image.
 * Developers can use this interface to read and write pixel data, obtain image properties and pixel formats, and perform operations such as scaling, rotating, and cropping the image
 * Interface declaration: { "name": "blueos.media.image" }
 */
declare module "@blueos.media.image" {
  /**
   * @desc image object
   */
  const BitmapSource: BitmapSourceType;

  /**
   * @desc image object
   */
  const Bitmap: BitmapType;

  /**
   * @desc image object
   */
  const BitmapOutput: BitmapOutputType;
}

/**
 * @desc image object
 */
declare interface BitmapOutputType {
  /**
   * @desc create object
   * @param {params} callback return value {CreateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {BitmapOutputInstanceType}
   */
  create: (params: CreateParams) => BitmapOutputInstanceType;
}

/**
 * @desc input parameters
 */
declare interface CreateParams {
  /**
   * @desc resource
   */
  source: Bitmap | BitmapSource;
}

/**
 * @desc image object.
 */
declare interface BitmapSourceType {
  /**
   * @desc create object
   * @param {params} input parameters {UriParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {BitmapSource}
   */
  create(params: UriParams): BitmapSource;

  /**
   * @desc create object
   * @param {params} input parameters {BufParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {BitmapSource}
   */
  create(params: BufParams): BitmapSource;
}

/**
 * @desc image object
 */
declare interface BitmapType {
  /**
   * @desc create object
   * @param {params} input parameters {CreateBitmapTypeParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  create(params: CreateBitmapTypeParams): void;

  /**
   * @desc create object
   * @param {params} input parameters {PromiseCreateBitmapTypeParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Bitmap>}
   */
  create(params: PromiseCreateBitmapTypeParams): Promise<Bitmap>;
}

declare interface BitmapSource {
  /**
   * @desc get image information
   * @param {params} input parameters {GetImageInfoParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  getImageInfo(params: GetImageInfoParams): void;

  /**
   * @desc get image information
   * @param {params} input parameters {PromiseGetImageInfoParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<ImageInfo>}
   */
  getImageInfo(params: PromiseGetImageInfoParams): Promise<ImageInfo>;

  /**
   * @desc create object
   * @param {params} input parameters {CreateBitmapParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  createBitmap(params: CreateBitmapParams): void;

  /**
   * @desc create object
   * @param {params} input parameters {PromiseCreateBitmapParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<ImageInfo>}
   */
  createBitmap(params: PromiseCreateBitmapParams): Promise<ImageInfo>;

  /**
   * @desc release resources
   * @devices (phone,watch)
   * @apiLevel 2
   */
  release: () => void;
}

/**
 * @desc image object
 */
declare interface Bitmap {
  /**
   * @desc get image-related information
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {ImageInfo}
   */
  getImageInfo: () => ImageInfo;

  /**
   * 	@desc pixel data object.
   */
  pixels: PixelsInstance;

  /**
   * 	@desc crop
   * 	@param {params} input parameters {CropParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  crop(params: CropParams): void;

  /**
   * 	@desc crop
   * 	@param {params} input parameters {CropParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   *  @returns {Promise<void>}
   */
  crop(params: PromiseCropParams): Promise<void>;

  /**
   * @desc perform position transformation on a bitmap using coordinates
   * @param {params} input parameters {TranslateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  translate(params: TranslateParams): void;

  /**
   * @desc perform position transformation on a bitmap using coordinates
   * @param {params} input parameters {PromiseTranslateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  translate(params: PromiseTranslateParams): Promise<void>;

  /**
   * @desc scale
   * @param {params} input parameters {ScaleParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  scale(params: ScaleParams): void;

  /**
   * @desc scale
   * @param {params} input parameters {PromiseScaleParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  scale(params: PromiseScaleParams): Promise<void>;

  /**
   * @desc rotate
   * @param {params} input parameters {RotateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  rotate(params: RotateParams): void;

  /**
   * @desc rotate
   * @param {params} input parameters {PromiseRotateParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  rotate(params: PromiseRotateParams): Promise<void>;

  /**
   * @desc release bitmap resources
   * @devices (phone,watch)
   * @apiLevel 2
   */
  release: () => void;
}

/**
 * @desc create bitmap output target object
 */
declare interface BitmapOutputInstanceType {
  /**
   * @desc Asynchronously return the compressed ArrayBuffer data of the Bitmap after compression
   * @param {params} input parameters {CompressParams}
   * @devices (phone,watch)
   * @apiLevel 2
   */
  compress(params: CompressParams): void;

  /**
   * @desc Asynchronously return the compressed ArrayBuffer data of the Bitmap after compression
   * @param {params} input parameters {PromiseCompressParams}
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<ArrayBuffer>}
   */
  compress(params: PromiseCompressParams): Promise<ArrayBuffer>;

  /**
   * @desc release image output-related resources
   * @devices (phone,watch)
   * @apiLevel 2
   */
  release: () => void;
}

/**
 * @desc path
 */
declare interface UriParams {
  /**
   * @desc release resources related to image output
   */
  uri: string;
  /**
   * @desc configuration
   */
  options?: BitmapSourceOptions;
}

/**
 * @desc buffer
 */
declare interface BufParams {
  /**
   * @desc release resources related to image output
   */
  buf: ArrayBuffer;
  /**
   * @desc configuration
   */
  options?: BitmapSourceOptions;
}

/**
 * @desc Image attributes, including image index and default attribute values
 */
declare interface BitmapSourceOptions {
  /**
   * @desc The pixel density of the image source, used as the default pixel density for the Bitmap
   */
  density?: number;
  /**
   * @desc The width of the image source
   */
  width?: number;
  /**
   * @desc The pixel format of the image source
   */
  pixelFormat?: PixelFormat;

  /**
   * @desc The height of the image source
   */
  height?: number;
}

/**
 * @desc The pixel format of the image, e.g., BGRA_8888
 */
declare enum PixelFormat {
  /**
   * @desc unknown format
   */
  UNKNOWN = 0,
  /**
   * @desc Each pixel stores only the alpha (transparency) information, represented by 8 bits
   */
  ALPHA_8 = 1,
  /**
   * @desc 24-bit RGB format, with the red and blue channels represented by 5 bits each, and the green channel represented by 6 bits
   */
  RGB_565 = 2,
  /**
   * @desc 24-bit RGB format, with each pixel channel represented by 8 bits
   */
  RGB_888 = 3,
  /**
   * @desc 32-bit RGB format, with each pixel channel represented by 8 bits
   */
  RGBA_8888 = 4,

  /**
   * @desc 32-bit RGB format, with each pixel represented by 8 bits
   */
  BGRA_8888 = 5,

  /**
   * @desc 2-bit RGB format, with red, green, and blue channels represented by 10 bits each, and the alpha (transparency) channel represented by 2 bits
   */
  RGBA_1010102 = 6,

  /**
   * @desc 64-bit RGB format, with each pixel channel represented by a 16-bit floating point number.
   */
  RGBA_F16 = 7,

  /**
   * @desc A YUV format where the Y component is stored as one plane, and the U and V components are stored in two separate planes. The U and V components are usually stored at a 1/4 sampling rate, meaning one U and one V pixel are stored for every four Y pixels
   */
  YV12 = 8,

  /**
   * @desc A YUV format where the Y component is stored consecutively in one plane, with each pixel corresponding to one Y component. The U and V components are stored in two separate planes, each at a 1/4 sampling rate
   */
  YUV_420_888 = 9,

  /**
   * @desc A YUV format where the Y component's pixel data is stored consecutively in one plane, and the UV components are stored alternately in another plane, meaning one pixel stores the V component, and the next pixel stores the U component
   */
  NV21 = 10,
}

/**
 * @desc corresponding compressed format
 */
declare enum CompressFormat {
  /**
   * @desc JPEG format
   */
  JPEG = 0,
  /**
   * @desc PNG format
   */
  PNG = 1,
  /**
   * @desc webp format
   */
  WEBP = 2,
}

/**
 * @desc specific rectangular area space
 */
declare interface Region {
  /**
   * @desc x-coordinate
   */
  x?: number;
  /**
   * @desc y-coordinate
   */
  y?: number;
  /**
   * @desc width
   */
  width?: number;
  /**
   * @desc height
   */
  height?: number;
}

/**
 * @desc Image attributes, including image index and default attribute values
 */
declare interface Area {
  /**
   * @desc The pixel density of the image source, used as the default pixel density for the Bitmap
   */
  region?: Region;
  /**
   * @desc he width of the image source
   */
  offset?: number;
  /**
   * @desc The pixel format of the image source
   */
  stride?: number;
}

/**
 * @desc 	Alpha channel information
 */
declare enum AlphaInfo {
  /**
   * @desc unknown format
   */
  UNKNOWN = 0,
  /**
   * @desc No alpha channel
   */
  NONE = 1,
  /**
   * @desc No color data, only an alpha channel
   */
  ALPHA_ONLY = 2,
  /**
   * @desc The color components have been multiplied by the alpha value. For example, premultiplied ARGB format
   */
  PREMULTIPLIED = 3,
  /**
   * @desc he color components have not been multiplied by the alpha value
   */
  UN_PREMULTIPLIED = 4,
}

/**
 * @desc Configuration options for decoding into a Bitmap
 */
declare interface DecodeOptions {
  /**
   * @desc If set to a value greater than 1, the decoder is requested to subsample the original image and return a smaller image to save memory
   */
  sampleSize?: number;
  /**
   * @desc desired output width
   */
  width?: number;
  /**
   * @desc desired decoding region
   */
  region?: Region;

  /**
   * @desc desired output height
   */
  height?: number;

  /**
   * @desc desired output height
   */
  isMutable?: boolean;

  /**
   * @desc desired output height
   */
  pixelFormat?: PixelFormat;
}

/**
 * @desc image property object
 */
declare interface ImageInfo {
  /**
   * @desc image width
   */
  width: number;
  /**
   * @desc image height
   */
  height: number;
  /**
   * @desc total bytes per row.
   */
  bytesPerRow: number;
  /**
   * @desc bits per pixel
   */
  bitsPerPixel: number;
  /**
   * @desc total bytes occupied by the image
   */
  totalBytes: number;
  /**
   * @desc Bitmap pixel format, e.g., BGRA_8888
   */
  pixelFormat: PixelFormat;
  /**
   * @desc bits occupied by sample pixels
   */
  depth: number;
  /**
   * @desc Alpha channel information
   */
  alphaInfo: AlphaInfo;
  /**
   * @desc the number of images contained in the image source
   */
  imageCount: number;
  /**
   * @desc Returns the MIME type of the image, such as Image/png or image/jpeg. If none is available, it returns null
   */
  mimeType: string | null;
}

/**
 * @desc input parameter
 */
declare interface PromiseCreateBitmapTypeParams {
  /**
   * @desc color array
   */
  colors: ArrayBuffer;
  /**
   * @desc width
   */
  width: number;
  /**
   * @desc height
   */
  height: number;
  /**
   * @desc bytes per row
   */
  bytesPerRow: number;
  /**
   * @desc Mutable or not; immutable bitmaps cannot be edited in the Bitmap object
   */
  isMutable?: boolean;
  /**
   * @desc pixel format
   */
  pixelFormat: PixelFormat;
  /**
   * @desc Alpha channel information
   */
  alphaInfo: AlphaInfo;
}

/**
 * @desc input parameter
 */
declare interface CreateBitmapTypeParams {
  /**
   * @desc color array
   */
  colors: ArrayBuffer;
  /**
   * @desc width
   */
  width: number;
  /**
   * @desc height
   */
  height: number;
  /**
   * @desc bytes per row
   */
  bytesPerRow: number;
  /**
   * @desc Mutable or not; immutable bitmaps cannot be edited in the Bitmap object
   */
  isMutable?: boolean;
  /**
   * @desc pixel format
   */
  pixelFormat: PixelFormat;
  /**
   * @desc Alpha channel information
   */
  alphaInfo: AlphaInfo;
  /**
   * @desc callback function returned on success
   * @param {data} return value of the callback function on success {Bitmap}
   */
  success?: (data: Bitmap) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseGetImageInfoParams {
  /**
   * @desc The image source format contains multiple images, which can be specified through an index
   */
  index?: number;
}

/**
 * @desc input parameter
 */
declare interface GetImageInfoParams {
  /**
   * @desc The image source format contains multiple images, which can be specified through an index
   */
  index?: number;
  /**
   * @desc callback function returned on success
   * @param {data} return value of the callback function on success {ImageInfo}
   */
  success?: (data: ImageInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseCreateBitmapParams {
  /**
   * @desc image index
   */
  index?: number;
  /**
   * @desc configuration parameters
   */
  options?: DecodeOptions;
}

/**
 * @desc input parameter
 */
declare interface CreateBitmapParams {
  /**
   * @desc image index
   */
  index?: number;
  /**
   * @desc configuration parameters
   */
  options?: DecodeOptions;
  /**
   * @desc callback function returned on success
   * @param {data} return status code of the failure callback {ImageInfo}
   */
  success?: (data: ImageInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc create object
 */
declare interface PixelsInstance {
  /**
   * 	@desc Read pixel data from the entire bitmap or a specific region of the bitmap and write it to the target buffer
   * 	@param {params} input parameter {ReadToBufferParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  readToBuffer(params: ReadToBufferParams): void;

  /**
   * 	@desc Read pixel data from the entire bitmap or a specific region of the bitmap and write it to the target buffer
   * 	@param {params} input parameter {ReadToBufferParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   *  @returns {Promise<void>}
   */
  readToBuffer(params: PromiseReadToBufferParams): Promise<void>;

  /**
   * 	@desc Write the source buffer to the bitmap, overwriting pixel data of the entire bitmap or a specific region of the bitmap.
   * 	@param {params} input parameter {WriteWithBufferParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  writeWithBuffer(params: WriteWithBufferParams): void;

  /**
   * 	@desc Write the source buffer to the bitmap, overwriting pixel data of the entire bitmap or a specific region of the bitmap.
   * 	@param {params} input parameter {WriteWithBufferParams}
   *  @devices (phone,watch)
   *  @apiLevel 2
   *  @returns {Promise<void>}
   */
  writeWithBuffer(params: PromiseWriteWithBufferParams): Promise<void>;
}

/**
 * @desc input parameter
 */
declare interface PromiseCropParams {
  /**
   * @desc cropping area
   */
  region: Region;
}

/**
 * @desc input parameter
 */
declare interface CropParams {
  /**
   * @desc cropping area
   */
  region: Region;
  /**
   * @desc callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseWriteWithBufferParams {
  /**
   * @desc Write the pixel data of the Bitmap as unpremultiplied ARGB values in the sRGB ColorSpace into the target ArrayBuffer. The size of the target buffer can be obtained using bitmapInstance.getImageInfo to get totalBytes
   */
  sourceBuffer: ArrayBuffer;
  /**
   * @desc When the area is not defined, the entire bitmap is read into the target buffer by default; when the area parameter is defined, only pixels from the specified region are read into the target buffer
   */
  area?: Area;
}

/**
 * @desc input parameter
 */
declare interface WriteWithBufferParams {
  /**
   * @desc Write the pixel data of the Bitmap as unpremultiplied ARGB values in the sRGB ColorSpace into the target ArrayBuffer. The size of the target buffer can be obtained using bitmapInstance.getImageInfo to get totalBytes
   */
  sourceBuffer: ArrayBuffer;
  /**
   * @desc When the area is not defined, the entire bitmap is read into the target buffer by default; when the area parameter is defined, only pixels from the specified region are read into the target buffer
   */
  area?: Area;
  /**
   * @desc callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseReadToBufferParams {
  /**
   * @desc Write the pixel data of the Bitmap as unpremultiplied ARGB values in the sRGB ColorSpace to the target ArrayBuffer. The size of the target buffer can be obtained using bitmapInstance.getImageInfo to retrieve totalBytes
   */
  targetBuffer: ArrayBuffer;
  /**
   * @desc When the area is not defined, the default behavior is to read the entire bitmap into the target buffer; when the area parameter is defined, only the pixels from the specified region are read into the target buffer
   */
  area?: Area;
}

/**
 * @desc input parameter
 */
declare interface ReadToBufferParams {
  /**
   * @desc Write the pixel data of the Bitmap as unpremultiplied ARGB values in the sRGB ColorSpace to the target ArrayBuffer. The size of the target buffer can be obtained using bitmapInstance.getImageInfo to retrieve totalBytes
   */
  targetBuffer: ArrayBuffer;
  /**
   * @desc When the area is not defined, the default behavior is to read the entire bitmap into the target buffer; when the area parameter is defined, only the pixels from the specified region are read into the target buffer
   */
  area?: Area;
  /**
   * @desc callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseTranslateParams {
  /**
   * @desc x-coordinate
   */
  x: number;
  /**
   * @desc y-coordinate
   */
  y: number;
}

/**
 * @desc input parameter
 */
declare interface TranslateParams {
  /**
   * @desc x-coordinate
   */
  x: number;
  /**
   * @desc y-coordinate
   */
  y: number;
  /**
   * @desc callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseScaleParams {
  /**
   * @desc horizontal scaling factor
   */
  x: number;
  /**
   * @desc vertical scaling factor.
   */
  y: number;

  /**
   * @desc 	center point x-coordinate
   */
  originX?: number;

  /**
   * @desc center point y-coordinate
   */
  originY?: number;
}

/**
 * @desc input parameter
 */
declare interface ScaleParams {
  /**
   * @desc horizontal scaling factor
   */
  x: number;
  /**
   * @desc vertical scaling factor.
   */
  y: number;

  /**
   * @desc 	center point x-coordinate
   */
  originX?: number;

  /**
   * @desc center point y-coordinate
   */
  originY?: number;

  /**
   * @desc callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseRotateParams {
  /**
   * @desc The angle of rotation, for example, 60.0 means a rotation of 60°
   */
  angle: number;
  /**
   * @desc center point x-coordinate
   */
  originX?: number;
  /**
   * @desc center point y-coordinate
   */
  originY?: number;
}

/**
 * @desc input parameter
 */
declare interface RotateParams {
  /**
   * @desc The angle of rotation, for example, 60.0 means a rotation of 60°
   */
  angle: number;
  /**
   * @desc center point x-coordinate
   */
  originX?: number;
  /**
   * @desc center point y-coordinate
   */
  originY?: number;
  /**
   * @desc Callback function returned on success
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface PromiseCompressParams {
  /**
   * @desc corresponding compression format
   */
  format: CompressFormat;
  /**
   * @desc Image compression quality parameter, with a range of values from 1 to 100
   */
  quality: number;
}

/**
 * @desc input parameter
 */
declare interface CompressParams {
  /**
   * @desc corresponding compression format
   */
  format: CompressFormat;
  /**
   * @desc Image compression quality parameter, with a range of values from 1 to 100
   */
  quality: number;
  /**
   * @desc Callback function returned on success
   * @param {data} return value of the failure callback {ArrayBuffer}
   */
  success?: (data: ArrayBuffer) => void;
  /**
   * 	@desc failure callback function
   * 	@param {data} return value of the failure callback {any}
   *	@param {code} return status code of the failure callback {number}
   */
  fail?: (data: any, code: number) => void;
}
