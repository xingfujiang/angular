/**
 * Toast notification
 * Interface declaration: {"name": "blueos.window.prompt"}
 */
declare module "@blueos.window.prompt" {
  /**
   * @desc Toast notification.
   * @devices (phone,watch)
   * @apiLevel 1
   * @param  {ShowToastParams} options-Input parameter 
   */
  const showToast: (options: ShowToastParams) => void;
}

/**
 * @desc input parameter
 */
declare interface ShowToastParams {
  /**
   * @desc Text to display
   */
  message: string;
  /**
   * @desc 0 for short duration, 1 for long duration, default is 0
   */
  duration?: number;
}
