/**
 * @desc Console output information
 */
declare const console: {
  /**
   * @desc Print debug information.
   * @param {string} message - Debug information input
   * @param {...any[]} arguments - Debug information input
   * @devices (phone,watch)
   * @apiLevel 1
   */
  debug(message: string, ...arguments: any[]): void
  /**
   * @desc Print log information.
   * @param {string} message - Log information input
   * @param {...any[]} arguments - Log information input
   * @devices (phone,watch)
   * @apiLevel 1
   */
  log(message: string, ...arguments: any[]): void
  /**
   * @desc Print info information.
   * @param {string} message - Info information input
   * @param {...any[]} arguments - Info information input
   * @devices (phone,watch)
   * @apiLevel 1
   */
  info(message: string, ...arguments: any[]): void
  /**
   * @desc Print warn information.
   * @param {string} message - Warn information input
   * @param {...any[]} arguments  - Warn information input
   * @devices (phone,watch)
   * @apiLevel 1
   */
  warn(message: string, ...arguments: any[]): void
  /**
   * @desc Print error information.
   * @param {string} message - Error information input
   * @param {...any[]} arguments - Error information input
   * @devices (phone,watch)
   * @apiLevel 1
   */
  error(message: string, ...arguments: any[]): void
}

/**
 * @desc Timer.
 * @param {Function} handler - Function argument
 * @param {number} delay - Time argument
 * @param {...any[]} arguments  - Other arguments
 * @apiLevel 1
 * @devices (phone,watch)
 * @returns {number} - Returns the ID of the timer
 */
declare function setTimeout(
  handler: Function | string,
  delay?: number,
  ...arguments: any[]
): number

/**
 * @desc Timer.
 * @param {Function} handler - Function argument
 * @param {number} delay - Time argument
 * @param {...any[]} arguments - Other arguments
 * @apiLevel 1
 * @devices (phone,watch)
 * @returns {number} - Returns the ID of the timer
 */
declare function setInterval(
  handler: Function | string,
  delay: number,
  ...arguments: any[]
): number

/**
 * @desc Converts to a number.
 * @param {any} value - Input parameter
 * @apiLevel 1
 * @devices (phone,watch)
 * @returns {number} - Returns a number
 */
declare function Number(value: any): number

/**
 * @desc Converts to a string.
 * @param {any} value - Input parameter
 * @apiLevel 1
 * @devices (phone,watch)
 * @returns {string} - Returns a string
 */
declare function String(value: any): string

/**
 * @desc Clears a timer created by setInterval().
 * @param {number} intervalID - Timer input parameter
 * @devices (phone,watch)
 * @apiLevel 1
 */
declare function clearInterval(intervalID?: number): void

/**
 * @desc Clears a timer created by setTimeout().
 * @param {number} timeoutID - Timer input parameter
 * @devices (phone,watch)
 * @apiLevel 1
 */
declare function clearTimeout(timeoutID?: number): void

/**
 * @desc Number utility function
 */
declare const Math: {
  /**
   * @desc Returns the absolute value of a number.
   * @param {number} x - The number to get the absolute value of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The absolute value of x.
   */
  abs(x: number): number

  /**
   * @desc Returns the arccosine of a number.
   * @param {number} x - The number to get the arccosine of. Range [-1, 1].
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The arccosine of x in radians.
   */
  acos(x: number): number

  /**
   * @desc Returns the hyperbolic arccosine of a number.
   * @param {number} x - The number to get the hyperbolic arccosine of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic arccosine of x.
   */
  acosh(x: number): number

  /**
   * @desc Returns the arcsine of a number.
   * @param {number} x - The number to get the arcsine of. Range [-1, 1].
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The arcsine of x in radians.
   */
  asin(x: number): number

  /**
   * @desc Returns the hyperbolic arcsine of a number.
   * @param {number} x - The number to get the hyperbolic arcsine of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic arcsine of x.
   */
  asinh(x: number): number

  /**
   * @desc Returns the arctangent of a number.
   * @param {number} x - The number to get the arctangent of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The arctangent of x in radians.
   */
  atan(x: number): number

  /**
   * @desc Returns the angle whose tangent is the quotient of two specified numbers.
   * @param {number} y - The y-coordinate.
   * @param {number} x - The x-coordinate.
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number} - The angle in radians from the positive x-axis.
   */
  atan2(y: number, x: number): number

  /**
   * @desc Returns the hyperbolic arctangent of a number.
   * @param {number} x - The number to get the hyperbolic arctangent of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic arctangent of x.
   */
  atanh(x: number): number

  /**
   * @desc Returns the cube root of a number.
   * @param {number} x - The number to get the cube root of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The cube root of x.
   */
  cbrt(x: number): number

  /**
   * @desc Returns the smallest integer greater than or equal to a number.
   * @param {number} x - The number to get the ceiling of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The ceiling value of x.
   */
  ceil(x: number): number

  /**
   * @desc Returns the number of leading zero bits in the 32-bit binary representation of a number.
   * @param {number} x - The input number.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The count of leading zero bits.
   */
  clz32(x: number): number

  /**
   * @desc Returns the cosine of a number.
   * @param {number} x - The number to get the cosine of (in radians).
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The cosine of x.
   */
  cos(x: number): number

  /**
   * @desc Returns the hyperbolic cosine of a number.
   * @param {number} x - The number to get the hyperbolic cosine of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic cosine of x.
   */
  cosh(x: number): number

  /**
   * @desc Returns ex, where e is Euler's number and x is the exponent.
   * @param {number} x - The exponent value.
   * @apiLevel 1
   * @returns {number} - The result of e raised to the power of x.
   */
  exp(x: number): number

  /**
   * @desc Returns ex - 1, where e is Euler's number and x is the exponent.
   * @param {number} x - The exponent value.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The result of e raised to the power of x minus 1.
   */
  expm1(x: number): number

  /**
   * @desc Returns the largest integer less than or equal to a number.
   * @param {number} x - The number to get the floor of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The floor value of x.
   */
  floor(x: number): number

  /**
   * @desc Returns the nearest single precision float representation of a number.
   * @param {number} x - The number to round.
   * @devices (phone,watch)
   * @returns {number} - The nearest single precision float to x.
   */
  fround(x: number): number

  /**
   * @desc Returns the square root of the sum of squares of its arguments.
   * @param {...number} values - The numbers to calculate the square root of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The square root of the sum of squares.
   */
  hypot(...values: number[]): number

  /**
   * @desc Performs C-like multiplication of two 32-bit integer numbers.
   * @param {number} a - The first integer.
   * @param {number} b - The second integer.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The result of multiplying a by b.
   */
  imul(a: number, b: number): number

  /**
   * @desc Returns the natural logarithm (e-based) of a number.
   * @param {number} x - The number to get the natural logarithm of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The natural logarithm of x.
   */
  log(x: number): number

  /**
   * @desc Returns the natural logarithm of 1 + x.
   * @param {number} x - The number for which to calculate the natural logarithm of (1 + x).
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The natural logarithm of 1 + x.
   */
  log1p(x: number): number

  /**
   * @desc Returns the base 10 logarithm of a number.
   * @param {number} x - The number to get the base 10 logarithm of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The base 10 logarithm of x.
   */
  log10(x: number): number

  /**
   * @desc Returns the base 2 logarithm of a number.
   * @param {number} x - The number to get the base 2 logarithm of.
   * @apiLevel 1
   * @returns {number} - The base 2 logarithm of x.
   */
  log2(x: number): number

  /**
   * @desc Returns the largest of its arguments.
   * @param {...number} values - The numbers to compare.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The largest number.
   */
  max(...values: number[]): number

  /**
   * @desc Returns the smallest of its arguments.
   * @param {...number} values - The numbers to compare.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The smallest number.
   */
  min(...values: number[]): number

  /**
   * @desc Returns the base raised to the power of exponent.
   * @param {number} base - The base number.
   * @param {number} exponent - The exponent number.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The result of base raised to the power of exponent.
   */
  pow(base: number, exponent: number): number

  /**
   * @desc Returns a pseudo-random number between 0 and 1.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - A pseudo-random number between 0 and 1.
   */
  random(): number

  /**
   * @desc Returns the value of a number rounded to the nearest integer.
   * @param {number} x - The number to round.
   * @apiLevel 1
   * @returns {number} - The value of x rounded to the nearest integer.
   */
  round(x: number): number

  /**
   * @desc Returns the sign of a number, indicating whether the number is positive, negative or zero.
   * @param {number} x - The number to check.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - 1 if positive, -1 if negative, 0 if zero.
   */
  sign(x: number): number

  /**
   * @desc Returns the sine of a number.
   * @param {number} x - The number to get the sine of (in radians).
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The sine of x.
   */
  sin(x: number): number

  /**
   * @desc Returns the hyperbolic sine of a number.
   * @param {number} x - The number to get the hyperbolic sine of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic sine of x.
   */
  sinh(x: number): number

  /**
   * @desc Returns the square root of a number.
   * @param {number} x - The number to get the square root of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The square root of x.
   */
  sqrt(x: number): number

  /**
   * @desc Returns the tangent of a number.
   * @param {number} x - The number to get the tangent of (in radians).
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The tangent of x.
   */
  tan(x: number): number

  /**
   * @desc Returns the hyperbolic tangent of a number.
   * @param {number} x - The number to get the hyperbolic tangent of.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The hyperbolic tangent of x.
   */
  tanh(x: number): number

  /**
   * @desc Returns the integer part of a number by removing any fractional digits.
   * @param {number} x - The number to truncate.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The integer part of x.
   */
  trunc(x: number): number
}

/**
 * @desc Extend the original string type
 */
interface String {
  /**
   * @desc Returns the length of the string.
   * @type {number}
   * @apiLevel 1
   * @devices (phone,watch)
   * @readonly
   */
  readonly length: number

  /**
   * @desc Returns the string representation of the object.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string}
   */
  toString(): string

  /**
   * @desc Returns the character at the specified index.
   * @param {number} pos - The position of the character.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - Character at the specified index.
   */
  charAt(pos: number): string

  /**
   * @desc Returns the Unicode value of the character at the given index.
   * @param {number} index - The position of the character.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - Unicode value of the character.
   */
  charCodeAt(index: number): number

  /**
   * @desc Concatenates the string arguments to the calling string.
   * @apiLevel 1
   * @devices (phone,watch)
   * @param {string[]} strings - Strings to concatenate.
   * @returns {string} - The concatenated string.
   */
  concat(...strings: string[]): string

  /**
   * @desc Returns the index within the calling string of the first occurrence of the specified value.
   * @param {string} searchString - The string to search for.
   * @param {number} [position] - The position to begin the search.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The index, or -1 if not found.
   */
  indexOf(searchString: string, position?: number): number

  /**
   * @desc Returns the index within the calling string of the last occurrence of the specified value.
   * @param {string} searchString - The string to search for.
   * @param {number} [position] - The position to begin the search backward.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The index, or -1 if not found.
   */
  lastIndexOf(searchString: string, position?: number): number

  /**
   * @desc Compares the calling string to the specified string.
   * @param {string} that - The string to compare with.
   * @returns {number} - A negative, zero, or positive value.
   */
  localeCompare(that: string): number

  /**
   * @desc Retrieves the matches when matching a string against a regular expression.
   * @param {string | RegExp} regexp - The regular expression pattern.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {RegExpMatchArray | null} - Array of matches, or null if no matches.
   */
  match(regexp: string | RegExp): RegExpMatchArray | null

  /**
   * @desc Replaces occurrences of a substring with a new string.
   * @param {string | RegExp} searchValue - The value to search for.
   * @param {string} replaceValue - The string that replaces the searchValue.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The modified string.
   */
  replace(searchValue: string | RegExp, replaceValue: string): string

  /**
   * @desc Replaces occurrences of a substring using a replacer function.
   * @param {string | RegExp} searchValue - The value to search for.
   * @param {function} replacer - A function that returns the replacement text.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The modified string.
   */
  replace(
    searchValue: string | RegExp,
    replacer: (substring: string, ...args: any[]) => string
  ): string

  /**
   * @desc Searches for a match between a regular expression and a string.
   * @param {string | RegExp} regexp - The regular expression pattern.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {number} - The position of the first match found, or -1 if no match.
   */
  search(regexp: string | RegExp): number

  /**
   * @desc Extracts a section of a string and returns it as a new string.
   * @param {number} [start] - The start index.
   * @param {number} [end] - The end index.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The extracted string.
   */
  slice(start?: number, end?: number): string

  /**
   * @desc Splits a string using a separator into an array of strings.
   * @param {string | RegExp} separator - The string or regular expression to use for separating.
   * @param {number} [limit] - A limit on the number of splits.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string[]} - An array of strings split at each point.
   */
  split(separator: string | RegExp, limit?: number): string[]

  /**
   * @desc Returns the substring at a start and optionally the end index.
   * @param {number} start - The start index.
   * @param {number} [end] - The end index.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The substring.
   */
  substring(start: number, end?: number): string

  /**
   * @desc Converts the string to lowercase.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The lowercase version of the string.
   */
  toLowerCase(): string

  /**
   * @desc Converts the string to lowercase according to locale-specific case mappings.
   * @param {string | string[]} [locales] - The locale or locales to consider.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The locale-sensitive lowercase version.
   */
  toLocaleLowerCase(locales?: string | string[]): string

  /**
   * @desc Converts the string to uppercase.
   * @returns {string} - The uppercase version of the string.
   */
  toUpperCase(): string

  /**
   * @desc Converts the string to uppercase according to locale-specific case mappings.
   * @param {string | string[]} [locales] - The locale or locales to consider.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The locale-sensitive uppercase version.
   */
  toLocaleUpperCase(locales?: string | string[]): string

  /**
   * @desc Removes whitespace from both ends of the string.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The trimmed string.
   */
  trim(): string

  /**
   * @desc Returns the primitive value of a String object.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The primitive value.
   */
  valueOf(): string

  /**
   * @desc Returns the character at the specified index, allowing negative numbers.
   * @param {number} index - The index of the character.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string | undefined} - The character, or undefined if out of bounds.
   */
  at(index: number): string | undefined

  /**
   * @desc Determines whether the string starts with certain characters.
   * @param {string} searchString - The characters to search for.
   * @param {number} [position] - The position in the string to start from.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {boolean} - True if the string starts with the search string.
   */
  startsWith(searchString: string, position?: number): boolean

  /**
   * @desc Determines whether the string ends with certain characters.
   * @param {string} searchString - The characters to search for.
   * @param {number} [endPosition] - The position in the string to end searching.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {boolean} - True if the string ends with the search string.
   */
  endsWith(searchString: string, endPosition?: number): boolean

  /**
   * @desc Performs a search to determine whether the calling string contains a certain substring.
   * @param {string} searchString - The characters to search for.
   * @param {number} [position] - The position in the string to start searching.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {boolean} - True if the string contains the search string.
   */
  includes(searchString: string, position?: number): boolean

  /**
   * @desc Pads the current string from the start with the specified character and length.
   * @param {number} maxLength - The length of the resulting padded string.
   * @param {string} [fillString=' '] - The string to pad with.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The padded string.
   */
  padStart(maxLength: number, fillString?: string): string

  /**
   * @desc Pads the current string from the end with the specified character and length.
   * @param {number} maxLength - The length of the resulting padded string.
   * @param {string} [fillString=' '] - The string to pad with.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The padded string.
   */
  padEnd(maxLength: number, fillString?: string): string

  /**
   * @desc Returns the current string repeated the specified number of times.
   * @param {number} count - The number of times to repeat the string.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The repeated string.
   */
  repeat(count: number): string

  /**
   * @desc Removes whitespace from the end of the string.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The trimmed string.
   */
  trimEnd(): string

  /**
   * @desc Removes whitespace from the start of the string.
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The trimmed string.
   */
  trimStart(): string

  /**
   * @desc Alias for trimStart().
   * @returns {string} -The trimmed string.
   */
  trimLeft(): string

  /**
   * @desc Alias for trimEnd().
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {string} - The trimmed string.
   */
  trimRight(): string
}

/**
 * @desc Date
 */
declare class Date {
  /**
   * @desc Creates a new Date object representing the current date and time.
   * @devices (all)
   * @apiLevel 1
   */
  constructor()

  /**
   * @desc Creates a new Date object representing the specified date and time.
   * @param {number | string | Date} value A number, string, or Date object specifying the date and time.
   * @devices (all)
   * @apiLevel 1
   */
  constructor(value: number | string | Date)

  /**
   * @desc Creates a new Date object representing the specified date and time.
   * @param {number} year The year to set.
   * @param {number} month The month to set (0-11).
   * @param {number} [day] The day to set (1-31).
   * @param {number} [hour] The hours to set (0-23).
   * @param {number} [minute] The minutes to set (0-59).
   * @param {number} [second] The seconds to set (0-59).
   * @param {number} [millisecond] The milliseconds to set (0-999).
   * @devices (all)
   * @apiLevel 1
   */
  constructor(
    year: number,
    month: number,
    day?: number,
    hour?: number,
    minute?: number,
    second?: number,
    millisecond?: number
  )

  /**
   * @desc Returns a string representation of the Date object.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} A string representation of the Date object.
   */
  toString(): string

  /**
   * @desc Returns the date portion of the Date object as a string.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} The date portion of the Date object.
   */
  toDateString(): string

  /**
   * @desc Returns the time portion of the Date object as a string.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} The time portion of the Date object.
   */
  toTimeString(): string

  /**
   * @desc Returns a locale-sensitive string representation of the Date object.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} A locale-sensitive representation of the Date object.
   */
  toLocaleString(): string

  /**
   * @desc Returns the date portion of the Date object as a locale-sensitive string.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} The date portion as a locale-sensitive string.
   */
  toLocaleDateString(): string

  /**
   * @desc Returns the time portion of the Date object as a locale-sensitive string.
   * @devices (all)
   * @apiLevel 1
   * @returns {string} The time portion as a locale-sensitive string.
   */
  toLocaleTimeString(): string

  /**
   * @desc Returns the primitive value of the Date object.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The primitive value of the Date object.
   */
  valueOf(): number

  /**
   * @desc Returns the time value in milliseconds since January 1, 1970, 00:00:00 UTC.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The time value in milliseconds.
   */
  getTime(): number

  /**
   * @desc Returns the year of the specified date according to local time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The year of the specified date.
   */
  getFullYear(): number

  /**
   * @desc Returns the year of the specified date according to universal time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The year of the specified date in UTC.
   */
  getUTCFullYear(): number

  /**
   * @desc Returns the month of the specified date according to local time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The month of the specified date (0-11).
   */
  getMonth(): number

  /**
   * @desc Returns the month of the specified date according to universal time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The month of the specified date in UTC (0-11).
   */
  getUTCMonth(): number

  /**
   * @desc Returns the day of the month for the specified date according to local time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The day of the month (1-31).
   */
  getDate(): number

  /**
   * @desc Returns the day of the month for the specified date according to universal time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The day of the month in UTC (1-31).
   */
  getUTCDate(): number

  /**
   * @desc Returns the day of the week for the specified date according to local time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The day of the week (0-6).
   */
  getDay(): number

  /**
   * @desc Returns the day of the week for the specified date according to universal time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The day of the week in UTC (0-6).
   */
  getUTCDay(): number

  /**
   * @desc Returns the hours in the specified date according to local time.
   * @devices (all)
   * @apiLevel 1
   * @returns {number} The hours (0-23).
   */
  getHours(): number

  /**
   * @desc Returns the hours in the specified date according to universal time (UTC).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The hours in UTC (0-23).
   */
  getUTCHours(): number

  /**
   * @desc Returns the minutes in the specified date according to local time.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The minutes (0-59).
   */
  getMinutes(): number

  /**
   * @desc Returns the minutes in the specified date according to universal time (UTC).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The minutes in UTC (0-59).
   */
  getUTCMinutes(): number

  /**
   * @desc Returns the seconds in the specified date according to local time.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The seconds (0-59).
   */
  getSeconds(): number

  /**
   * @desc Returns the seconds in the specified date according to universal time (UTC).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The seconds in UTC (0-59).
   */
  getUTCSeconds(): number

  /**
   * @desc Returns the milliseconds in the specified date according to local time.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds (0-999).
   */
  getMilliseconds(): number

  /**
   * @desc Returns the milliseconds in the specified date according to universal time (UTC).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds in UTC (0-999).
   */
  getUTCMilliseconds(): number

  /**
   * @desc Returns the time-zone offset in minutes for the current locale.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The time-zone offset in minutes.
   */
  getTimezoneOffset(): number

  /**
   * @desc Sets the date object to the time represented by the number of milliseconds since January 1, 1970, 00:00:00 UTC.
   * @param {number} time Time in milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The time value of the updated Date object.
   */
  setTime(time: number): number

  /**
   * @desc Sets the milliseconds for the specified date according to local time.
   * @param {number} ms Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds of the updated Date object.
   */
  setMilliseconds(ms: number): number

  /**
   * @desc Sets the milliseconds for the specified date according to universal time (UTC).
   * @param {number} ms Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds in UTC of the updated Date object.
   */
  setUTCMilliseconds(ms: number): number

  /**
   * @desc Sets the seconds for the specified date according to local time.
   * @param {number} sec Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The seconds of the updated Date object.
   */
  setSeconds(sec: number, ms?: number): number

  /**
   * @desc Sets the seconds for the specified date according to universal time (UTC).
   * @param {number} sec Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The seconds in UTC of the updated Date object.
   */
  setUTCSeconds(sec: number, ms?: number): number

  /**
   * @desc Sets the minutes for the specified date according to local time.
   * @param {number} min Minutes.
   * @param {number} [sec] Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The minutes of the updated Date object.
   */
  setMinutes(min: number, sec?: number, ms?: number): number

  /**
   * @desc Sets the minutes for the specified date according to universal time (UTC).
   * @param {number} min Minutes.
   * @param {number} [sec] Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The minutes in UTC of the updated Date object.
   */
  setUTCMinutes(min: number, sec?: number, ms?: number): number

  /**
   * @desc Sets the hours for the specified date according to local time.
   * @param {number} hours The hours.
   * @param {number} [min] Minutes.
   * @param {number} [sec] Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The hours of the updated Date object.
   */
  setHours(hours: number, min?: number, sec?: number, ms?: number): number

  /**
   * @desc Sets the hours for the specified date according to universal time (UTC).
   * @param {number} hours The hours.
   * @param {number} [min] Minutes.
   * @param {number} [sec] Seconds.
   * @param {number} [ms] Milliseconds.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The hours in UTC of the updated Date object.
   */
  setUTCHours(hours: number, min?: number, sec?: number, ms?: number): number

  /**
   * @desc Sets the day of the month for the specified date according to local time.
   * @param {number} date The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The day of the month of the updated Date object.
   */
  setDate(date: number): number

  /**
   * @desc Sets the day of the month for the specified date according to universal time (UTC).
   * @param {number} date The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The day in UTC of the updated Date object.
   */
  setUTCDate(date: number): number

  /**
   * @desc Sets the month for the specified date according to local time.
   * @param {number} month The month (0-11).
   * @param {number} [date] The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The month of the updated Date object.
   */
  setMonth(month: number, date?: number): number

  /**
   * @desc Sets the month for the specified date according to universal time (UTC).
   * @param {number} month The month (0-11).
   * @param {number} [date] The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The month in UTC of the updated Date object.
   */
  setUTCMonth(month: number, date?: number): number

  /**
   * @desc Sets the full year for the specified date according to local time.
   * @param {number} year The year.
   * @param {number} [month] The month (0-11).
   * @param {number} [date] The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The year of the updated Date object.
   */
  setFullYear(year: number, month?: number, date?: number): number

  /**
   * @desc Sets the full year for the specified date according to universal time (UTC).
   * @param {number} year The year.
   * @param {number} [month] The month (0-11).
   * @param {number} [date] The day of the month (1-31).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The year in UTC of the updated Date object.
   */
  setUTCFullYear(year: number, month?: number, date?: number): number

  /**
   * @desc Returns a string representing the specified date according to universal time (UTC).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A string representing the date in UTC.
   */
  toUTCString(): string

  /**
   * @desc Returns a string representing the specified date in ISO 8601 format.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A string in ISO 8601 format.
   */
  toISOString(): string

  /**
   * @desc Converts the Date object to a JSON string.
   * @param {any} [key] Key for JSON conversion.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A JSON string representing the Date object.
   */
  toJSON(key?: any): string

  /**
   * @desc Returns the number of milliseconds elapsed since January 1, 1970, 00:00:00 UTC to now.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds elapsed since the Unix Epoch.
   */
  static now(): number

  /**
   * @desc Parses a string representation of a date and returns the number of milliseconds since January 1, 1970, 00:00:00 UTC.
   * @param {string} s A string representation of a date.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds since the Unix Epoch.
   */
  static parse(s: string): number

  /**
   * @desc Returns the number of milliseconds since January 1, 1970, 00:00:00 UTC for a specified UTC date.
   * @param {number} year The year.
   * @param {number} month The month (0-11).
   * @param {number} [date] The day of the month (1-31).
   * @param {number} [hours] The hours (0-23).
   * @param {number} [minutes] The minutes (0-59).
   * @param {number} [seconds] The seconds (0-59).
   * @param {number} [ms] The milliseconds (0-999).
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The milliseconds since the Unix Epoch for the specified UTC date.
   */
  static UTC(
    year: number,
    month: number,
    date?: number,
    hours?: number,
    minutes?: number,
    seconds?: number,
    ms?: number
  ): number
}

/**
 * @desc The methods that an Object object possesses
 */
declare class Object {
  /**
   * @desc Creates a new Object instance.
   * @param {any} [value] The value with which to initialize the object.
   * @devices (phone, watch)
   * @apiLevel 1
   */
  constructor(value?: any)

  /**
   * @desc Returns a string representation of the object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A string representation of the object.
   */
  toString(): string

  /**
   * @desc Returns a locale-sensitive string representation of the object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A locale-sensitive representation of the object.
   */
  toLocaleString(): string

  /**
   * @desc Returns the primitive value of the specified object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Object} The primitive value of the specified object.
   */
  valueOf(): Object

  /**
   * @desc Determines whether the object has the specified property as its own property.
   * @param {PropertyKey} v The name of the property to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the object has the property as its own property; otherwise, false.
   */
  hasOwnProperty(v: PropertyKey): boolean

  /**
   * @desc Determines whether an object exists in another object's prototype chain.
   * @param {Object} v The prototype to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the prototype is in the chain; otherwise, false.
   */
  isPrototypeOf(v: Object): boolean

  /**
   * @desc Determines whether the specified property is enumerable.
   * @param {PropertyKey} v The name of the property to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the property is enumerable; otherwise, false.
   */
  propertyIsEnumerable(v: PropertyKey): boolean

  /**
   * @desc Performs primitive conversion of the object.
   * @param {"string" | "number"} hint The type of primitive conversion.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string | number} The primitive value of the object.
   */
  [Symbol.toPrimitive](hint: 'string' | 'number'): string | number

  /**
   * @desc Returns a default string description of the object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @type {string}
   */
  [Symbol.toStringTag]: string

  /**
   * @desc Copies the values of all enumerable own properties from one or more source objects to a target object.
   * @param {any} target The target object.
   * @param {...any[]} sources Source objects.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The target object.
   */
  static assign(target: any, ...sources: any[]): any

  /**
   * @desc Creates a new object with the specified prototype object and properties.
   * @param {object | null} o The object to use as the prototype.
   * @param {PropertyDescriptorMap} [properties] The properties to add to the object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The newly created object.
   */
  static create(o: object | null, properties?: PropertyDescriptorMap): any

  /**
   * @desc Defines new or modifies existing properties directly on an object.
   * @param {any} o The object on which to define or modify properties.
   * @param {PropertyDescriptorMap} properties The properties to define or modify.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The object that was passed to the function.
   */
  static defineProperties(o: any, properties: PropertyDescriptorMap): any

  /**
   * @desc Defines a new property directly on an object, or modifies an existing property.
   * @param {any} o The object on which to define or modify the property.
   * @param {PropertyKey} p The name of the property to be defined or modified.
   * @param {PropertyDescriptor} attributes The property descriptor to define or modify.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The object that was passed to the function.
   */
  static defineProperty(
    o: any,
    p: PropertyKey,
    attributes: PropertyDescriptor
  ): any

  /**
   * @desc Returns an array of a given object's own enumerable string-keyed property [key, value] pairs.
   * @param {any} o The object on which to get the entries.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {[string, any][]} An array of the object's own enumerable property [key, value] pairs.
   */
  static entries(o: any): [string, any][]

  /**
   * @desc Freezes an object, preventing new properties from being added and marking existing properties as non-configurable.
   * @param {T} o The object to freeze.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Readonly<T>} The frozen object.
   */
  static freeze<T>(o: T): Readonly<T>

  /**
   * @desc Returns a new object from an iterable of key-value pairs.
   * @param {Iterable<readonly any[]>} entries The iterable of key-value pairs.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The new object composed from the key-value pairs.
   */
  static fromEntries(entries: Iterable<readonly any[]>): any

  /**
   * @desc Returns a property descriptor for a named property on an object.
   * @param {any} o The object on which to get the property descriptor.
   * @param {PropertyKey} p The name of the property.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {PropertyDescriptor | undefined} The property descriptor for the named property, or undefined if there is no such property.
   */
  static getOwnPropertyDescriptor(
    o: any,
    p: PropertyKey
  ): PropertyDescriptor | undefined

  /**
   * @desc Returns an object containing all own property descriptors of an object.
   * @param {any} o The object on which to get the property descriptors.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {PropertyDescriptorMap} An object containing all own property descriptors of the object.
   */
  static getOwnPropertyDescriptors(o: any): PropertyDescriptorMap

  /**
   * @desc Returns an array of all own property names (string keys) of an object.
   * @param {any} o The object from which to retrieve property names.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string[]} An array of the object's own property names.
   */
  static getOwnPropertyNames(o: any): string[]

  /**
   * @desc Returns an array of all own property symbols of an object.
   * @param {any} o The object from which to retrieve property symbols.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {symbol[]} An array of the object's own property symbols.
   */
  static getOwnPropertySymbols(o: any): symbol[]

  /**
   * @desc Returns the prototype (internal [[Prototype]]) of the specified object.
   * @param {any} o The object whose prototype is to be returned.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The prototype of the specified object.
   */
  static getPrototypeOf(o: any): any

  /**
   * @desc Determines if two values are the same value.
   * @param {any} value1 The first value to compare.
   * @param {any} value2 The second value to compare.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the values are the same, false otherwise.
   */
  static is(value1: any, value2: any): boolean

  /**
   * @desc Determines if an object is extensible, meaning new properties can be added to it.
   * @param {any} o The object to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the object is extensible, false otherwise.
   */
  static isExtensible(o: any): boolean

  /**
   * @desc Determines if an object is frozen, meaning no new properties can be added and existing properties cannot be changed.
   * @param {any} o The object to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the object is frozen, false otherwise.
   */
  static isFrozen(o: any): boolean

  /**
   * @desc Determines if an object is sealed, meaning new properties cannot be added and existing properties cannot be deleted.
   * @param {any} o The object to test.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the object is sealed, false otherwise.
   */
  static isSealed(o: any): boolean

  /**
   * @desc Returns an array of all own enumerable property names (string keys) of an object.
   * @param {any} o The object from which to retrieve keys.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string[]} An array of the object's own enumerable property keys.
   */
  static keys(o: any): string[]

  /**
   * @desc Prevents new properties from being added to an object, making it non-extensible.
   * @param {T} o The object to make non-extensible.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {T} The non-extensible object.
   */
  static preventExtensions<T>(o: T): T

  /**
   * @desc Seals an object, preventing new properties from being added and marking all existing properties as non-configurable.
   * @param {T} o The object to seal.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {T} The sealed object.
   */
  static seal<T>(o: T): T

  /**
   * @desc Sets the prototype (internal [[Prototype]]) of a specified object to another object or null.
   * @param {any} o The object whose prototype is to be set.
   * @param {any} proto The new prototype for the object.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The object after setting its prototype.
   */
  static setPrototypeOf(o: any, proto: any): any

  /**
   * @desc Returns an array of values of the enumerable properties of an object.
   * @param {any} o The object from which to retrieve values.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any[]} An array of property values from the object.
   */
  static values(o: any): any[]
}

/**
 * @desc Methods available in the JSON object
 */
declare const JSON: {
  /**
   * @desc Parses a JSON-formatted string and returns the corresponding JavaScript value or object.
   * @param {string} jsonString A string in JSON format.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {any} The JavaScript value or object resulting from parsing the JSON string.
   */
  parse(jsonString: string): any

  /**
   * @desc Converts a JavaScript value or object to a JSON-formatted string.
   * @param {any} value The value or object to convert to JSON.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} The JSON-formatted string representation of the input value.
   */
  stringify(value: any): string
}

/**
 * @desc Uint8Array
 */
declare class Uint8Array {
  /**
   * @desc Creates a new Uint8Array from an array-like or iterable object.
   * @param {ArrayLike<number>} arrayLike An array-like or iterable object to convert.
   * @devices (phone, watch)
   * @apiLevel 1
   * @static
   * @returns {Uint8Array} A new Uint8Array instance.
   */
  static from(arrayLike: ArrayLike<number>): Uint8Array

  /**
   * @desc Creates a new Uint8Array from a variable number of arguments.
   * @param {number[]} items Elements to include in the new Uint8Array.
   * @devices (phone, watch)
   * @apiLevel 1
   * @static
   * @returns {Uint8Array} A new Uint8Array instance.
   */
  static of(...items: number[]): Uint8Array

  /**
   * @desc Constructs a new Uint8Array. The array's contents depends on the given input.
   * @param {any} value The value to initialize the array with.
   * @devices (phone, watch)
   * @apiLevel 1
   */
  constructor(value?: any)

  /**
   * @desc Gets the length of the Uint8Array.
   * @type {number}
   * @devices (phone, watch)
   * @apiLevel 1
   */
  readonly length: number

  /**
   * @desc Gets the number of bytes per element in the Uint8Array.
   * @type {number}
   * @devices (phone, watch)
   * @apiLevel 1
   */
  readonly BYTES_PER_ELEMENT: number;

  /**
   * @desc Accesses the element at the given index.
   * @param {number} index The index of the element.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The element at the specified index.
   */
  [index: number]: number

  /**
   * @desc Copies a sequence of array elements within the array.
   * @param {number} target The index to copy the elements to.
   * @param {number} start The index to start copying elements from.
   * @param {number} [end] The index to end copying elements, non-inclusive.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} The Uint8Array with the modified data.
   */
  copyWithin(target: number, start: number, end?: number): Uint8Array

  /**
   * @desc Tests whether all elements pass the provided function.
   * @param {(value: number, index: number, array: Uint8Array) => boolean} callbackfn Function to test each element.
   * @param {any} [thisArg] Value to use as `this` when executing callbackfn.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if all elements pass the test, otherwise false.
   */
  every(
    callbackfn: (value: number, index: number, array: Uint8Array) => boolean,
    thisArg?: any
  ): boolean

  /**
   * @desc Fills elements of the array with a static value.
   * @param {number} value Value to fill the array with.
   * @param {number} [start] Start index, default is 0.
   * @param {number} [end] End index, non-inclusive, default is array's length.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} The Uint8Array with the modified data.
   */
  fill(value: number, start?: number, end?: number): Uint8Array

  /**
   * @desc Finds the first element satisfying the provided function.
   * @param {(value: number, index: number, obj: Uint8Array) => boolean} predicate Function to execute on each element.
   * @param {any} [thisArg] Value to use as `this` when executing predicate.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number | undefined} The found element, or undefined if not found.
   */
  find(
    predicate: (value: number, index: number, obj: Uint8Array) => boolean,
    thisArg?: any
  ): number | undefined

  /**
   * @desc Finds the index of the first element satisfying the function.
   * @param {(value: number, index: number, obj: Uint8Array) => boolean} predicate Function to execute on each element.
   * @param {any} [thisArg] Value to use as `this` when executing predicate.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The index of the found element, or -1 if not found.
   */
  findIndex(
    predicate: (value: number, index: number, obj: Uint8Array) => boolean,
    thisArg?: any
  ): number

  /**
   * @desc Executes a provided function once for each array element.
   * @param {(value: number, index: number, array: Uint8Array) => void} callbackfn Function to execute on each element.
   * @param {any} [thisArg] Value to use as `this` when executing callbackfn.
   * @devices (phone, watch)
   * @apiLevel 1
   */
  forEach(
    callbackfn: (value: number, index: number, array: Uint8Array) => void,
    thisArg?: any
  ): void

  /**
   * @desc Determines whether the array includes a certain element.
   * @param {number} searchElement Element to search for.
   * @param {number} [fromIndex] Index to start the search at.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if the element is found, otherwise false.
   */
  includes(searchElement: number, fromIndex?: number): boolean

  /**
   * @desc Returns the first index of the element in the array, or -1 if not present.
   * @param {number} searchElement Element to locate.
   * @param {number} [fromIndex] Index to start the search at.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The index of the element or -1.
   */
  indexOf(searchElement: number, fromIndex?: number): number

  /**
   * @desc Joins all elements of the array into a string.
   * @param {string} [separator] Specifies a string to separate each pair of adjacent elements.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {string} A string with all array elements joined.
   */
  join(separator?: string): string

  /**
   * @desc Returns an iterable of keys in the array.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {IterableIterator<number>} An iterator of keys.
   */
  keys(): IterableIterator<number>

  /**
   * @desc Returns the last index of an element in the array, or -1 if not present.
   * @param {number} searchElement Element to locate.
   * @param {number} [fromIndex] Index to start the search backward.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The index of the element or -1.
   */
  lastIndexOf(searchElement: number, fromIndex?: number): number

  /**
   * @desc Creates a new array with the results of calling a function on every element.
   * @param {(value: number, index: number, array: Uint8Array) => number} callbackfn Function to be called on each element.
   * @param {any} [thisArg] Value to use as `this` when executing callbackfn.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} A new Uint8Array with each element being the result of the callback function.
   */
  map(
    callbackfn: (value: number, index: number, array: Uint8Array) => number,
    thisArg?: any
  ): Uint8Array

  /**
   * @desc Applies a function against an accumulator and each element (from left to right) to reduce to a single value.
   * @param {function} callbackfn A function to execute on each element.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The single value that results from the reduction.
   */
  reduce(
    callbackfn: (
      previousValue: number,
      currentValue: number,
      currentIndex: number,
      array: Uint8Array
    ) => number
  ): number

  /**
   * @desc Applies a function against an accumulator and each element (from right to left) to reduce to a single value.
   * @param {function} callbackfn A function to execute on each element.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {number} The single value that results from the reduction.
   */
  reduceRight(
    callbackfn: (
      previousValue: number,
      currentValue: number,
      currentIndex: number,
      array: Uint8Array
    ) => number
  ): number

  /**
   * @desc Reverses the elements of the array in place.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} The reversed Uint8Array.
   */
  reverse(): Uint8Array

  /**
   * @desc Sets values from another array into this Uint8Array, at the specified offset.
   * @param {ArrayLike<number>} array The array from which to copy values.
   * @param {number} [offset] The index in this array at which to start writing.
   * @devices (phone, watch)
   * @apiLevel 1
   */
  set(array: ArrayLike<number>, offset?: number): void

  /**
   * @desc Returns a shallow copy of a portion of the array into a new Uint8Array.
   * @param {number} [start] Zero-based index at which to start extraction.
   * @param {number} [end] Zero-based index before which to end extraction.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} A new Uint8Array containing the extracted elements.
   */
  slice(start?: number, end?: number): Uint8Array

  /**
   * @desc Tests whether at least one element passes the provided function.
   * @param {function} callbackfn A function to test each element.
   * @param {any} [thisArg] Value to use as `this` when executing callbackfn.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {boolean} True if at least one element passes the test; otherwise, false.
   */
  some(
    callbackfn: (value: number, index: number, array: Uint8Array) => boolean,
    thisArg?: any
  ): boolean

  /**
   * @desc Sorts the elements of the array in place.
   * @param {function} [compareFn] Function that defines the sort order.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} The sorted Uint8Array.
   */
  sort(compareFn?: (a: number, b: number) => number): Uint8Array

  /**
   * @desc Returns a new Uint8Array containing elements between the specified begin and end indices.
   * @param {number} [begin] The zero-based index at which to start the subarray.
   * @param {number} [end] The zero-based index before which to end the subarray, non-inclusive.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {Uint8Array} A new Uint8Array holding the specified elements.
   */
  subarray(begin?: number, end?: number): Uint8Array

  /**
   * @desc Returns an iterator object containing the values for each index in the array.
   * @devices (phone, watch)
   * @apiLevel 1
   * @returns {IterableIterator<number>} An iterator for the array values.
   */
  values(): IterableIterator<number>
}

/**
 * @desc Array
 */
declare const Array: typeof Array

/**
 * @desc Promise
 */
declare const Promise: typeof Promise
