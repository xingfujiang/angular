/**
 * Health
 * Interface declaration: { "name": "blueos.health.health" }
 */
declare module "@blueos.health.health" {
  /**
   * @desc The supported data types can be:AVERAGE,SUM,MAX,MIN
   */
  const STATISTIC_TYPES: Record<any, any>;

  /**
   * @desc he supported data types can be:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  const DATA_TYPES: Record<any, any>;
  /**
   * @desc 	Obtain the most recent sampling data
   * @param {getRecentSamplesParams}options- Get input parameters for the most recent sampling data 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data> | void}
   */
  export function getRecentSamples(
    options: getRecentSamplesParams
  ): Promise<Data> | void;

  /**
   * @desc 	Monitor sampling data changes
   * @param {subscribeSampleParams}options- Listen to sampling data changes with input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeSample: (options: subscribeSampleParams) => void;

  /**
   * @desc 	Cancel sampling data changes
   * @devices (phone,watch)
   * @param {unsubscribeSampleParams}options- Listen Cancel sampling data changes input parameters
   * @apiLevel 1
   */
  const unsubscribeSample: (options: unsubscribeSampleParams) => void;

  /**
   * @desc 	Query today's statistical data
   * @param {getTodayStatisticParams}options- Input parameters for querying today's statistical data 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<string>> | void}
   */
  export function getTodayStatistic(
    options: getTodayStatisticParams
  ): Promise<Array<string>> | void;

  /**
   * @desc 	Query today's statistical data
   * @param {getStatisticParams}options- Input parameters for querying today's statistical data 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<string>> | void}
   */
  export function getStatistic(
    options: getStatisticParams
  ): Promise<Array<string>> | void;

  /**
   * @desc 	Monitor today's statistical data
   * @param {subscribeTodayStatisticParams}options- Input parameters for monitoring today's statistical data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeTodayStatistic: (
    options: subscribeTodayStatisticParams
  ) => void;

  /**
   * @desc 	Cancel monitoring of today's statistical data.
   * @param {unsubscribeTodayStatisticParams}options- Input parameters for canceling monitoring of today's statistical data 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeTodayStatistic: (
    options: unsubscribeTodayStatisticParams
  ) => void;
}

/**
 *   @desc Return value
 */
declare interface DataTypeValue {
  /**
   *   @desc Sampling time
   */
  timeStamp: number;
  /**
   *   @desc The specific data value of the queried dataType, with the value type determined by the dataType
   */
  value: any;
}

/**
 *   @desc Return value
 */
declare interface Data {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
  /**
   *   @desc data
   */
  data: DataTypeValue;
}

/**
 * @desc input parameters
 */
declare interface getRecentSamplesParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: Array<string>;

  /**
   * @desc success callback
   * @param {Data}data- sampling data 
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface subscribeSampleParams {
  /**
   * @desc data type
   */
  dataType: number;

  /**
   * 	@desc callback function
   * 	@param {Array<string>} data -return value of the callback
   */
  callback: (data: Array<string>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface unsubscribeSampleParams {
  /**
   * @desc data type
   */
  dataType: number;
}

/**
 * @desc input parameters
 */
declare interface getTodayStatisticParams {
  /**
   *   @desc data type
   */
  dataType: number;
  /**
   *   @desc The dimensions of statistics vary by manufacturer, and different dataTypes support different dimensions
   */
  statisticType: string;
  /**
   * @desc success callback
   * @param {Array<string>}data- sampling data 
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface getStatisticParams {
  /**
   *   @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
  /**
   *   @desc Dimensions of statistics, with some data types supporting detailed statistical chart data
   */
  statisticType: string;

  /**
   *   @desc Start time: Activities that occur after this time are included, as well as activities that began before this time period but have not yet ended
   */
  startTime: number;

  /**
   *   @desc End time: Activities that occur before this time are included, as well as activities that are ongoing but not yet fully completed
   */
  endTime: number;
  /**
   * @desc success callback
   * @param {Array<string>}data- sampling data 
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface subscribeTodayStatisticParams {
  /**
   * @desc The dimensions of statistics vary by manufacturer, and different data types support different dimensions
   */
  statisticType: number;
  /**
   * @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;

  /**
   * 	@desc callback function
   * 	@param {Array<string>}data- return value of the callback
   */
  callback: (data: Array<string>) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface unsubscribeTodayStatisticParams {
  /**
   * @desc Data type, possible values:HEART_RATE、HEART_RATE_STEP、HEART_RATE_RESTING、STANDING、INTENSITY_SPORT、STEP_COUNT、SPO2、DISTANCE、CALORIES、STRESS、WALKING_SPEED、SLEEP_UNIT、SLEEP_STAGES、SLEEP_STATUS、ENERGY、WALKING_STATUS、SPEED
   */
  dataType: number;
}
