/**
 * Wi-Fi P2P (Peer-to-Peer) is a module used for managing Wi-Fi P2P functionality, including features such as device discovery, group creation, group joining, and monitoring device changes
 * Interface declaration: { "name": "blueos.wifi.p2p" }
 */
declare module "@blueos.wifi.p2p" {
  /**
   * @desc Obtain device connection information
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {getConnectionInfoParams}options-Successful callback return value 
   * @returns {Promise<ConnectionInfo> | void}
   */

  export function getConnectionInfo(
    options?: getConnectionInfoParams
  ): Promise<ConnectionInfo> | void;

  /**
   * @desc Check if the Wi-Fi P2P is enabled
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {boolean}
   */
  const isEnabled: () => boolean;

  /**
   * @desc Check if Wi-Fi P2P is currently in device discovery mode
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {boolean}
   */
  const isInDiscovery: () => boolean;

  /**
   * @desc Create a P2P group with the current device as the group owner
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {createGroupParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function createGroup(options: createGroupParams): Promise<void> | void;

  /**
   * @desc Disband the current group or leave the current group
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {removeGroupParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */
  export function removeGroup(
    options?: removeGroupParams
  ): Promise<void> | void;

  /**
   * @desc Get current group information.
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {getGroupInfoParams}options- Input parameter 
   * @returns {Promise<GroupInfo> | void}
   */
  export function getGroupInfo(
    options?: getGroupInfoParams
  ): Promise<GroupInfo> | void;

  /**
   * @desc Start P2P peer discovery. Scan for available peer devices to establish a connection
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {startDiscoveryParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function startDiscovery(
    options?: startDiscoveryParams
  ): Promise<void> | void;

  /**
   * @desc Stop the ongoing P2P peer discovery
   * @param {stopDiscoveryParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */

  export function stopDiscovery(
    options?: stopDiscoveryParams
  ): Promise<void> | void;
}

/**
 * @desc MAC address type of the device
 */
declare enum ScopeType {
  /**
   * @desc Full-range scan.
   */
  ALL = 0,
  /**
   * @desc Scan only social channels. In the 2.4 GHz band, these are the three channels (1, 6, 11) reserved by the Wi-Fi Alliance for Wi-Fi Direct and P2P communication
   */
  SOCIAL = 1,
}

/**
 * @desc Retrieve current group information
 */
declare interface GroupInfo {
  /**
   * @desc Group SSID, also known as the group name
   */
  ssid: string;
  /**
   * @desc Is the current device the group owner？
   */
  isGroupOwner: boolean;
  /**
   * @desc Is the current group a persistent group?
   */
  isPersistent: boolean;
  /**
   * @desc Operating frequency of the current group (in MHz).
   */
  frequency: number;
  /**
   * @desc Group key, returned only when the current device is the group owner; otherwise, it returns empty if the current device is not the group owner
   */
  passphrase: string;
}

/**
 * @desc Device connection information
 */
declare interface ConnectionInfo {
  /**
   * @desc Current device connection status
   */
  state: ConnectionState;
  /**
   * @desc Is the current device the group owner?
   */
  isGroupOwner: boolean;
  /**
   * @desc Group owner MAC address
   */
  groupOwnerAddress: string;
}

/**
 * @desc Wi-Fi security authentication method
 */
declare enum WifiBand {
  /**
   * @desc Auto-select
   */
  AUTO = 0,
  /**
   * @desc 2.4GHZ
   */
  "2.4GHZ" = 1,
  /**
   * @desc 5GHZ
   */
  "5GHZ" = 2,
}

/**
 * @desc Current device connection status
 */
declare enum ConnectionState {
  /**
   * @desc Disconnect
   */
  DISCONNECTED = 0,
  /**
   * @desc Connecting
   */
  CONNECTING = 1,
  /**
   * @desc Connected
   */
  CONNECTED = 2,
  /**
   * @desc Available
   */
  AVAILABLE = 3,
  /**
   * @desc Unavailable
   */
  UNAVAILABLE = 4,
  /**
   * @desc Invited
   */
  INVITED = 5,
  /**
   * @desc Failed to connect
   */
  FAILE = 6,
}

/**
 * @desc Input parameter
 */
declare interface getConnectionInfoParams {
  /**
   * @desc success callback
   * @param {ConnectionInfo} data- success callback return value 
   */
  success?: (data: ConnectionInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface createGroupParams {
  /**
   * @desc Group SSID, the name of the group to be created or joined
   */
  ssid: string;
  /**
   * @desc Operating frequency band for creating or joining a group
   */
  groupBand: WifiBand;
  /**
   * @desc Flag for creating a persistent group when forming a group; default is no
   */
  isPersistent?: boolean;
  /**
   * @desc Password for creating or joining a group
   */
  passphrase?: string;
  /**
   * @desc Peer device MAC address. When performing a P2P connection, either the SSID or the peerAddress must be provided
   */
  peerAddress?: string;
  /**
   * @desc Successful callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface removeGroupParams {
  /**
   * @desc Successful callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface getGroupInfoParams {
  /**
   * @desc Successful callback
   * @param {GroupInfo}data- return value of the failure callback 
   */
  success?: (data: GroupInfo) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface startDiscoveryParams {
  /**
   * @desc Scan type, default value is ScopeType.ALL
   */
  scope?: ScopeType;
  /**
   * @desc Custom frequency value, in MHz. Once this field is defined, the scope field becomes invalid
   */
  frequency?: number;
  /**
   * @desc Successful callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface stopDiscoveryParams {
  /**
   * @desc Successful callback
   */
  success?: () => void;
    /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
