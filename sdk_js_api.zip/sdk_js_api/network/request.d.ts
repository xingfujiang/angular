/**
 * Upload and download
 * Interface declaration: {"name": "blueos.network.request"}
 */
declare module "@blueos.network.request" {
  /**
   * @desc Upload file.
   * @param {uploadParams}options- File upload parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<SuccessData> | void}
   */
  export function upload(options: uploadParams): Promise<SuccessData> | void;

  /**
   * 	@desc Download file.
   *  @param {downloadParams}options- Parameters for file download 
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<TokenData> | void}
   */

  export function download(options: downloadParams): Promise<TokenData> | void;

  /**
   * 	@desc Monitor download task
   *  @param {onDownloadCompleteParams}options- Parameters for monitoring download tasks 
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<UriData> | void}
   */

  export function onDownloadComplete(
    options: onDownloadCompleteParams
  ): Promise<UriData> | void;

  /**
   * 	@desc Interrupt download task
   *  @param {abortDownloadParams}options- Parameters for interrupting a download task
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<void> | void}
   */
  export function abortDownload(
    options: abortDownloadParams
  ): Promise<void> | void;
}

/**
 * @desc Input parameter
 */
declare interface uploadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all of its properties will be set in the request's header section.
   */
  header?: Record<string, any>;
  /**
   * @desc The default is POST; it can be: POST, PUT
   */
  method?: string;
  /**
   * @desc List of files to be uploaded, submitted using multipart/form-data
   */
  files: Array<FilesArry>;
  /**
   * @desc Additional form data in the HTTP request
   */
  data?: Array<DataArry>;
  /**
   * @desc Successful callback
   * @param {SuccessData}data- success callback return value 
   */
  success?: (data: SuccessData) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface FilesArry {
  /**
   * @desc Filename in the header when submitting multipart
   */
  filename?: string;
  /**
   * @desc Form item name for multipart submission, default is "file"
   */
  name?: string;
  /**
   * @desc Local address of the file
   */
  uri: string;
  /**
   * @desc Content-Type format of the file, which will be determined by the extension of the filename or URI by default
   */
  type?: string;
}

/**
 * @desc Input parameter
 */
declare interface DataArry {
  /**
   * @desc Name of the form element
   */
  name: string;
  /**
   * @desc Value of the form element
   */
  value: string;
}

/**
 * @desc Input parameter
 */
declare interface SuccessData {
  /**
   * @desc Server status code
   */
  code: number;
  /**
   * @desc If the type in the server's returned header is text/*, application/json, application/javascript, or application/xml, the value is text content. Otherwise, it is the URI of a stored temporary file. If the temporary file is an image or video content, it can be set to display on an image or video control
   */
  data: string;
  /**
   * @desc All headers of the server response
   */
  headers: Record<string, any>;
}

/**
 * @desc Input parameter
 */
declare interface downloadParams {
  /**
   * @desc Resource URL
   */
  url: string;
  /**
   * @desc Request headers, where all properties will be set in the request's header section. User-Agent setting is supported starting from version 1040
   */
  header?: string;
  /**
   * @desc Download description, used for the notification bar title. Defaults to the filename
   */
  description?: string;
  /**
   * @desc Download filename. By default, it is obtained from the network request or URL
   */
  filename?: string;
  /**
   * @desc success callback
   * @param {TokenData}data- success callback return value
   */
  success?: (data: TokenData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface TokenData {
  /**
   * @desc Download token, used to obtain the download status
   */
  token: string;
}

/**
 * @desc Input parameter
 */
declare interface onDownloadCompleteParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
  /**
   * @desc success callback
   * @param {UriData}data- success callback return value
   */
  success?: (data: UriData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface UriData {
  /**
   * @desc URI of the downloaded file
   */
  uri: string;
}

/**
 * @desc Input parameter
 */
declare interface abortDownloadParams {
  /**
   * @desc Token returned by the download interface
   */
  token: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
