/**
 * WebSocket
 * Interface declaration:{"name": "blueos.network.webSocket"}
 */
declare module '@blueos.network.webSocket' {
  /**
   * @desc Create a WebSocket instance.
   * @param {createParams}options- Input parameters for creating a WebSocket instance
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {CreateInstance}
   */
  const create: (options: createParams) => CreateInstance
}

/**
 * @desc Input parameter
 */
declare interface createParams {
  /**
   *  @desc Request URL, must be using the wss or ws protocol
   */
  url: string
  /**
   *  @desc Request headers, where Referer and User-Agent cannot be set in the header
   */
  header?: Record<string, any>
  /**
   *  @desc Subprotocol group
   */
  protocols?: string[]
}

/**
 * @desc Input parameter
 */
declare interface PromiseSendDataParams {
  /**
   * @desc Sent message
   */
  data: string | ArrayBuffer
}

/**
 * @desc Input parameter
 */
declare interface SendDataParams {
  /**
   * @desc Sent message
   */
  data: string | ArrayBuffer
  /**
   * @desc Successful callback
   */
  success?: () => void
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void
}

/**
 * @desc Input parameter
 */
declare interface PromiseCloseParams {
  /**
   * @desc Connection close status code, default is 1000
   */
  code?: number
  /**
   * @desc Reason for closure
   */
  reason?: string
}

/**
 * @desc Input parameter
 */
declare interface CloseParams {
  /**
   * @desc Connection close status code, default is 1000
   */
  code?: number
  /**
   * @desc Reason for closure
   */
  reason?: string
  /**
   * @desc Successful callback
   */
  success?: () => void
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void
}

/**
 * @desc Return value
 */
declare interface MessageData {
  /**
   * @desc Message received by the listener; the message type is consistent with the sent type
   */
  data: string | ArrayBuffer
}

/**
 * @desc Input parameter
 */
declare interface OnCloseParams {
  /**
   * @desc Status code returned by the server upon closure
   */
  code: number
  /**
   * @desc Reason for closure returned by the server
   */
  reason: string
  /**
   * @desc Was the closure normal?
   */
  wasClean: boolean
}

/**
 * @desc Input parameter
 */
declare interface OnErrorParams {
  /**
   * @desc Message received by the listener
   */
  data: string
}

/**
 * @desc Create instance
 */
declare interface CreateInstance {
  /**
   * @desc Send data to the server
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {SendDataParams}options- Input parameters for sending data to the server
   */
  send(options: SendDataParams): void

  /**
   * @desc Send data to the server
   * @param {PromiseSendDataParams}options- Input parameters for sending data to the server
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  send(options: PromiseSendDataParams): Promise<void>

  /**
   * @desc Close the current connection
   * @param {CloseParams}options- Input parameters for closing the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   */
  close(options: CloseParams): void

  /**
   * @desc Close the current connection
   * @param {PromiseCloseParams}options- Input parameters for closing the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  close(options: PromiseCloseParams): Promise<void>

  /**
   * @desc Used to specify the callback function after a successful connection
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onOpen: () => void

  /**
   * @desc Used to specify the callback function when a message is received from the server
   * @param {MessageData}data- Used to specify the return value of the callback function when a message is received from the server
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onMessage: (data: MessageData) => void

  /**
   * @desc Used to specify the callback function after the connection is closed
   * @param {OnCloseParams}data- Used to specify the return value of the callback function after the connection is closed
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onClose: (data: OnCloseParams) => void

  /**
   *  @desc Used to specify the callback function after a connection failure
   *  @param {OnErrorParams}data- Used to specify the return value of the callback function after a connection failure
   *  @devices (phone,watch)
   *  @apiLevel 2
   */
  onError: (data: OnErrorParams) => void
}
