/**
 * database
 * Interface declaration: { "name": "blueos.storage.relationaldatabase" }
 */
declare module '@blueos.storage.relationaldatabase' {
  /**
   * @desc create a database instance
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {InstanceDatabaseParams}options- input parameters for creating a database instance
   * @requires{DbConnection}
   */
  const instanceDatabase: (options: InstanceDatabaseParams) => DbConnection
}

/**
 * @desc database object
 */
declare interface DbConnection {
  /**
   * @desc transaction
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {CallbackFn}callback- input parameters
   */
  transaction: (callback: CallbackFn) => void

  /**
   * @desc execute statement
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {RawQueryParams}options- input parameters for executing statement
   */
  rawQuery(options: RawQueryParams): void

  /**
   * @desc execute statement
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {PromiseRawQueryParams}options- input parameters for executing statement
   * @returns {Promise<any[]>}
   */
  rawQuery(options: PromiseRawQueryParams): Promise<any[]>

  /**
   * @desc execute statement
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ExecSQLParams}options- input parameters for executing statement
   */
  execSQL(options: ExecSQLParams): void

  /**
   * @desc execute statement
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {PromiseExecSQLParams}options- input parameters for executing statement
   * @returns {Promise<any[]>}
   */
  execSQL(options: PromiseExecSQLParams): Promise<any[]>
  /**
   * @desc placeholder
   */
  [key: string]: Repository | any
}

/**
 * @desc Repository
 */
declare interface Repository {
  /**
   * @desc Return a single piece of data based on a unique constraint or primary key. If the query condition is not based on a unique constraint or primary key, the operation will fail
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {QueryOption}query- input parameters
   * @returns {any}
   */
  findOne: (query: QueryOption) => any

  /**
   * @desc Return the first record that matches the given condition
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {QueryOption}query- input parameters
   * @returns {any}
   */
  findFirst: (query: QueryOption) => any

  /**
   * @desc Return a list of entity records that match the given condition
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {QueryOption}query- input parameters
   * @returns {any[]}
   */
  findMany: (query: QueryOption) => any[]

  /**
   * @desc Create a new database record and return the newly created record
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {CreateDataParams}options- input parameters
   * @returns {any}
   */
  create: (options: CreateDataParams) => any

  /**
   * @desc Create multiple records within a transaction and return the number of records created
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {CreateManyDataParams}options- input parameters
   * @returns {CountData}
   */
  createMany: (options: CreateManyDataParams) => CountData

  /**
   * @desc Update a database record based on a unique constraint and return the updated record
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {UpdateOneDataParams}options- input parameters
   * @returns {any}
   */
  updateOne: (options: UpdateOneDataParams) => any

  /**
   * @desc Batch update existing database records based on the given condition and return the number of records updated
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {UpdateManyDataParams}options- input parameters
   * @returns {CountData}
   */
  updateMany: (options: UpdateManyDataParams) => CountData

  /**
   * @desc Delete a database record based on a unique constraint or primary key and return the deleted record. The operation fails if it is not based on a unique constraint or primary key
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {DeleteOneDataParams}options- input parameters
   * @returns {any}
   */
  deleteOne: (options: DeleteOneDataParams) => any

  /**
   * @desc Delete multiple records based on the given condition and return the number of records deleted
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {DeleteManyDataParams}options- input parameters
   * @returns {CountData}
   */
  deleteMany: (options: DeleteManyDataParams) => CountData

  /**
   * @desc Count the number of records that meet the given condition.
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {QueryOption}query- input parameters
   * @returns {number}
   */
  count: (query: QueryOption) => number

  /**
   * @desc execute statement
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {any}options- input parameters
   */
  groupBy: (options: any) => void
}

/**
 * @desc input parameter
 */
declare interface QueryOption {
  /**
   * @desc conditional operator WhereOption
   */
  where?: object
  /**
   * @desc which fields are included in the returned object
   */
  select?: object
  /**
   * @desc The return result includes relationship values: add the specified properties with include on the Entity.
   */
  include?: object
  /**
   * @desc Sort the list of records: asc for ascending order, desc for descending order.
   */
  orderBy?: object
  /**
   * @desc remove duplicates from the list of records
   */
  distinct?: any[]
}

/**
 * @desc input parameter
 */
declare interface InstanceDatabaseParams {
  /**
   * @desc name the database
   */
  name?: string
  /**
   * @desc path
   */
  path?: any
  /**
   * @desc entity
   */
  entity: any[]
  /**
   * @desc Enable logging?
   */
  log?: boolean
  /**
   * @desc Version number
   */
  version?: number
}

/**
 * @desc input parameter
 */
declare interface PromiseRawQueryParams {
  /**
   * @desc SQL statement
   */
  sql: string
  /**
   * @desc Placeholder data to be filled in when there are placeholders
   */
  replacements?: Map<string, string>
}

/**
 * @desc input parameter
 */
declare interface RawQueryParams {
  /**
   * @desc SQL statement
   */
  sql: string
  /**
   * @desc Placeholder data to be filled in when there are placeholders
   */
  replacements?: Map<string, string>
  /**
   * @desc success callback
   * @param {any[]}list- callback function return value
   */
  success?: (list: any[]) => void
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void
}

/**
 * @desc input parameter
 */
declare interface PromiseExecSQLParams {
  /**
   * @desc SQL statement
   */
  sql: string
  /**
   * @desc Placeholder data to be filled in when there are placeholders
   */
  replacements?: Map<string, string>
}

/**
 * @desc input parameter
 */
declare interface ExecSQLParams {
  /**
   * @desc SQL statement
   */
  sql: string
  /**
   * @desc Placeholder data to be filled in when there are placeholders
   */
  replacements?: Map<string, string>
  /**
   * @desc success callback
   * @param {any[]}list- callback function return value
   */
  success?: (list: any[]) => void
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void
}

/**
 * @desc input parameter
 */
declare interface CreateDataParams {
  /**
   * @desc Conditional statement
   */
  data: any
}

/**
 * @desc input parameter
 */
declare interface CreateManyDataParams {
  /**
   * @desc Conditional statement
   */
  data: any[]
}

/**
 * @desc input parameter
 */
declare interface UpdateOneDataParams {
  /**
   * @desc Conditional statement
   */
  where: any
  /**
   * @desc Conditional statement
   */
  data: any
}

/**
 * @desc input parameter
 */
declare interface UpdateManyDataParams {
  /**
   * @desc Conditional statement
   */
  where: any
  /**
   * @desc Conditional statement
   */
  data: any[]
}

/**
 * @desc Return value
 */
declare interface CountData {
  /**
   * @desc Number of items
   */
  count: number
}

/**
 * @desc input parameter
 */
declare interface DeleteOneDataParams {
  /**
   * @desc Conditional statement
   */
  where: any
}

/**
 * @desc input parameter
 */
declare interface DeleteManyDataParams {
  /**
   * @desc Conditional statement
   */
  where: any
}

/**
 * @desc input parameter
 */
declare interface CallbackFn {
  /**
   * @desc function
   * @param {DbConnection}tx- input parameter
   */
  (tx: DbConnection): void
}
