/**
 * Key-value format data storage
 * Interface declaration: {"name": "blueos.storage.storage"}
 */
declare module "@blueos.storage.storage" {
  /**
   * @desc The number of data items in the storage
   */
  const length: number;

  /**
   * @desc Read storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {GetStorageParams}options- Input parameter 
   * @returns {Promise<any> | void}
   */

  export function get(options: GetStorageParams): Promise<any> | void;

  /**
   * @desc Set storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {SetStorageParams}options- Input parameter
   * @returns {Promise<void>}
   */

  export function set(options: SetStorageParams): Promise<void> | void;

  /**
   * @desc Clear storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {ClearStorageParams}options- Input parameter
   * @returns {Promise<void> | void}
   */

  export function clear(options?: ClearStorageParams): Promise<void> | void;

  /**
   * @desc Delete storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {DelStorageParams}options- Input parameter  
   * @returns {Promise<any> | void}
   */
  function del(options: DelStorageParams): Promise<void> | void;

  /**
   * @desc Return the key name of an index in the storage
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {KeyStorageParams}options- Input parameter 
   * @returns {Promise<string> | void}
   */

  export function key(options: KeyStorageParams): Promise<string> | void;

  /**
   * @desc Synchronously read storage content
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {GetSyncStorageParams}options- Input parameter 
   * @returns {TypeValue}
   */
  function getSync(options: GetSyncStorageParams) : TypeValue;

  export { del as delete, length,getSync };
}

/**
 * @desc Return value type
 */
type TypeValue = string | boolean | number | object | Array<string>;

/**
 * @desc input parameter
 */
declare interface GetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc If the key does not exist, return default. If default is not specified, return a zero-length empty string
   */
  default?: string;
  /**
   * @desc success callback
   * @param {any}data- callback function return value 
   */
  success?: (data: any) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface SetStorageParams {
  /**
   * @desc Index
   */
  key: string;

  /**
   * @desc New value. If the new value is a zero-length empty string, the data item indexed by the key will be deleted
   */
  value?: any;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface ClearStorageParams {
  /**
   * @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface DelStorageParams {
  /**
   * @desc index
   */
  key: string;
  /**
   * @desc success callback
   * @param {any}data- callback function return value 
   */
  success?: (data: any) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface KeyStorageParams {
  /**
   * @desc The index corresponding to the key name to be queried.
   */
  index: number;
  /**
   * @desc success callback
   * @param {string}data- callback function return value 
   */
  success?: (data: string) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface GetSyncStorageParams {
  /**
   * @desc index
   */
  key: string;
}
