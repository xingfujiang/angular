/**
 * statvfs is a module used to obtain application space, including interfaces to get available space and total space, and supports both synchronous and asynchronous operations
 * Interface declaration: { "name": "blueos.storage.statvfs" }
 */
declare module "@blueos.storage.statvfs" {
  /**
   * @desc Query the available space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {GetFreeSizeParams}options- Input parameter 
   * @returns {Promise<number> | void}
   */

  export function getFreeSize(
    options: GetFreeSizeParams
  ): Promise<number> | void;

  /**
   * @desc Query the available space size of the specified file system, synchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {string}path- Input parameter
   * @returns {number}
   */
  const getFreeSizeSync: (path: string) => number;

  /**
   * @desc Query the total space size of the specified file system, asynchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {GetTotalSizeParams}options- Input parameter 
   * @returns {Promise<number> | void}
   */

  export function getTotalSize(
    options: GetTotalSizeParams
  ): Promise<number> | void;

  /**
   * @desc Query the total space size of the specified file system, synchronous interface
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {string}path- Input parameter 
   * @returns {number}
   */
  const getTotalSizeSync: (path: string) => number;
}

/**
 * @desc input parameter
 */
declare interface GetFreeSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
  /**
   * @desc success callback
   * @param {number}size- callback function return value
   */
  success?: (size: number) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface GetTotalSizeParams {
  /**
   * @desc The file path URI of the file system to be queried
   */
  path: string;
  /**
   * @desc success callback
   * @param {number}size- callback function return value 
   */
  success?: (size: number) => void;

 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
