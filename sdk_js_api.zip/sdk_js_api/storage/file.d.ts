/**
 * File storage, the application can only access the storage space within its sandbox. See URI for details{@link SandboxURI}
 * Interface declaration: {"name": "blueos.storage.file"}
 */
declare module "@blueos.storage.file" {
  /**
   * @desc File moving
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {MoveParams}options- Input parameter 
   * @returns {Promise<string> | void}
   */
  export function move(options: MoveParams): Promise<string> | void;

  /**
   * @desc File copy" or "File copying
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {CopyParams}options- Input parameter 
   * @returns {Promise<string> | void}
   */
  export function copy(options: CopyParams): Promise<string> | void;

  /**
   * @desc Retrieve the list of files in the specified directory; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {ListParams}options- Input parameter 
   * @returns {Promise<ListData> | void}
   */
  export function list(options: ListParams): Promise<ListData> | void;

  /**
   * @desc Retrieve file information; please refer to the URI description used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {GetDataParams}options- Input parameter 
   * @returns {Promise<DataInfo> | void}
   */

  export function get(options: GetDataParams): Promise<DataInfo> | void;

  /**
   * @desc Delete locally stored files; refer to the file organization for the description of the URI used in the interface
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {DelParams}options- Input parameter 
   * @returns {Promise<any> | void}
   */

  function del(options: DelParams): Promise<any> | void;

  /**
   * @desc Write text to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {WriteTextParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function writeText(options: WriteTextParams): Promise<void> | void;

  /**
   * @desc Write buffer to a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {WriteArrayBufferParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function writeArrayBuffer(
    options: WriteArrayBufferParams
  ): Promise<void> | void;

  /**
   * @desc Read text from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {ReadTextParams}options- Input parameter 
   * @returns {Promise<ValueText> | void}
   */
  export function readText(options: ReadTextParams): Promise<ValueText> | void;

  /**
   * @desc Read buffer from a file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {ReadArrayBufferParams}options- Input parameter 
   * @returns {Promise<BufferData> | void}
   */
  export function readArrayBuffer(
    options: ReadArrayBufferParams
  ): Promise<BufferData> | void;

  /**
   * @desc Check if a file or directory exists
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {AccessParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */
  export function access(options: AccessParams): Promise<void> | void;

  /**
   * @desc Create directory
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {MkdirParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */
  export function mkdir(options: MkdirParams): Promise<void> | void;

  /**
   * @desc Delete directory
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {RmdirParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function rmdir(options: RmdirParams): Promise<void> | void;

  export { del as delete };
}

/**
 * @desc input parameter
 */
declare interface MoveParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
  /**
   * @desc success callback
   * @param {string} uri- callback function return value 
   */
  success?: (uri: string) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface CopyParams {
  /**
   * @desc The URI of the source file, which cannot be an application resource path or a tmp type URI
   */
  srcUri: string;
  /**
   * @desc The URI of the destination file, which cannot be an application resource path or a tmp type URI
   */
  dstUri: string;
  /**
   * @desc success callback
   * @param {string}uri- callback function return value 
   */
  success?: (uri: string) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface FileListData {
  /**
   * @desc  File URI
   */
  uri: string;
  /**
   * @desc File size, in bytes
   */
  length: number;
  /**
   * @desc  The timestamp of the last modification of the file, in milliseconds since 1970/01/01 00:00:00 GMT to the current time
   */
  lastModifiedTime: number;
}

/**
 * @desc Return value
 */
declare interface ListData {
  /**
   * @desc File list, where each file is formatted as {uri:'file1', lastModifiedTime:1234456, length:123456}.
   */
  fileList: Array<FileListData>;
}

/**
 * @desc input parameter
 */
declare interface ListParams {
  /**
   *  @desc The URI of the directory, which cannot be an application resource path or a tmp type URI.
   */
  uri: string;
  /**
   * @desc success callback
   * @param {ListData}data- callback function return value 
   */
  success?: (data: ListData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface DataInfo {
  /**
   * @desc  File URI
   */
  uri: string;
  /**
   * @desc File size, in bytes
   */
  length: number;
  /**
   * @desc  The timestamp of the last modification of the file, in milliseconds since 1970/01/01 00:00:00 GMT to the current time
   */
  lastModifiedTime: number;
  /**
   * @desc File type, dir: directory; file: file
   */
  type: string;
  /**
   * @desc File list, recursively returning detailed information for files in subdirectories when recursive is true and type is dir; otherwise, it does not return
   */
  subFiles: string[];
}

/**
 * @desc input parameter
 */
declare interface GetDataParams {
  /**
   * @desc The URI of the file, which cannot be an application resource path
   */
  uri: string;
  /**
   *
   * @desc Whether to recursively retrieve the file list of subdirectories. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   * @param {DataInfo}data- callback function return value 
   */
  success?: (data: DataInfo) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface DelParams {
  /**
   * @desc The URI of the file to be deleted, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc success callback
   * @param {any}data- callback function return value 
   */
  success?: (data: any) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface WriteTextParams {
  /**
   * @desc Local file path, does not support resource file paths and tmp partitions. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc he string to be written
   */
  text: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
  /**
   * @desc Whether to use append mode, default is false
   */
  append?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface WriteArrayBufferParams {
  /**
   * @desc Local file path; resource file paths and tmp partitions are not supported. If the file does not exist, it will be created
   */
  uri: string;
  /**
   * @desc The buffer to be written
   */
  buffer: Uint8Array;
  /**
   * @desc The offset position where data writing begins in the file, default is 0.
   */
  position?: number;
  /**
   * @desc Whether to use append mode, default is false. When true, the position parameter is ignored
   */
  append?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface ValueText {
  /**
   * @desc Read text
   */
  text: string;
}

/**
 * @desc input parameter
 */
declare interface ReadTextParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Encoding format, default is UTF-8
   */
  encoding?: string;
  /**
   * @desc success callback
   * @param {ValueText}data- callback function return value 
   */
  success?: (data: ValueText) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface BufferData {
  /**
   * The content read from the file
   */
  buffer: Uint8Array;
}

/**
 * @desc input parameter
 */
declare interface ReadArrayBufferParams {
  /**
   * @desc Local file path
   */
  uri: string;
  /**
   * @desc Starting position for reading, default is the beginning of the file
   */
  position?: number;
  /**
   * @desc Length to read; if not specified, reads until the end of the file
   */
  length?: number;
  /**
   * @desc success callback
   * @param {BufferData} data- callback function return value 
   */
  success?: (data: BufferData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface AccessParams {
  /**
   * @desc Directory or file URI, which cannot be an application resource path or a tmp type URI.
   */
  uri: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface MkdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface RmdirParams {
  /**
   * @desc Directory URI, which cannot be an application resource path or a tmp type URI
   */
  uri: string;
  /**
   * @desc Whether to recursively create the parent directories before creating this directory. Default is false
   */
  recursive?: boolean;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
