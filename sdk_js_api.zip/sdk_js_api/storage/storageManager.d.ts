/**
 * storageManager is a module used for managing application sandbox directories, including functions like clearing sandbox directories and calculating application space
 * Interface declaration: { "name": "blueos.storage.storageManager" }
 */
declare module "@blueos.storage.storageManager" {
  /**
   * @desc Clear cache directory data using the application package name
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ClearSpecificAppCacheParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function clearSpecificAppCache(
    options: ClearSpecificAppCacheParams
  ): Promise<void> | void;

  /**
   * @desc Clear tmp directory data using the application package name
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ClearSpecificAppTmpParams}options- Input parameter 
   * @returns {Promise<void> | void}
   */

  export function clearSpecificAppTmp(
    options: ClearSpecificAppTmpParams
  ): Promise<void> | void;

  /**
   * @desc Clear the cache directory data of the current application
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ClearCurrentAppCacheParams}options- Input parameter  
   * @returns {Promise<void> | void}
   */

  export function clearCurrentAppCache(
    options: ClearCurrentAppCacheParams
  ): Promise<void> | void;

  /**
   * @desc Clear files/cache/tmp/preferences/databases/lib directory data using the package name
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {ClearSpecificAppDataParams}options- Input parameter  
   * @returns {Promise<void> | void}
   */
  export function clearSpecificAppData(
    options: ClearSpecificAppDataParams
  ): Promise<void> | void;

  /**
   * @desc Calculate specified application space data
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {GetStorageStatsParams}options- Input parameter 
   * @returns {Promise<StorageStatsData> | void }
   */

  export function getStorageStats(
    options: GetStorageStatsParams
  ): Promise<StorageStatsData> | void;

  /**
   * @desc Calculate specified application space data
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {string}packageName- Input parameter 
   * @returns {StorageStatsData}
   */
  const getStorageStatsSync: (packageName: string) => StorageStatsData;
}

/**
 * @desc input parameter
 */
declare interface ClearSpecificAppTmpParams {
  /**
   * @desc Application package name
   */
  packageName: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface ClearSpecificAppCacheParams {
  /**
   * @desc Application package name
   */
  packageName: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any} data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface ClearCurrentAppCacheParams {
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface ClearSpecificAppDataParams {
  /**
   * @desc Application package name
   */
  packageName: string;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameter
 */
declare interface GetStorageStatsParams {
  /**
   * @desc Application package name
   */
  packageName: string;

  /**
   * @desc success callback
   * @param {StorageStatsData}data- callback function return value 
   */
  success?: (data: StorageStatsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface StorageStatsData {
  /**
   * @desc App package data size (in Bytes)
   */
  appSize: number;
  /**
   * @desc Application data size, excluding cache files and temporary files (in Bytes)
   */
  dataSize: number;
  /**
   * @desc Cache data size, including cache files and temporary files (in Bytes)
   */
  cacheSize: number;
}
