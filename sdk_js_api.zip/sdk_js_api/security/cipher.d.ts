/**
 * encryption algorithm.
 * Interface declaration: {"name": "blueos.security.cipher"}
 */
declare module "@blueos.security.cipher" {
  /**
   * @desc RSA encryption and decryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {rsaParams}options- RSA RSA encryption and decryption, input parameters 
   * @returns {Promise<DataText> | void}
   */

  export function rsa(options: rsaParams): Promise<DataText> | void;

  /**
   * @desc AES encryption and decryption, supports block encryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {aesParams}options- Input parameters for AES encryption and decryption 
   * @returns {Promise<DataText> | void}
   */

  export function aes(options: aesParams): Promise<DataText> | void;

  /**
   * @desc Base64 encoding and decoding
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {Base64Params}options- Input parameters for Base64 encoding and decoding
   * @returns {string}
   */
  const base64: (options: Base64Params) => string;

  /**
   * @desc crc32 encryption
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {Crc32Params}options- encryption input parameters 
   * @returns {number}
   */
  const crc32: (options: Crc32Params) => number;

  /**
   * @desc calculate hash value
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {HashParams}options- input parameters for calculating the hash value 
   * @returns {string}
   */
  const hash: (options: HashParams) => string;
}

/**
 * @desc Input parameter
 */
declare interface rsaParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
  /**
   * @desc success callback
   * @param {DataText} data- callback function return value 
   */
  success?: (data: DataText) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface aesParams {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text and must not exceed the length of keySize / 8 - 66, where keySize is the length of the key (for example, if the key length is 1024, the text must not exceed 62 bytes). The text content to be decrypted should be a binary value that has been base64 encoded. Base64 encoding uses the default style, same as below.
   */
  text: string;
  /**
   * @desc The RSA key used for encryption or decryption, which is a string generated after base64 encoding. The key is a public key during encryption and a private key during decryption
   */
  key: string;
  /**
   * @desc The padding scheme for the RSA algorithm, defaulting to 'RSA/None/OAEPwithSHA-256andMGF1Padding'
   */
  transformation?: string;
  /**
   * @desc The initialization vector for AES encryption and decryption, which is a string encoded in base64. The default value is the key value
   */
  iv?: string;
  /**
   * @desc Initial vector offset for AES encryption and decryption, default value is 0
   */
  ivOffset?: number;
  /**
   * @desc Byte length of the initialization vector for AES encryption and decryption, default value is 16
   */
  ivLen?: number;
  /**
   * @desc success callback
   * @param {DataText}data- callback function return value 
   */
  success?: (data: DataText) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc return value
 */
declare interface DataText {
  /**
   * @desc The text content generated after encryption or decryption. The encrypted content is a binary value encoded in base64, while the decrypted content is plain text. An error will occur (CODE: 200) if the decrypted content cannot be converted to a UTF-8 string
   */
  text: string;
}

/**
 * @desc Input parameter
 */
declare interface Base64Params {
  /**
   * @desc Encryption and decryption type, with two options: encrypt for encryption, decrypt for decryption
   */
  action: string;
  /**
   * @desc The text content to be encrypted or decrypted. The text content to be encrypted should be plain text
   */
  text: string;
}

/**
 * @desc Input parameter
 */
declare interface Crc32Params {
  /**
   * @desc encrypted content
   */
  content: Buffer | string;
}

/**
 * @desc Input parameter
 */
declare interface HashParams {
  /**
   * @desc Hash algorithm, options are md5, sha256
   */
  algorithm: string;
  /**
   * @desc encrypted content
   */
  content: Buffer | string;
}
