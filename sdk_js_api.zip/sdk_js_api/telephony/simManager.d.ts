/**
 * SIM card management
 * Interface declaration: {"name": "blueos.telephony.simManager"}
 */
declare module "@blueos.telephony.simManager" {
  /**
   * @desc Obtain SIM card operator information; requires phone permissions
   * @param {GetSimOperatorsParams}options - Input parameter 
   * @apiLevel 1
   * @devices (phone,watch)
   * @returns {Promise<OperatorsData> | void}
   */
  export function getSimOperators(
    options: GetSimOperatorsParams
  ): Promise<OperatorsData> | void;
}

/**
 * @desc Return value
 */
declare interface OperatorsData {
  /**
   * @desc SIM card list information
   */
  operators: Array<OperatorData>;
  /**
   * @desc Number of SIM cards
   */
  size: string;
}

/**
 * @desc Return value
 */
declare interface OperatorData {
  /**
   * @desc Return the SIM card operator information. Operator information explanation: this returns MCC+MNC, which is the Mobile Country Code + Mobile Network Code; China Mobile: 46000, 46002, 46004, 46007; China Unicom: 46001, 46006, 46009; China Telecom: 46003, 46005, 46011
   */
  operator: string;
  /**
   * @desc Slot number
   */
  slotIndex: number;
}

/**
 * @desc input parameter
 */
declare interface GetSimOperatorsParams {
  /**
   * @desc success callback
   * @param {OperatorsData}data - callback function return value 
   */
  success?: (data: OperatorsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data - return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
