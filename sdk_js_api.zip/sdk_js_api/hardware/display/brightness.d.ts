/**
 * Screen brightness
 * Interface declaration: {"name": "blueos.hardware.display.brightness"}
 */
declare module "@blueos.hardware.display.brightness" {
  /**
   * @desc Obtain the current screen brightness value
   * @devices (phone,watch)
   * @param {getValueParams}options- Obtain the current screen brightness value with input parameter 
   * @apiLevel 1
   * @returns {Promise<Data> | void}
   */
  export function getValue(options?: getValueParams): Promise<Data> | void;

  /**
   * @desc Get the current screen brightness value
   * @param {setValueParams}options- Set the current screen brightness value with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function setValue(options: setValueParams): Promise<void> | void;

  /**
   * @desc Obtain the current screen brightness mode
   * @param {getModeParams}options- Obtain the current screen brightness mode with input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data> | void}
   */
  export function getMode(options?: getModeParams): Promise<Data> | void;

  /**
   * @desc Set the current screen brightness mode
   * @param {setModeParams}options- Obtain the current screen brightness mode with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function setMode(options: setModeParams): Promise<void> | void;

  /**
   * @desc Turn the screen on or off
   * @param {setKeepScreenOnParams}options- Turn the screen on or off with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function setKeepScreenOn(
    options: setKeepScreenOnParams
  ): Promise<void> | void;

  /**
   * @desc Listen for the current screen brightness data. If called multiple times, only the last call takes effect
   * @param {subscribeParam}options- Listen for the current screen brightness data with input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (options: subscribeParam) => void;

  /**
   * @desc Unsubscribe from screen brightness data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Synchronously obtain the current screen brightness value
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {number}
   */
  const getValueSync: () => number;

  /**
   * @desc Turn the screen on or off
   * @param {wakeScreenOnParams}options- Turn the screen on or off with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function wakeScreenOn(
    options: wakeScreenOnParams
  ): Promise<void> | void;
}

/**
 * @desc Input parameter
 */
declare interface getValueParams {
  /**
   * @desc Success callback
   * @param {Data} data -Return value 
   */
  success?: (data: Data) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Screen brightness, range 0-255
   */
  value: number;
}

/**
 * @desc Input parameter
 */
declare interface setValueParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  value: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface getModeParams {
  /**
   * @desc Success callback
   * @param {Data} data - Callback return value 
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc  0 for manual screen brightness adjustment, 1 for automatic screen brightness adjustment
   */
  mode: number;
}

/**
 * @desc Input parameter
 */
declare interface setModeParams {
  /**
   * @desc Screen brightness, range 0-255
   */
  mode: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface setKeepScreenOnParams {
  /**
   * @desc Keep the screen always on
   */
  screenOn: boolean;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface subscribeParam {
  /**
   * @desc Callback function
   * @param {DataValues}data- Return value 
   */
  callback: (data: DataValues) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface DataValues {
  /**
   * @desc Screen brightness, range 0–255
   */
  value: number;
}

/**
 * @desc Input parameter
 */
declare interface wakeScreenOnParams {
  /**
   * @desc Is it on
   */
  screenOn: boolean;
  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
