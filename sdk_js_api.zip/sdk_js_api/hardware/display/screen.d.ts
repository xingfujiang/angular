/**
 * Screen
 * Interface declaration: {"name": "blueos.hardware.display.screen"}
 */
declare module "@blueos.hardware.display.screen" {
  /**
   * @desc Get screen-off time
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {number}
   */
  const getScreenOffTime: () => number;

  /**
   * @desc Get AOD status. AOD stands for Always on Display, which allows parts of the screen to remain illuminated to display important information without lighting up the entire screen
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getAodStatus: () => number;
}
