/**
 * Geolocation
 * Interface declaration: {"name": "blueos.hardware.location.location"}
 */
declare module "@blueos.hardware.location.location" {
  /**
   * @desc Get geolocation
   * @param {getLocationParams}options- Get geolocation with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data> | void }
   */
  export function getLocation(
    options?: getLocationParams
  ): Promise<Data> | void;

  /**
   * @desc Listen for geolocation changes. If called multiple times, only the last call takes effect
   * @param {subscribeDataParams}options- Listen for geolocation with input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (options: subscribeDataParams) => void;

  /**
   * @desc Unsubscribe from geolocation updates
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Get supported coordinate system types
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {string[]}
   */
  const getSupportedCoordTypes: () => string[];
}

/**
 * @desc Input parameter
 */
declare interface getLocationParams {
  /**
   * @desc Set the timeout period in milliseconds (ms), with a default value of 30000. If the system denies permissions or if the location settings are incorrect, a result may never be returned, so a timeout is necessary. The fail callback will be used after the timeout.
   */
  timeout?: number;
  /**
   * @desc Coordinate system type, with optional values available through getSupportedCoordTypes, defaults to wgs84
   */
  coorType?: string;
  /**
   * @desc Success callback
   * @param {Data} data- Return value of the success callback
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;

  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Longitude
   */
  longitude: number;
  /**
   * @desc Latitude
   */
  latitude: number;
  /**
   * @desc Accuracy
   */
  accuracy: number;
  /**
   * @desc Time
   */
  time: number;
}

/**
 * @desc Input parameter
 */
declare interface subscribeDataParams {
  /**
   * @desc Whether to persist the subscription, default is false. Mechanism: If set to true, navigation between pages will not automatically cancel the subscription; it must be manually unsubscribed
   */
  reserved?: boolean;
  /**
   * @desc Coordinate system type, optional values can be obtained via getSupportedCoordTypes, default is wgs84
   */
  coorType?: string;
  /**
   * @desc The callback is triggered each time the location information changes
   * @param {Data} data - Listen for geolocation with input parameter 
   */
  callback: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
