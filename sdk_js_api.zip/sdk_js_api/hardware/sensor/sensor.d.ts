/**
 * Sensor
 * Interface declaration: {"name": "blueos.hardware.sensor.sensor"}
 */
declare module "@blueos.hardware.sensor.sensor" {
  /**
   * @desc Listen for gravity sensor data. If called multiple times, only the last call takes effect
   * @param {subscribeAccelerometerParams} options - Listen for gravity sensor data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeAccelerometer: (options: subscribeAccelerometerParams) => void;

  /**
   * @desc Unsubscribe from gravity sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeAccelerometer: () => void;

  /**
   * @desc Listen for compass data. If called multiple times, only the last call takes effect
   * @param {subscribeCompassParams}options - Listen for compass data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeCompass: (options: subscribeCompassParams) => void;

  /**
   * @desc Unsubscribe from compass data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeCompass: () => void;

  /**
   * @desc Listen for pedometer sensor data. If called multiple times, only the last call takes effect
   * @param {subscribeStepCounterparams}options- Listen for pedometer sensor data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeStepCounter: (options: subscribeStepCounterparams) => void;

  /**
   * @desc Unsubscribe from pedometer sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeStepCounter: () => void;

  /**
   * @desc Listen for device wear status sensor data. If called multiple times, only the last call takes effect
   * @param {subscribeOnBodyStateParams}options- Listen for device wear status sensor data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeOnBodyState: (options: subscribeOnBodyStateParams) => void;

  /**
   * @desc Unsubscribe from pedometer sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeOnBodyState: () => void;

  /**
   * @desc Get device wear status
   * @devices (phone,watch)
   * @param {getOnBodyStateParams}options- Get device wear status with input parameter 
   * @apiLevel 1
   * @returns {Promise<DataValue> | void}
   */
  export function getOnBodyState(
    options?: getOnBodyStateParams
  ): Promise<DataValue> | void;

  /**
   * @desc Listen for gyroscope sensor data. If called multiple times, only the last call takes effect
   * @param {subscribeGyroscopeParams}options- Listen for gyroscope sensor data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeGyroscope: (options: subscribeGyroscopeParams) => void;

  /**
   * @desc Unsubscribe from gyroscope data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeGyroscope: () => void;

  /**
   * @desc Listen for barometric sensor data. If called multiple times, only the last call takes effect
   * @param {subscribeBarometerParams} options - Listen for barometric sensor data with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeBarometer: (options: subscribeBarometerParams) => void;

  /**
   * @desc Unsubscribe from pressure sensor data
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeBarometer: () => void;

  /**
   * @desc Listen for wrist raise. If called multiple times, only the last call takes effect
   * @param {subscribeWristLiftParams}options- Listen for wrist raise with input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeWristLift: (options: subscribeWristLiftParams) => void;

  /**
   * @desc Unsubscribe from wrist raise detection
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeWristLift: () => void;

  /**
   * @desc Listen for continuous wrist rotation. If called multiple times, only the last call takes effect
   * @param {subscribeContinuousWristTurnParams}options- Listen for continuous wrist rotation with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribeContinuousWristTurn: (
    options: subscribeContinuousWristTurnParams
  ) => void;

  /**
   * @desc Unsubscribe from wrist raise detection
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeContinuousWristTurn: () => void;

  /**
   * @desc Subscribe to proximity sensor user presence status
   * @param {subscribeProximityStateParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const subscribeProximityState: (
    options: subscribeProximityStateParams
  ) => number;

  /**
   * @desc Unsubscribe from the proximity sensor user presence status
   * @param {number} subscribeId - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeProximityState: (subscribeId: number) => void;

  /**
   * @desc Subscribe to light sensor data
   * @param {subscribeLightParams}options - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const subscribeLight: (options: subscribeLightParams) => number;

  /**
   * @desc Unsubscribe from light sensor data.
   * @param {number}subscribeId- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribeLight: (subscribeId: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeProximityStateParams {
  /**
   * @desc Listen for callback
   * @param {IsCloseData}data- Return value 
   */
  callback: (data: IsCloseData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface IsCloseData {
  /**
   *  @desc Is the proximity sensor near the user
   */
  isClose: boolean;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeContinuousWristTurnParams {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  callback: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeAccelerometerParams {
  /**
   * @desc This function is called back after changes in gravity sensor data are detected
   * @param {RetData}ret- Callback function return value 
   */
  callback: (ret: RetData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface RetData {
  /**
   * @desc x Axis coordinates
   */
  x: number;
  /**
   * @desc y Axis coordinates
   */
  y: number;
  /**
   * @desc z Axis coordinates
   */
  z: number;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeCompassParams {
  /**
   * @desc This function is called back after changes in compass data are detected
   * @param {ResData}ret- Callback function return value 
   */
  callback: (ret: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface ResData {
  /**
   * @desc ndicates the angle between the device's Y-axis and the magnetic north pole. When facing north, the angle is 0; facing south, the angle is π; facing east, the angle is π/2; and facing west, the angle is -π/2.
   */
  direction: number;
  /**
   * @desc Accuracy
   */
  accuracy: number;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeStepCounterparams {
  /**
   *  @desc This function is called back after changes in pedometer sensor data are detected
   *  @param {StepsData}ret- Callback function return value 
   */
  callback: (ret: StepsData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface StepsData {
  /**
   * @desc The pedometer sensor records the current cumulative number of steps. This value resets to 0 each time the phone restarts
   */
  steps: number;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeOnBodyStateParams {
  /**
   *  @desc This function is called back after changes in device wear status sensor data are detected
   *  @param {RetValue} ret -Callback function return value 
   */
  callback: (ret: RetValue) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface RetValue {
  /**
   * @desc Is it worn
   */
  value: number;
}

/**
 *  @desc Input parameter
 */
declare interface getOnBodyStateParams {
  /**
   * @desc Success callback
   * @param {DataValue} data - Return value of the success callback 
   */
  success?: (data: DataValue) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc Return value
 */
declare interface DataValue {
  /**
   * @desc Is it worn
   */
  value: boolean;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeGyroscopeParams {
  /**
   * @desc This function is called back after changes in gyroscope sensor data are detected
   * @param {RetData}ret- Callback function return value 
   */
  callback: (ret: RetData) => void;

   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface PressureData {
  /**
   * @desc Pressure value, unit: pascal
   */
  pressure: number;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeBarometerParams {
  /**
   *  @desc This function is called back after changes in the device wear status sensor data are detected
   *  @param {PressureData}ret- Callback function return value 
   */
  callback: (ret: PressureData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Input parameter
 */
declare interface subscribeWristLiftParams {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  callback: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

declare interface subscribeLightParams {
  /**
   * @desc Callback function
   * @param {IntensityData}data - Return value 
   */
  callback: (data: IntensityData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 *  @desc Return value
 */
declare interface IntensityData {
  /**
   *  @desc This function is called back after changes in wrist raise data are detected
   */
  intensity: number;
}
