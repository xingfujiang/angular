/**
 * Device information
 * Interface declaration: {"name": "blueos.hardware.deviceInfo"}
 */
declare module "@blueos.hardware.deviceInfo" {
  /**
   * @desc Get device information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getInfoParams}options- Get device information with input parameter
   * @returns {Promise<InfoData> | void}
   */
  export function getInfo(options?: getInfoParams): Promise<InfoData> | void;

  /**
   * @desc Batch get device identifiers
   * @param {getIdParams}options- Batch get device identifiers with input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<DataValue> | void}
   */
  export function getId(options: getIdParams): Promise<DataValue> | void;

  /**
   * @desc Get the device's unique identifier
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getDeviceIdParams}options-  Get the device's unique identifier parameter
   * @returns {Promise<DeviceIdData> | void}
   */
  export function getDeviceId(
    options?: getDeviceIdParams
  ): Promise<DeviceIdData> | void;

  /**
   * @desc Get the user's unique identifier
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getUserIdParams}options- Get the user's unique identifier input parameter 
   * @returns {Promise<UserIdData> | void}
   */
  export function getUserId(
    options?: getUserIdParams
  ): Promise<UserIdData> | void;

  /**
   * @desc Get the total size of the storage space
   * @devices (phone,watch)
   * @param {getTotalStorageParams}options-  Get the total size of the storage space input parameter 
   * @apiLevel 1
   * @returns {Promise<TotalStorageData> | void}
   */
  export function getTotalStorage(
    options?: getTotalStorageParams
  ): Promise<TotalStorageData> | void;

  /**
   * @desc Get the available size of the storage space
   * @devices (phone,watch)
   * @param {getAvailableStorageParams}options- Get the available size of the storage space input parameter
   * @apiLevel 1
   * @returns {Promise<AvailableStorageData> | void}
   */
  export function getAvailableStorage(
    options?: getAvailableStorageParams
  ): Promise<AvailableStorageData> | void;

  /**
   * @desc Get CPU information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getCpuInfoParams}options- Get CPU information input parameter
   * @returns {Promise<CpuInfoData> | void}
   */
  export function getCpuInfo(
    options?: getCpuInfoParams
  ): Promise<CpuInfoData> | void;

  /**
   * @desc Get the device serial number
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getSerialParams}options- Get the device serial number input parameter 
   * @returns {Promise<SerialData> | void}
   */
  export function getSerial(
    options?: getSerialParams
  ): Promise<SerialData> | void;

  /**
   * @desc Get card identification code
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getDeviceICCIDParams}options-  Get card identification code input parameter
   * @returns {Promise<IccidData> | void}
   */
  export function getDeviceICCID(
    options?: getDeviceICCIDParams
  ): Promise<IccidData> | void;

  /**
   * @desc Determine whether the hardware device capabilities are supported
   * @param {string}name- Determine hardware device capability support with input parameters, possible values include 'sys.modem.support' and 'sys.sensor.ecg.support'
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {boolean}
   */
  const isSupported: (name: string) => boolean;

  /**
   * @desc Get the complete list of hardware features
   * @param {getFeatureListParams}options-  Get the complete list of hardware features input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<string>> | void}
   */

  export function getFeatureList(
    options?: getFeatureListParams
  ): Promise<Array<string>> | void;

  /**
   * @desc Get information about connected devices (such as phones, tablets)
   * @param {getPeerDeviceInfoParams}options-  Get connected device information input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<BrandAndOsType> | void}
   */
  export function getPeerDeviceInfo(
    options?: getPeerDeviceInfoParams
  ): Promise<BrandAndOsType> | void;

  /**
   * @desc Synchronously get device information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {InfoData}
   */
  const getInfoSync: () => InfoData;
}

/**
 * 	@desc Input parameter
 */
declare interface getInfoParams {
  /**
   * @desc Success callback
   * @param {InfoData}data- Success callback return value
   */
  success?: (data: InfoData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * 	@desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Input parameter
 */
declare interface getIdParams {
  /**
   * @desc Supports four types: device, mac, user, and advertising, and can provide one or more of these
   */
  type: string[];
  /**
   * 	@desc Success callback
   * 	@param {DataValue}data- Callback function input parameter 
   */
  success?: (data: DataValue) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface DataValue {
  /**
   * @desc Device unique identifier. On Android, it returns IMEI or MEID; after Android Q, it returns aaid (Anonymous Application Device Identifier) for Huawei phones, and for other manufacturers, it returns oaid (Open Anonymous Device Identifier) if supported, otherwise it returns an empty value
   */
  device?: string;
  /**
   * @desc Device's MAC address. On Android M and above, it returns a fixed value: 02:00:00:00:00:00
   */
  mac?: string;
  /**
   * @desc User unique identifier. On Android, it returns the androidid
   */
  user?: string;
  /**
   * @desc Advertising unique identifier
   */
  advertising?: string;
}

/**
 * 	@desc Return value
 */
declare interface InfoData {
  /**
   * @desc Device brand
   */
  brand: string;
  /**
   * @desc Device manufacturer
   */
  manufacturer: string;
  /**
   * @desc Device model
   */
  model: string;
  /**
   * @desc Device codename
   */
  product: string;
  /**
   * @desc Operating system name
   */
  osType: string;
  /**
   * @desc Operating system version name
   */
  osVersionName: string;
  /**
   * @desc Operating system version number
   */
  osVersionCode: number;
  /**
   * @desc Runtime platform version name
   */
  platformVersionName: string;
  /**
   * @desc Runtime platform version number
   */
  platformVersionCode: number;
  /**
   * @desc System language
   */
  language: string;
  /**
   * @desc System region
   */
  region: string;
  /**
   * @desc Hardware version
   */
  hardwareVersion: string;
  /**
   * @desc Software version
   */
  softwareVersion: string;
  /**
   * @desc Screen width
   */
  screenWidth: number;
  /**
   * @desc Screen height
   */
  screenHeight: number;
  /**
   * @desc Usable window width
   */
  windowWidth: number;
  /**
   * @desc Usable window height
   */
  windowHeight: number;
  /**
   * @desc Status bar height
   */
  statusBarHeight: number;
  /**
   * @desc Device screen density
   */
  screenDensity: number;
  /**
   * @desc Name of the phone manufacturer's system
   */
  vendorOsName: string;
  /**
   * @desc Version number of the phone manufacturer's system
   */
  vendorOsVersion: string;
  /**
   * @desc For notched screens (such as a notch, waterdrop, or hole-punch screen), it returns the position and size of the notched area. Each item in the array represents a description of a notched area.
   */
  cutout: any[];
  /**
   * @desc The current device type for the vivo watch engine is 'watch' for the watch version
   */
  deviceType: string;

  /**
   * @desc Get the screen display refresh rate (the frame rate obtained may not be the standard 60, 90, 144, etc.)
   */
  screenRefreshRate: number;
}

/**
 * 	@desc Input parameter
 */
declare interface getDeviceIdParams {
  /**
   * 	@desc Success callback
   * 	@param {DeviceIdData}data- Callback function input parameter
   */
  success?: (data: DeviceIdData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface DeviceIdData {
  /**
   * @desc Device unique identifier
   */
  deviceId: string;
}

/**
 * 	@desc Return value
 */
declare interface UserIdData {
  /**
   * Device unique identifier. On Android, it returns the androidid
   */
  userId: string;
}

/**
 * 	@desc Input parameter
 */
declare interface getUserIdParams {
  /**
   * 	@desc Success callback
   * 	@param {UserIdData} data - Callback function input parameter
   */
  success?: (data: UserIdData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface TotalStorageData {
  /**
   *  @desc Total size of the storage space, in bytes. On Android, it returns the total size of the external storage
   */
  totalStorage: number;
}

/**
 * 	@desc Input parameter
 */
declare interface getTotalStorageParams {
  /**
   * @desc Success callback
   * @param {TotalStorageData} data- Callback function input parameter 
   */
  success?: (data: TotalStorageData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   *  @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface AvailableStorageData {
  /**
   * @desc Available size of the storage space, in bytes. On Android, it returns the available size of the external storage
   */
  availableStorage: number;
}

/**
 * 	@desc Input parameter
 */
declare interface getAvailableStorageParams {
  /**
   * @desc Success callback
   * @param {AvailableStorageData}data- Callback function input parameter 
   */
  success?: (data: AvailableStorageData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface CpuInfoData {
  /**
   * @desc CPU information。
   */
  cpuInfo: string;
}

/**
 * 	@desc Input parameter
 */
declare interface getCpuInfoParams {
  /**
   * @desc Success callback
   * @param {CpuInfoData} data - Callback function input parameter
   */
  success?: (data: CpuInfoData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface SerialData {
  /**
   * @desc CPU information. On Android, it returns the contents of the /proc/cpuinfo file
   */
  serial: string;
}

/**
 * 	@desc Input parameter
 */
declare interface getSerialParams {
  /**
   * @desc Success callback
   * @param {SerialData} data- Callback function input parameter 
   */
  success?: (data: SerialData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface IccidData {
  /**
   * @desc Card identification code
   */
  iccid: string;
}

/**
 * 	@desc Input parameter
 */
declare interface getDeviceICCIDParams {
  /**
   * @desc Success callback
   * @param {IccidData} data - Callback function input parameter 
   */
  success?: (data: IccidData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Input parameter
 */
declare interface getFeatureListParams {
  /**
   * @desc Success callback
   * @param {Array<string>} data - Callback function input parameter 
   */
  success?: (data: Array<string>) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * 	@desc Return value
 */
declare interface BrandAndOsType {
  /**
   * @desc Device brand
   */
  brand: string;
  /**
   * @desc Operating system name
   */
  osType: string;
}

/**
 * 	@desc Input parameter
 */
declare interface getPeerDeviceInfoParams {
  /**
   * @desc Success callback
   * @param {BrandAndOsType} data - Callback function input parameter 
   */
  success?: (data: BrandAndOsType) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
