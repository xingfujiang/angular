/**
 * Vibration
 * Interface declaration: {"name": "blueos.hardware.vibrator.vibrator"}
 */
declare module "@blueos.hardware.vibrator.vibrator" {
  /**
   * @desc Trigger vibration
   * @param {vibrateParams}options- Trigger vibration with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const vibrate: (options: vibrateParams) => void;

  /**
   * @desc Start vibration
   * @param {startParams}options- Start vibration with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<IdData> | void}
   */
  export function start(options: startParams): Promise<IdData> | void;

  /**
   * @desc Stop vibration
   * @param {number}key- Stop vibration with input parameter 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {boolean}
   */
  const stop: (key: number) => boolean;

  /**
   * @desc Get the system default vibration pattern
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getSystemDefaultMode: () => number;
}

/**
 * @desc Input parameter
 */
declare interface vibrateParams {
  /**
   * @desc Vibration pattern, where "long" indicates a long vibration and "short" indicates a short vibration. The default is long
   */
  mode?: string;
}

/**
 * @desc Input parameter
 */
declare interface startParams {
  /**
   * @desc Vibration priority ranges from 0 to 8, with lower numbers indicating higher priority
   */
  priority: number;
  /**
   * @desc Vibration duration (in milliseconds)
   */
  duration: number;
  /**
   * @desc Vibration interval time (in milliseconds)
   */
  interval: number;
  /**
   * @desc Number of vibrations
   */
  count: number;
  /**
   * @desc Success callback
   * @param {IdData}data- Return value of the success callback 
   */
  success?: (data: IdData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface IdData {
  /**
   * @desc The underlying system assigns a unique ID and returns it to the caller
   */
  id: number;
}
