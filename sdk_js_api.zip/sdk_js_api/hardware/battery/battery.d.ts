/**
 * Power information" or "Battery information
 * Interface declaration: {"name": "blueos.hardware.battery.battery"}
 */
declare module "@blueos.hardware.battery.battery" {
  /**
   * @desc Retrieve the current device's battery information
   * @devices (phone,watch)
   * @param {getStatusParams}options- Retrieve the current device's battery information with input parameter 
   * @apiLevel 1
   * @returns {Promise<Data> | void}
   */
  export function getStatus(options: getStatusParams): Promise<Data> | void;

  /**
   * @desc Synchronously retrieve the current device's battery information
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns  {Data}
   */
  const getStatusSync: () => Data;
}

/**
 * @desc Input parameter
 */
declare interface getStatusParams {
  /**
   * @desc Success callback
   * @param {Data} data- Return value of the callback
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc Return value
 */
declare interface Data {
  /**
   * @desc Is it charging
   */
  charging: boolean;
  /**
   * @desc Current battery level, between 0.0 and 1.0
   */
  level: number;
}
