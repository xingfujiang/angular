/**
 * Bluetooth interface
 * Interface declaration: {"name": "blueos.bluetooth.bluetoothManager"}
 */
declare module "@blueos.bluetooth.bluetoothManager" {
  /**
   * @desc Start searching for nearby Bluetooth peripheral devices. This operation consumes considerable system resources; please call the bluetooth.stopDevicesDiscovery method to stop searching after locating and connecting to the device
   * @param {startDevicesDiscoveryParams}options- get device information input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function startDevicesDiscovery(
    options: startDevicesDiscoveryParams
  ): Promise<void> | void;

  /**
   * @desc Stop searching for nearby Bluetooth peripheral devices. It is recommended to call this interface to stop Bluetooth searching once the desired Bluetooth device has been found and further searching is unnecessary.
   * @param {stopDevicesDiscoveryParams}options- stop searching for nearby Bluetooth peripheral devices input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function stopDevicesDiscovery(
    options: stopDevicesDiscoveryParams
  ): Promise<void> | void;

  /**
   * @desc Listen for the event of discovering a new device
   * @param {onDeviceFoundParams}options- listen for the event of discovering a new device input parameters
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const onDeviceFound: (options: onDeviceFoundParams) => void;
}

/**
 * @desc input parameter
 */
declare interface startDevicesDiscoveryParams {
  /**
   * @desc The list of UUIDs for the primary services to search for. Some Bluetooth devices broadcast their primary service's UUID. If this parameter is set, the search will only include Bluetooth devices with a broadcast packet containing the corresponding UUID of the primary service. It is recommended to use this parameter primarily to filter out other Bluetooth devices in the vicinity that do not need to be processed
   */
  service?: string[];
  /**
   * @desc The default value is false. Whether to allow the same device to be reported repeatedly. If repeated reporting is allowed, the bluetooth.ondevicefound method will report the same device multiple times, although the RSSI value may differ.
   */
  allowDuplicatesKey?: boolean;
  /**
   * @desc In milliseconds, with a default value of 0. This is the interval for reporting devices. A value of 0 means that a newly found device is reported immediately, while other values indicate that devices are reported at the specified interval
   */
  interval?: number;
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface stopDevicesDiscoveryParams {
  /**
   * @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc return value
 */
declare interface onDeviceFoundParams {
  /**
   * @desc device information
   */
  devices: Array<DevicesData>;
}

/**
 * @desc device information
 */
declare interface DevicesData {
  /**
   * @desc Bluetooth device name, which some devices may not have
   */
  name: string;
  /**
   * @desc ID used to distinguish the device
   */
  deviceId: string;
  /**
   * @desc current Bluetooth device signal strength.
   */
  RSSI: ArrayBuffer;
  /**
   * @desc ManufacturerData segment in the advertising data of the current Bluetooth device
   */
  advertisServiceUUIDs: string[];
  /**
   * @desc LocalName segment in the advertising data of the current Bluetooth device
   */
  localName: string;
  /**
   * @desc The ServiceData segment in the advertising data of the current Bluetooth device, where the key is a string value of the uuid, and the value is the corresponding ServiceData ArrayBuffer.
   */
  serviceData: Record<string, any>;
}
