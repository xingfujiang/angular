/**
 * system settings
 * Interface declaration: {"name": "blueos.service.settings"}
 */
declare module "@blueos.service.settings" {
  /**
   * @desc get the value of the setting
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {GetValueParams}options- Get setting input parameters 
   * @returns {Promise<KeyValue> | void}
   */

  export function getValue(options: GetValueParams): Promise<KeyValue> | void;

  /**
   * @desc Synchronously get the value of the setting
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {SystemConfiguration}key- get setting input parameters 
   * @returns {any}
   */
  const getValueSync: (key: SystemConfiguration) => any;
}

/**
 * system settings enumeration
 */
declare enum SystemConfiguration {
  /**
   * @desc screen brightness
   */
  Brightness = "brightness",
  /**
   * @desc wearing hand
   */
  WearHand = "wearHand",
  /**
   * @desc Wrist raise detection switch
   */
  RaiseWristSwitch = "raiseWristSwitch",
  /**
   * @desc Wrist raise detection sensitivity
   */
  RaiseWristSensitivity = "raiseWristSensitivity",
  /**
   * @desc silent mode
   */
  SilentMode = "silentMode",
  /**
   * @desc screen rotation
   */
  FlipScreen = "flipScreen",
}

/**
 * @desc return value
 */
declare interface KeyValue {
  /**
   * @desc the field name of the corresponding setting
   */
  key: string;
  /**
   * @desc the value of the corresponding setting
   */
  value: any;
}

/**
 * @desc Input parameter
 */
declare interface GetValueParams {
  /**
   * @desc he field name of the corresponding setting
   */
  key: SystemConfiguration;
  /**
   * @desc success callback
   * @param {KeyValue}data- callback function return value 
   */
  success?: (data: KeyValue) => void;

 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
