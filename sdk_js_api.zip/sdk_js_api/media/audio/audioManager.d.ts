/**
 * audio management
 * Interface declaration: {"name": "blueos.media.audio.audioManager"}
 */
declare module "@blueos.media.audio.audioManager" {
  /**
   * @desc Set volume
   * @param {setVolumeParams}options- Input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function setVolume(options: setVolumeParams): Promise<void> | void;

  /**
   * @desc Get volume
   * @param {getVolumeParams}options- Input parameters for getting volume 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<number> | void}
   */

  export function getVolume(options: getVolumeParams): Promise<number> | void;

  /**
   * @desc Synchronously get volume
   * @param {getVolumeSyncParams}options- Input parameters for synchronously getting volume 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getVolumeSync: (options: getVolumeSyncParams) => number;

  /**
   * @desc Listen for volume changes
   * @param {DataSubscribeParams}options- Input parameters for listening to volume changes
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const subscribe: (options: DataSubscribeParams) => void;

  /**
   *  @desc Cancel listening to volume changes
   *  @devices (phone,watch)
   *  @apiLevel 1
   */
  const unsubscribe: () => void;

  /**
   * @desc Get the minimum volume for the specified stream
   * @param {getMinVolumeParams}options- Input parameters for getting the minimum volume of the specified stream 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getMinVolume: (options: getMinVolumeParams) => number;

  /**
   * @desc Get the maximum volume for the specified stream
   * @param {getMaxVolumeParams}options- nput parameters for getting the maximum volume of the specified stream 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const getMaxVolume: (options: getMaxVolumeParams) => number;

  /**
   * @desc Mute or unmute the specified volume stream
   * @param {muteParams}options- Input parameters for muting or unmuting the specified volume stream
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */

  export function mute(options: muteParams): Promise<void> | void;

  /**
   * @desc Check if the specified volume stream is muted
   * @param {isMuteParams}options- Input parameters for checking if the specified volume stream is muted
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<number> | void}
   */

  export function isMute(options: isMuteParams): Promise<number> | void;

  /**
   * @desc Check if the microphone is muted
   * @devices (phone,watch)
   * @param {isMicrophoneMuteParams}options- Input parameters for checking if the microphone is muted 
   * @apiLevel 1
   * @returns {Promise<number>}
   */
  export function isMicrophoneMute(
    options: isMicrophoneMuteParams
  ): Promise<number> | void;
}

/**
 * @desc input parameters
 */
declare interface setVolumeParams {
  /**
   *  @desc volume stream type
   */
  volumeType: "RING" | "MEDIA";
  /**
   *  @desc Volume level, the set volume, between 0.00 and 1.00
   */
  volume: number;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc audio stream type
 */
type VolumeType =
  | "SYSTEM"
  | "RING"
  | "MEDIA"
  | "VOICE_CALL"
  | "ALARM"
  | "NOTIFICATION"
  | "BLUETOOTH_SCO"
  | "TTS"
  | "SPORT_BROADCAST";

/**
 * @desc input parameters
 */
declare interface getVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc success callback
   *  @param {number}num- callback return value 
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface getVolumeSyncParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 *  @desc success callback
 */
declare interface CallbackData {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc Volume level, with the set volume ranging between 0.00 and 1.00
   */
  value: number;
}

/**
 * @desc input parameters
 */
declare interface DataSubscribeParams {
  /**
   *  @desc volume: represents volume
   */
  type: string;
  /**
   *  @desc Monitor the execution of the volume change data callback function
   *  @param {CallbackData}data- callback return value for monitoring changes 
   */
  callback: (data: CallbackData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getMinVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface getMaxVolumeParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;
}

/**
 * @desc input parameters
 */
declare interface muteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc Whether to mute the audio stream (1: set to mute; 0: set to unmute)
   */
  isMute: number;

  /**
   *  @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface isMuteParams {
  /**
   *  @desc audio stream type
   */
  volumeType: VolumeType;

  /**
   *  @desc success callback
   *  @param {number}num callback return value 
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameters
 */
declare interface isMicrophoneMuteParams {
  /**
   *  @desc success callback
   *  @param {number} num -Callback return value, 1: set to mute; 0: set to unmute
   */
  success?: (num: number) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
