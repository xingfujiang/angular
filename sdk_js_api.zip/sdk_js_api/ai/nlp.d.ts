/**
 * Natural Language Processing
 * Interface declaration: {"name": "blueos.ai.nlp"}
 */
declare module "@blueos.ai.nlp" {
  /**
   * @desc Face segmentation, utilizing AI cutout technology to segment the human head in an image, can be used for background replacement or face-swapping applications
   * @apiLevel 2
   * @devices (phone,watch)
   * @param {TranslateParams}options- Input parameter 
   * @returns {Promise<TranslateData>}
   */
  const translateText: (options: TranslateParams) => Promise<TranslateData>;

  /**
   * @desc The API supports two platforms: vivo AI platform and Xuanji platform. By default, the API connects to the vivo AI platform. If you have already obtained an appId and appKey on the Xuanji platform and wish to use its services, you need to call this interface once to switch the API environment to the Xuanji platform
   * @apiLevel 2
   * @devices (phone,watch)
   * @private
   */
  const switch2xuanji: () => void;
}

/**
 * @desc Request authentication information to ensure the legitimacy of the request source.
 */
declare interface Auth {
  /**
   * @desc Application appId.
   */
  appId: string;
  /**
   * @desc Application appKey
   */
  appKey: string;
}

/**
 * @desc TranslateParams parameter
 */
declare interface TranslateParams {
  /**
   * @desc Translate text
   */
  text: string;

  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source
   */
  auth: Auth;

  /**
   * @desc Source language and target language parameters
   */
  options?: {
    /**
     * @desc Source language, for language codes see the language code reference table below
     */
    from?: string;
    /**
     * @desc Target language, for language codes see the language code reference table below.
     */
    to?: string;
  };
}

/**
 * @desc TranslateData return result
 */
declare interface TranslateData {
  /**
   * @desc Original text
   */
  text: string;
  /**
   * @desc Source language
   */
  from: string;
  /**
   * @desc Target language
   */
  to: string;
  /**
   * @desc Translated text
   */
  translation: string;
}
