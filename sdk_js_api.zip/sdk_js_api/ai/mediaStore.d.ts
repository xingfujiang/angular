/**
 * Album invocation framework service
 * Interface declaration: {"name": "blueos.ai.mediaStore"}
 */
declare module "@blueos.ai.mediaStore" {
  /**
   * 	@desc Album invocation framework service searchPhotos interface, retrieve data matching the query
   * 	@param {SearchPhotosParams}options- Input parameter 
   *  @apiLevel 2
   *  @devices (phone,watch)
   *  @returns {Promise<Array<TargetPhoto>> | void}
   */
  export function searchPhotos(
    options: SearchPhotosParams
  ): Promise<Array<TargetPhoto>> | void;
}

/**
 * @desc Input parameter
 */
declare interface SearchPhotosParams {
  /**
   * @desc The original query content input by the user
   */
  query: string;
  /**
   * @desc JsonObject type, information on intent understanding passed through by the assistant from the cloud side
   */
  copilotJson: object;
  /**
   * @desc Successful callback
   * @param {Array<TargetPhoto>} data- Return value 
   */
  success?: (data: Array<TargetPhoto>) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc 0: represents a label, 1: represents semantics
 */
type SearchType = 0 | 1;

/**
 * @desc Return value
 */
declare interface TargetPhoto {
  /**
   * @desc 0: indicates a label, 1: indicates semantics
   */
  searchType: SearchType;
  /**
   * @desc Scores for label and semantic search results
   */
  score: number;
  /**
   * @desc Image name
   */
  name: string;
  /**
   * @desc Original image path
   */
  path: string;
  /**
   * @desc Thumbnail path
   */
  thumbnailPath: string;
  /**
   * @desc Image label
   */
  labelText: Array<string>;
  /**
   * @desc Image semantics
   */
  semanticText: Array<string>;
}
