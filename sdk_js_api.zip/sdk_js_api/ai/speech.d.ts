/**
 * Speech technology
 * Interface declaration: {"name": "blueos.ai.speech"}
 */
declare module "@blueos.ai.speech" {
  /**
   * @desc Create ASR instance
   * @param {CreateAsrParams}options - Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {AsrInstance}
   */
  const createAsr: (options: CreateAsrParams) => AsrInstance;

  /**
   * @desc Create TTS instance
   * @param {CreateTtsParams}options - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {TtsInstance}
   */
  const createTts: (options: CreateTtsParams) => TtsInstance;

  /**
   * @desc The API supports two platforms: the vivo AI platform and the Xuanji platform. By default, the API connects to the vivo AI platform. If you have already applied for an appId and appKey on the Xuanji platform and wish to use its services, you need to call this interface once to switch the API environment to the Xuanji platform
   * @apiLevel 2
   * @devices (phone,watch)
   * @private
   */
  const switch2xuanji: () => void;
}

/**
 * @desc ASR instance
 */
declare interface AsrInstance {
  /**
   * @desc Activate speech recognition service
   * @devices (phone,watch)
   * @apiLevel 2
   */
  start: () => void;

  /**
   * @desc Send audio data; it is recommended to send the audio data in frames, with each frame containing 40 milliseconds of audio. Each sentence should not exceed 60 seconds
   * @param {ArrayBuffer}data -  Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   */
  send: (data: ArrayBuffer) => void;

  /**
   * @desc Speech recognition information callback. After sending audio data through the send() interface, the speech recognition results will be returned via this callback event
   * @param {ShortModeResult | LongModeResult} result - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onMessage: (result: ShortModeResult | LongModeResult) => void;

  /**
   * @desc Callback for successful activation of the speech recognition service. Once the service is activated successfully, the speech recognition service will begin processing the data sent through the send() interface
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onStarted: () => void;

  /**
   * @desc Speech recognition service termination callback. This callback can be triggered by calling the finish() interface or automatically triggered by an endVadTime timeout
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onFinished: () => void;

  /**
   * @desc Speech recognition service error callback
   * @param {string} data - Input parameter 
   * @param {FailcodeEnum}code-  Input parameter
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onError: (data: string, code: FailcodeEnum) => void;
}

/**
 * @desc Result
 */
declare interface TtsResult {
  /**
   * @desc Synthesized audio segment
   */
  audio: Uint8Array;
  /**
   * @desc Current audio stream status
   */
  status: number;
  /**
   * @desc Synthesis progress, indicating the current number of characters synthesized out of the total number of characters
   */
  progress: string;
  /**
   * @desc The number of the returned frame data
   */
  slice: number;
}

/**
 * @desc TTS instanc
 */
declare interface TtsInstance {
  /**
   * @desc Connect to text-to-speech service
   * @param {string} data - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  connect: (data: string) => void;
  /**
   * @desc Disconnect from the text-to-speech service and release network resources and associated player resources. It is recommended to call this when the application is destroyed
   * @apiLevel 2
   * @devices (phone,watch)
   */
  disconnect: () => void;
  /**
   * @desc Send text content.
   * @param {string}data- Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   */
  send: (data: string) => void;
  /**
   * @desc Pause audio playback in the TTS instance service.
   * @devices (phone,watch)
   * @apiLevel 2
   */
  pauseAudio: () => void;
  /**
   * @desc Resume audio playback in the TTS instance service
   * @apiLevel 2
   * @devices (phone,watch)
   */
  resumeAudio: () => void;
  /**
   * @desc Callback for successful connection to the text-to-speech service. Triggered after successfully connecting to the service using the connect() function. Once the service is connected successfully, the text-to-speech service will start processing the text content sent through the send() interface
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onConnected: () => void;
  /**
   * @desc Text recognition information callback. After sending text content through the send() interface, the text recognition results will be returned via this callback event
   * @param {TtsResult}result- Input parameter
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onMessage: (result: TtsResult) => void;
  /**
   * @desc Playback start callback
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onSpeakStarted: () => void;
  /**
   * @desc Playback pause callback, triggered after calling TtsInstance.pauseAudio()
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onSpeakPaused: () => void;
  /**
   * @desc Playback progress information callback. After playback starts, this callback is triggered multiple times with progress information until playback is complete
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onSpeakProgress: () => void;
  /**
   * @desc Playback completion callback
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onSpeakFinished: () => void;
  /**
   * @desc Resume playback callback, triggered after calling TtsInstance.resumeAudio()
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onSpeakResumed: () => void;
  /**
   * @desc Text-to-speech service error callback
   * @param {string}data- Input parameter 
   * @param {FailcodeEnum}code- Input parameter 
   * @apiLevel 2
   * @devices (phone,watch)
   */
  onError: (data: string, code: FailcodeEnum) => void;
}

/**
 * @desc AsrParams parameter
 */
declare interface ShortModeResult {
  /**
   * @desc ASR recognition result
   */
  text: string;
  /**
   * @desc Result serial number
   */
  resultId: number;
  /**
   * @desc ASR recognition return, where 1 represents correction and 0 represents addition
   */
  reformation: number;
  /**
   * @desc Is this the last result of the current session?
   */
  isLast: boolean;
}

/**
 * @desc Request authentication information to ensure the legitimacy of the request source.
 */
declare interface Auth {
  /**
   * @desc Application appId.
   */
  appId: string;
  /**
   * @desc Application appKey
   */
  appKey: string;
}

/**
 * @desc Error callback code
 */
type FailcodeEnum =
  | 10000
  | 10002
  | 10003
  | 10004
  | 10005
  | 10006
  | 10007
  | 10008
  | 50001;

/**
 * @desc Error callback code
 */
type ResultCodeEnum = 0 | 8 | 9;

/**
 * @desc AsrParams parameter
 */
declare interface LongModeResult {
  /**
   * @desc Result code description
   */
  code: ResultCodeEnum;
  /**
   * @desc Midpoint result during recognition, i.e., an intermediate result of a sentence
   */
  midPoint: string;
  /**
   * @desc Intermediate recognition result "rec," which is the complete sentence or the final sentence result
   */
  endPoint: string;
  /**
   * @desc Start time, in milliseconds
   */
  beginTime: number;
  /**
   * @desc End time, in milliseconds
   */
  endTime: number;
  /**
   * @desc When there is speaker separation, returns 0 to indicate the current speaker, and a non-zero value to indicate a role ID, indicating a change in roles
   */
  speaker: number;
}

/**
 * @desc AsrParams parameter
 */
declare interface CreateAsrParams {
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source.
   */
  auth: Auth;
  /**
   * @desc ASR model used, supporting both short phrase and long sentence models
   */
  model: AsrModel;
  /**
   * @desc Initialize ASR client configuration settings
   */
  config?: AsrConfig;
}

declare interface CreateTtsParams {
  /**
   * @desc Authentication information for the request to ensure the legitimacy of the request source.
   */
  auth: Auth;
  /**
   * @desc TTS audio generation model, supporting short audio models and long audio generation models
   */
  model: TtsModel;
  /**
   * @desc Initialize TTS client configuration settings
   */
  config?: TtsConfig;
  /**
   * @desc 	Set whether the TTS instance should play sound
   */
  isNeedPlay?: boolean;
}

/**
 * @desc TTS audio generation model, supporting short audio and long audio generation models
 */
type TtsModel = "ShortJovi" | "LongDefault";

/**
 * @desc ASR model used, supporting both short speech and long sentence models
 */
type AsrModel = "ShortInputt" | "ShortJovi" | "LongListen" | "LongSubtitle";

/**
 * @desc Engine type, supporting Chinese and English with optimized effects
 */
type EngineType = "normal" | "enZh" | "en" | "optimized";

/**
 * @desc Language
 */
type AsrLang = "Cn" | "En";

/**
 * @desc Audio type used
 */
type AudioType = "Pcm" | "Opus";

/**
 * @desc Speaker for speech synthesis
 */
type ShortSpeaker =
  | "yiwen"
  | "yunye"
  | "wanqing"
  | "xiaofu"
  | "yigeChild"
  | "yige"
  | "yiyi"
  | "xiaoming";

/**
 * @desc The speaker for speech synthesis
 */
type LongSpeaker =
  | "yiwen"
  | "yunye"
  | "yunyeNews"
  | "yige"
  | "yigeNews"
  | "huaibin"
  | "zhaokun"
  | "yaheng"
  | "haiwei"
  | "qianqian"
  | "enFemale"
  | "xiaoyun";

/**
 * @desc Initialize TTS client configuration settings
 */
declare interface TtsConfig {
  /**
   * @desc Engine type, supports Chinese and English with optimized effects
   */
  engineType?: EngineType;
  /**
   * @desc Audio type
   */
  audioType?: AudioType;
  /**
   * @desc Sample rate
   */
  sampleRate?: number;
  /**
   * @desc Speaker for speech synthesis
   */
  speaker?: ShortSpeaker | LongSpeaker;
  /**
   * @desc Speech rate
   */
  speed?: number;
  /**
   * @desc Volume
   */
  volume?: number;
  /**
   * @desc Whether to return audio in a streaming manner
   */
  isStream?: boolean;
}

/**
 * @desc AsrParams parameter
 */
declare interface AsrConfig {
  /**
   * @desc Audio type used
   */
  audioType?: AudioType;
  /**
   * @desc Whether to enable punctuation
   */
  isWithPunctuation?: boolean;
  /**
   * @desc Backend detection time
   */
  endVadTime?: number;
  /**
   * @desc Whether to enable conversion from Chinese characters to numbers
   */
  isChinese2digital?: boolean;
  /**
   * @desc Language
   */
  lang?: AsrLang;
}
