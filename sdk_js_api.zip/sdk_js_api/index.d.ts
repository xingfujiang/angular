// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 3.7

//  app接口
/// <reference path="app/appmanager/appState.d.ts" />
/// <reference path="app/appmanager/pageStack.d.ts" />
/// <reference path="app/appmanager/router.d.ts" />
/// <reference path="app/appmanager/schedule.d.ts" />
/// <reference path="app/appManager/transitionAnimation.d.ts" />
/// <reference path="app/event/eventManager.d.ts" />
/// <reference path="app/notification/notificationManager.d.ts" />
/// <reference path="app/context.d.ts" />
/// <reference path="app/configuration.d.ts" />

//  ai接口
/// <reference path="ai/mediaStore.d.ts" />
/// <reference path="ai/nlp.d.ts" />
/// <reference path="ai/speech.d.ts" />
/// <reference path="ai/vision.d.ts" />

//  aigc接口
/// <reference path="aigc/aigc.d.ts" />
/// <reference path="aigc/vectorSearch.d.ts" />

//  card接口
/// <reference path="card/widgetManager.d.ts" />

//  input接口
/// <reference path="input/inputMethodcontroller.d.ts" />
/// <reference path="input/inputMethodSetting.d.ts" />
/// <reference path="input/inputMethodSwitchDialog.d.ts" />
/// <reference path="input/supplementalDictionary.d.ts" />
/// <reference path="input/textInputProxy.d.ts" />

// llm接口
/// <reference path="llm/llm.d.ts" />

// bluetooth接口
/// <reference path="bluetooth/bluetoothManager.d.ts" />

// service
/// <reference path="service/inputMethod.d.ts" />
/// <reference path="service/settings.d.ts" />

// bluexlink接口
/// <reference path="bluexlink/connectionManager.d.ts" />

// hardware接口
/// <reference path="hardware/battery/battery.d.ts" />
/// <reference path="hardware/display/brightness.d.ts" />
/// <reference path="hardware/display/screen.d.ts" />
/// <reference path="hardware/location/location.d.ts" />
/// <reference path="hardware/sensor/sensor.d.ts" />
/// <reference path="hardware/vibrator/vibrator.d.ts" />
/// <reference path="hardware/deviceInfo.d.ts" />
/// <reference path="hardware/keyboard/keyboard.d.ts" />

// health
/// <reference path="health/health.d.ts" />

// media
/// <reference path="media/audio/audioManager.d.ts" />
/// <reference path="media/audio/audioPlayer.d.ts" />
/// <reference path="media/audio/audioRecorder.d.ts" />
/// <reference path="media/audio/mediaManager.d.ts" />
/// <reference path="media/image/bitmap.d.ts" />

// network
/// <reference path="network/fetch.d.ts" />
/// <reference path="network/networkManager.d.ts" />
/// <reference path="network/request.d.ts" />
/// <reference path="network/webSocket.d.ts" />
/// <reference path="network/p2p.d.ts" />
/// <reference path="network/wifi.d.ts" />

// package
/// <reference path="package/packageManager.d.ts" />

// storage
/// <reference path="storage/exchange.d.ts" />
/// <reference path="storage/file.d.ts" />
/// <reference path="storage/storage.d.ts" />
/// <reference path="storage/sandboxUri.d.ts" />
/// <reference path="storage/database.d.ts" />
/// <reference path="storage/statvfs.d.ts" />
/// <reference path="storage/storageManager.d.ts" />

// window
/// <reference path="window/prompt.d.ts" />

// util
/// <reference path="util/fastlz.d.ts" />
/// <reference path="util/tar.d.ts" />

// telephony
/// <reference path="telephony/simManager.d.ts" />

// security
/// <reference path="security/cipher.d.ts" />

//全局函数
/// <reference path="global.d.ts" />
