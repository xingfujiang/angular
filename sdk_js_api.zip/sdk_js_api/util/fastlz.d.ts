/**
 * Extract file" or "Unzip file
 * Interface declaration: {"name": "blueos.util.fastlz"}
 */
declare module "@blueos.util.fastlz" {
  /**
   * @desc Extract file" or "Unzip file
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {DecompressParams} options - Input parameter 
   * @returns {Promise<void> | void}
   */
  export function decompress(options: DecompressParams): Promise<void> | void;
}

/**
 * @desc input parameter
 */
declare interface DecompressParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory must be a complete file name
   */
  dstUri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data - return value of the failure callback 
   *	@param {number}code - return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
