/**
 * Unpack
 * Interface declaration: {"name": "blueos.util.tar"}
 */
declare module "@blueos.util.tar" {
  /**
   * @desc Unpack
   * @devices (phone,watch)
   * @apiLevel 1
   * @param  {UntarParams} options - Input parameter 
   * @returns {Promise<void> | void}
   */
  export function untar(options: UntarParams): Promise<void> | void;
}

/**
 * @desc input parameter
 */
declare interface UntarParams {
  /**
   * @desc The URI of the source file, which cannot be of tmp type.
   */
  srcUri: string;
  /**
   * @desc The URI of the destination directory, which cannot be an application resource path or of tmp type
   */
  dstUri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any} data - return value of the failure callback 
   *	@param {number}code - return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}
