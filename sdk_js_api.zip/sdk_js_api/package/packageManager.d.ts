/**
 * package management
 * Interface declaration: {"name": "blueos.package.packageManager"}
 */
declare module "@blueos.package.packageManager" {
  /**
   * @desc Detect if the application is installed
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {hasInstalledParams}options- Check if there are input parameters for the application 
   * @returns {Promise<ResData> | void}
   */

  export function hasInstalled(
    options: hasInstalledParams
  ): Promise<ResData> | void;

  /**
   * @desc Install application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {installParams}options- Install application input parameters 
   * @returns {Promise<ResData> | void}
   */

  export function install(options: installParams): Promise<ResData> | void;

  /**
   * @desc Uninstall application
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {uninstallParams}options- Uninstall application input parameters 
   * @returns {Promise<ResData> | void}
   */

  export function uninstall(options: uninstallParams): Promise<ResData> | void;

  /**
   * @desc Retrieve application version code and version name information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {GetInfoParams}options- Retrieve input parameters for application version code and version name information 
   * @returns {Promise<Packages> | void}
   */

  export function getInfo(options: GetInfoParams): Promise<Packages> | void;

  /**
   * @desc Retrieve application signature digest information
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getSignatureDigestsParams}options- Parameters for retrieving application signature digest information 
   * @returns {Promise<SignatureDigestsData> | void}
   */

  export function getSignatureDigests(
    options: getSignatureDigestsParams
  ): Promise<SignatureDigestsData> | void;

  /**
   * @desc Get the list of currently installed applications
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getInstalledPackagesParams}options- Input parameters for retrieving the list of currently installed applications 
   * @returns {Promise<PackagesData> | void}
   */

  export function getInstalledPackages(
    options?: getInstalledPackagesParams
  ): Promise<PackagesData> | void;

  /**
   * @desc Get the list of installed cards
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getInstalledWidgetsParams}options- Input parameters for retrieving the list of installed cards
   * @returns {Promise<Widget> | void}
   */

  export function getInstalledWidgets(
    options?: getInstalledWidgetsParams
  ): Promise<Widget> | void;

  /**
   * @desc Synchronously get application categories
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {string}package- Input parameters for synchronously getting application categories 
   * @returns {Array<string>}
   */
  const getAppCategory: (package: string) => Array<string>;

  /**
   * @desc Asynchronously get application categories
   * @devices (phone,watch)
   * @apiLevel 1
   * @param {getAppCategoryAsyncParams}options- Input parameters for asynchronously getting application categories 
   * @returns {Promise<string[]>}
   */

  export function getAppCategoryAsync(
    options: getAppCategoryAsyncParams
  ): Promise<string[]> | void;
}

/**
 * @desc card type
 */
type CardType = "js" | "lite";

/**
 * @desc Widget information
 */
declare interface Widget {
  /**
   *  @desc package name
   */
  package: string;
  /**
   *  @desc card module name
   */
  moduleName: string;
  /**
   *  @desc card type
   */
  type: CardType;
  /**
   *  @desc Card name, supports multiple languages
   */
  name: string;
  /**
   *  @desc Card description, supports multiple languages
   */
  description: string;
  /**
   *  @desc Minimum supported platform version number
   */
  minPlatformVersion: number;
  /**
   *  @desc Represents the timed data refresh interval, in seconds
   */
  refreshDuration: number;
  /**
   *  @desc Indicates the scheduled refresh times for the card, using the 24-hour format, accurate to the minute, e.g., ['10:30', '21:30']
   */
  scheduledRefreshTime: string[];
  /**
   *  @desc card size
   */
  sizes: string[];
  /**
   *  @desc Supported device types for the card
   */
  deviceTypeList: DeviceType[];
  /**
   *  @desc Card preview image
   */
  previewImages: PreviewImage[];
}

/**
 * @desc device type
 */
type DeviceType = "watch" | "tv" | "car" | "phone" | "band";

/**
 * @desc application type
 */
type ApplicationType = "widget" | "package";

/**
 * @desc return result
 */
declare interface ResData {
  /**
   * @desc whether the application exists
   */
  result: boolean;
}

/**
 * @desc return result
 */
declare interface SignatureDigestsData {
  /**
   * @desc list of signature digest information using SHA-256
   */
  signatureDigests: string[];
}

/**
 * @desc return result
 */
declare interface PackagesData {
  /**
   * @desc The category of the application; see the above application classifications for details
   */
  packages: Packages[];
}

/**
 * @desc preview information
 */
declare interface PreviewImage {
  /**
   * @desc size
   */
  size: string;
  /**
   * @desc image information
   */
  images: string[];
}

/**
 * @desc List of installed application package information
 */
declare interface Packages {
  /**
   *  @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for widget in the manifest, e.g., widgets/widget.
   */
  moduleName: string;

  /**
   *  @desc application name
   */
  name: string;
  /**
   *  @desc application icon path
   */
  icon: string;
  /**
   *  @desc version number
   */
  versionCode: number;
  /**
   *  @desc version name
   */
  versionName: string;
}

/**
 * @desc Input parameter
 */
declare interface hasInstalledParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {ResData}data- callback function return value 
   */
  success?: (data: ResData) => void;

 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface installParams {
  /**
   * @desc installation package URI, sandbox directory
   */
  path: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {ResData}data- callback function return value 
   */
  success?: (data: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface uninstallParams {
  /**
   * @desc specify the package name of the application to uninstall
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;

  /**
   * @desc success callback
   * @param {ResData}data- callback function return value 
   */
  success?: (data: ResData) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface GetInfoParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
  /**
   * @desc success callback
   * @param {Packages}data- callback function return value 
   */
  success?: (data: Packages) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Input parameter
 */
declare interface getSignatureDigestsParams {
  /**
   * @desc application package name
   */
  package: string;

  /**
   * @desc When the type is widget, the card's moduleName is required, which is the key for the widget in the manifest, e.g., widgets/widget
   */
  moduleName?: string;

  /**
   * @desc The default value is package, where package represents a regular application and widget represents a card
   */
  type?: ApplicationType;
  /**
   * @desc success callback
   * @param {SignatureDigestsData}data- callback function return value 
   */
  success?: (data: SignatureDigestsData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface getInstalledPackagesParams {
  /**
   * @desc success callback
   * @param {PackagesData}data- callback function return value 
   */
  success?: (data: PackagesData) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface getInstalledWidgetsParams {
  /**
   * @desc success callback
   * @param {Widget} widget-callback function return value 
   */
  success?: (widget: Widget) => void;
 /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface getAppCategoryAsyncParams {
  /**
   * @desc application package name
   */
  package: string;
  /**
   * @desc success callback
   * @param {string[]}appCategory- callback function return value 
   */
  success?: (appCategory: string[]) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
