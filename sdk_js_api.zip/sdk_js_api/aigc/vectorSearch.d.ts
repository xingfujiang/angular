/**
 * ai
 * Interface declaration: {"name": "blueos.ai.vectorSearch"}
 */
declare module "@blueos.ai.vectorSearch" {
  /**
   * @desc Generate a corresponding vector from the input content.
   * @param {CommonEmbeddingParams}options- Successful return value 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<EmbeddingObject> | void}
   */
  export function textEmbedding(
    options: CommonEmbeddingParams
  ): Promise<EmbeddingObject> | void;

  /**
   * @desc Generate a corresponding vector from the input image
   * @param {CommonEmbeddingParams}options- Successful return value 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<EmbeddingObject> | void}
   */

  export function imageEmbedding(
    options: CommonEmbeddingParams
  ): Promise<EmbeddingObject> | void;

  /**
   * @desc object
   */
  const vectorDB: {
    /**
     * @desc Create an index; if the index already exists, directly return the index object instance
     * @param {CreateIndexParams}options- Input parameter 
     * @devices (phone,watch)
     * @apiLevel 2
     * @returns {VectorIndex}
     */
    createIndex: (options: CreateIndexParams) => VectorIndex;
  };
}

/**
 * @desc Input parameter
 */
declare interface PromiseVectorParams {
  /**
   * @desc Vector list
   */
  vectorList: Array<Embedding>;
  /**
   * @desc Vector ID, when the index uses non-auto-increment IDs
   */
  ids?: Array<number>;
  /**
   * @desc Meta is used to store additional information beyond the vector itself
   */
  metaList?: Array<Meta>;
}

/**
 * @desc Input parameter
 */
declare interface PromiseSearchParams {
  /**
   * @desc Vector
   */
  vector: Embedding;
  /**
   * @desc Top K closest search results
   */
  topK?: number;
  /**
   * @desc Search minimum threshold; only results above this threshold will be returned
   */
  thresholdScore?: number;

  /**
   * @desc An array of fixed length 4, used to indicate whether to return the Meta data information at the corresponding index positions. If a value at a certain index position in the array is true, then the Meta data information corresponding to that index will be returned
   */
  IncludeMeta?: boolean[];
}

/**
 * @desc Input parameter
 */
declare interface PromiseByIdsParams {
  /**
   * @desc Vector ID set
   */
  ids: number[];
}

/**
 * @desc Input parameter
 */
declare interface PromiseByMetaParams {
  /**
   * @desc Represents the index position of the Meta information in the database
   */
  index: number;

  /**
   * @desc It's an array containing meta information to be matched, with a variable length. When any meta value in the metas matches the meta value at the database index position, the corresponding data will be deleted.
   */
  metas: Array<number>;
}

/**
 * @desc object
 */
declare interface VectorIndex {
  /**
   * @desc Obtain index object
   * @param {VectorParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  insert(options: VectorParams): void;

  /**
   * @desc Obtain index object
   * @param {PromiseVectorParams}options- Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  insert(options: PromiseVectorParams): Promise<number>;

  /**
   * @desc Get index object
   * @param {SearchParams}options- Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   */
  search(options: SearchParams): void;

  /**
   * @desc Get index object
   * @param {PromiseSearchParams}options - Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Array<SearchResult>>}
   */
  search(options: PromiseSearchParams): Promise<Array<SearchResult>>;

  /**
   * @desc Delete vector data corresponding to the ID list
   * @param {ByIdsParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteByIds(options: ByIdsParams): void;

  /**
   * @desc Delete vector data corresponding to the ID list
   * @param {PromiseByIdsParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  deleteByIds(options: PromiseByIdsParams): Promise<number>;

  /**
   * @desc Delete vector data based on matching meta information
   * @param {ByMetaParams} Input parameter
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteByMeta(options: ByMetaParams): void;

  /**
   * @desc Delete vector data based on matching meta information
   * @param {PromiseByMetaParams}options- Input parameter 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<number>}
   */
  deleteByMeta(options: PromiseByMetaParams): Promise<number>;

  /**
   * @desc Delete all data under this index
   * @devices (phone,watch)
   * @apiLevel 2
   */
  deleteAll: () => void;

  /**
   * @desc  Get the data volume of this index
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  size: () => number;

  /**
   * @desc  Release index instance object
   * @devices (phone,watch)
   * @apiLevel 2
   */
  release: () => void;
}

/**
 * @desc Input parameter
 */
declare interface ByMetaParams {
  /**
   * @desc Represents the index position of the Meta information in the database
   */
  index: number;

  /**
   * @desc It's an array containing meta information to be matched, with a variable length. When any meta value in the metas matches the meta value at the database index position, the corresponding data will be deleted.
   */
  metas: Array<number>;

  /**
   * @desc Successful callback, returns the number of deleted entries. If it is 0 or a negative number, it indicates that the deletion failed
   * @param {number}count- Successful return value 
   */
  success?: (count: number) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface ByIdsParams {
  /**
   * @desc Vector ID set
   */
  ids: number[];
  /**
   * @desc Successful callback, returning the number of entries deleted. If it is 0 or a negative number, it indicates that the deletion failed.
   * @param {number} count -Successful return value
   */
  success?: (count: number) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Input parameter
 */
declare interface SearchParams {
  /**
   * @desc Vector
   */
  vector: Embedding;
  /**
   * @desc Top K closest search results
   */
  topK?: number;
  /**
   * @desc Search minimum threshold; only results above this threshold will be returned
   */
  thresholdScore?: number;

  /**
   * @desc An array of fixed length 4, used to indicate whether to return the Meta data information at the corresponding index positions. If a value at a certain index position in the array is true, then the Meta data information corresponding to that index will be returned
   */
  IncludeMeta?: boolean[];

  /**
   * @desc Successful callback
   * @param {Array<SearchResult>}result - Successful return value 
   */
  success?: (result: Array<SearchResult>) => void;
    /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface SearchResult {
  /**
   * @desc Vector ID.
   */
  id: number;
  /**
   * @desc Represents the degree of match; the higher the value, the closer the match
   */
  score: number;
  /**
   * @desc Return the corresponding field values based on the input IncludeMeta. The maximum length of the returned array is 4
   */
  meta: Array<number>;
}

/**
 * @desc Input parameter
 */
declare interface VectorParams {
  /**
   * @desc Vector list
   */
  vectorList: Array<Embedding>;
  /**
   * @desc Vector ID, when the index uses non-auto-increment IDs
   */
  ids?: Array<number>;
  /**
   * @desc Meta is used to store additional information beyond the vector itself
   */
  metaList?: Array<Meta>;

  /**
   * @desc Successful callback
   * @param {number}count- Successful return value 
   */
  success?: (count: number) => void;
     /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Vector list
 */
type Embedding = Array<number>;

/**
 * @desc Meta is used to store additional information beyond the vector itself
 */
type Meta = Array<number>;

/**
 * @desc Input parameter
 */
declare interface CreateIndexParams {
  /**
   * @desc Index name
   */
  name: string;
  /**
   * @desc Whether to enable auto-increment ID.
   */
  autoId?: boolean;
  /**
   * @desc Vector dimensions
   */
  dimension?: number;
  /**
   * @desc Algorithm used for similarity search. Default value: dotproduct (inner product similarity)
   */
  metric?: string;
}

/**
 * @desc Input parameter
 */
declare interface CommonEmbeddingParams {
  /**
   * @desc Input text
   */
  input: any;
  /**
   * @desc Model used
   */
  model?: string;
  /**
   * @desc Dimensions of the vector
   */
  dimension?: number;
  /**
   * @desc Successful callback
   * @param {EmbeddingObject}data - Successful return value
   */
  success?: (data: EmbeddingObject) => void;
     /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc Return value
 */
declare interface EmbeddingObject {
  /**
   * @desc The output is an array composed of EmbeddingData, with each element in the array containing the algorithm's output for a corresponding input
   */
  embeddings: Array<EmbeddingData>;
  /**
   * @desc Model used
   */
  model: string;
}

/**
 * @desc Each array contains the algorithm's output content corresponding to an input.
 */
declare interface EmbeddingData {
  /**
   * @desc The vectorized output result value of the input
   */
  embedding: Array<number>;
  /**
   * @desc Index of the corresponding input in the array
   */
  index: number;
}
