/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.textInputProxy" }
 */
declare module "@blueos.inputMethod.textInputProxy" {
  /**
   * @desc Insert text into the input component
   * @param {insertTextParams}options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function insertText(options: insertTextParams): Promise<void> | void;

  /**
   * @desc trigger a function key
   * @param {sendKeyActionParams}options- input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function sendKeyAction(
    options: sendKeyActionParams
  ): Promise<void> | void;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {deleteBackwardParams}options- input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */

  export function deleteBackward(
    options?: deleteBackwardParams
  ): Promise<void> | void;

  /**
   * @desc Delete a fixed length of text before the cursor
   * @param {deleteForwardParams}options- input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function deleteForward(
    options?: deleteForwardParams
  ): Promise<void> | void;

  /**
   * @desc Get the currently selected text (if any)
   * @devices (phone,watch)
   * @param {getSelectedTextParams}options- input parameters 
   * @apiLevel 2
   * @returns {Promise<string> | void}
   */
  export function getSelectedText(
    options?: getSelectedTextParams
  ): Promise<string> | void;

  /**
   * @desc Set selected text.
   * @param {setSelectionParams}options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function setSelection(
    options: setSelectionParams
  ): Promise<void> | void;

  /**
   * @desc Get the text of n characters after the current cursor position
   * @param {getTextAfterCursorParams}options- input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<string> | void}
   */
  export function getTextAfterCursor(
    options: getTextAfterCursorParams
  ): Promise<string> | void;

  /**
   * @desc Get the text of n characters before the current cursor position
   * @param {getTextBeforeCursorParams}options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<string> | void}
   */
  export function getTextBeforeCursor(
    options: getTextBeforeCursorParams
  ): Promise<string> | void;

  /**
   * @desc Callback for changes in the text of the input field
   * @param {string} options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onUpdateText: (options: string) => void;

  /**
   * @desc Callback for changes in the selected text
   * @param {onUpdateSelectionParams}options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onUpdateSelection: (options: onUpdateSelectionParams) => void;

  /**
   * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
   */
  const inputType: InputType;

  /**
   * @desc A read-only property that retrieves the enter button type set for the input field; returns an empty string if not set
   */
  const enterKeyType: EnterKeyType;
}

/**
 * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
 */
type InputType = "text" | "email";

/**
 * @desc A read-only property that retrieves the keyboard type set for the input field; returns an empty string if not set
 */
type EnterKeyType = "search" | "send";

/**
 * @desc input parameters
 */
declare interface onUpdateSelectionParams {
  /**
   * @desc starting index of the selection before the change
   */
  oldSelStart: number;

  /**
   * @desc ending index of the selection before the change
   */
  oldSelEnd: number;

  /**
   * @desc starting index of the selection after the change
   */
  newSelStart: number;

  /**
   * @desc ending index of the selection after the change
   */
  newSelEnd: number;
}

/**
 * @desc input parameters
 */
declare interface getTextBeforeCursorParams {
  /**
   * @desc Get character length
   */
  length: number;

  /**
   * @desc success callback
   * @param {string}text- return value 
   */
  success?: (text: string) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getTextAfterCursorParams {
  /**
   * @desc get character length
   */
  length: number;

  /**
   * @desc success callback
   * @param {string}text- return value 
   */
  success?: (text: string) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface setSelectionParams {
  /**
   * @desc starting index, beginning from 0
   */
  start: number;
  /**
   * @desc  ending index, beginning from 0
   */
  end: number;

  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getSelectedTextParams {
  /**
   * @desc success callback
   * @param {string}text- return value
   */
  success?: (text: string) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface deleteForwardParams {
  /**
   * @desc deletion length, default value is 1
   */
  length?: number;

  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface deleteBackwardParams {
  /**
   * @desc deletion length, default is 1
   */
  length?: number;

  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface sendKeyActionParams {
  /**
   * @desc text data to be inserted
   */
  value: string;

  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface insertTextParams {
  /**
   * @desc text data to be inserted
   */
  value: string;

  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
