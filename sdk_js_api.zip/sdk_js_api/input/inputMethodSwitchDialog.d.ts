/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodSwitchDialog" }
 */
declare module "@blueos.inputMethod.inputMethodSwitchDialog" {
  /**
   * @desc Pop up the input method switch component
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {showParams}options- Input parameters for popping up the input method switch component
   * @returns {Promise<void> | void}
   */
  export function show(options?: showParams): Promise<void> | void;
}

/**
 * @desc input parameters.
 */
declare interface showParams {
  /**
   * @desc success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
