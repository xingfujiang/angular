/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodSetting" }
 */
declare module "@blueos.inputMethod.inputMethodSetting" {
  /**
   * @desc Get current input method information
   * @param {getCurrentInputMethodInfoParams}options- Input parameters for getting current input method information
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<InputMethodInfo> | void}
   */
  export function getCurrentInputMethodInfo(
    options: getCurrentInputMethodInfoParams
  ): Promise<InputMethodInfo> | void;

  /**
   * @desc Get the current input method's subtype
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {getCurrentInputMethodSubtypeParams}options- Input parameters for getting the current input method's subtype 
   * @returns {Promise<InputMethodSubtype> | void}
   */
  export function getCurrentInputMethodSubtype(
    options?: getCurrentInputMethodSubtypeParams
  ): Promise<InputMethodSubtype> | void;

  /**
   * @desc Set the current input method's subtype
   * @param {setCurrentInputMethodSubtypeParams}options- Input parameters for setting the current input method's subtype
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function setCurrentInputMethodSubtype(
    options: setCurrentInputMethodSubtypeParams
  ): Promise<void> | void;

  /**
   * @desc Callback triggered when the current input method's subtype changes
   * @param {InputMethodSubtype}options- Input parameters for the callback triggered when the current input method's subtype changes 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const onInputMethodSubtypeChanged: (options: InputMethodSubtype) => void;

  /**
   * @desc Get the list of enabled input methods
   * @devices (phone,watch)
   * @param {getEnabledInputMethodListParams}options- Input parameters for getting the list of enabled input methods 
   * @apiLevel 2
   * @returns {Promise<Array<InputMethodInfo>> | void}
   */
  export function getEnabledInputMethodList(
    options?: getEnabledInputMethodListParams
  ): Promise<Array<InputMethodInfo>> | void;

  /**
   * @desc Get the list of installed input methods
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {getInputMethodListParams}options- Input parameters for getting the list of installed input methods
   * @returns {Promise<Array<InputMethodInfo>>}
   */
  export function getInputMethodList(
    options?: getInputMethodListParams
  ): Promise<Array<InputMethodInfo>> | void;

  /**
   * @desc Switch input method
   * @param {switchInputMethodParams}options- Input parameters for switching input methods 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */
  export function switchInputMethod(
    options: switchInputMethodParams
  ): Promise<void> | void;

  /**
   * @desc Switch input method to the specified subtype
   * @param {switchInputMethodAndSubtypeParams}options- input parameters for switching input method to the specified subtype 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  export function switchInputMethodAndSubtype(
    options: switchInputMethodAndSubtypeParams
  ): Promise<void> | void;

  /**
   * @desc Get the subtypes of the specified input method
   * @param {getInputMethodSubtypeListParams}options- Input parameters for getting the subtypes of the specified input method 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<InputMethodSubtype> | void}
   */

  export function getInputMethodSubtypeList(
    options: getInputMethodSubtypeListParams
  ): Promise<InputMethodSubtype> | void;

  /**
   * @desc Enable input method
   * @param {enableInputMethodParams}options- Input parameters for enabling the input method 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void> | void}
   */

  export function enableInputMethod(
    options: enableInputMethodParams
  ): Promise<void> | void;

  /**
   * @desc Disable input method
   * @param {disableInputMethodParams}options- Input parameters for disabling the input method
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  export function disableInputMethod(
    options: disableInputMethodParams
  ): Promise<void> | void;
}

/**
 * @desc input parameters
 */
declare interface disableInputMethodParams {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface enableInputMethodParams {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getInputMethodSubtypeListParams {
  /**
   * @desc input method ID
   */
  inputMethodId: number;

  /**
   * @desc Success callback
   * @param {InputMethodSubtype}data- return callback value
   */
  success?: (data: InputMethodSubtype) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface switchInputMethodAndSubtypeParams {
  /**
   * @desc input method ID
   */
  inputMethodId: number;
  /**
   * @desc input method subtype ID
   */
  subtypeId: number;

  /**
   * @desc Success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface switchInputMethodParams {
  /**
   * @desc input method subtype ID
   */
  inputMethodId: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getInputMethodListParams {
  /**
   * @desc Success callback
   * @param {Array<InputMethodInfo>}imInfos- callback return value 
   */
  success?: (imInfos: Array<InputMethodInfo>) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getEnabledInputMethodListParams {
  /**
   * @desc Success callback
   * @param {Array<InputMethodInfo>}imInfos- return callback value
   */
  success?: (imInfos: Array<InputMethodInfo>) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface setCurrentInputMethodSubtypeParams {
  /**
   * @desc input method subtype ID
   */
  inputMethodSubtypeId: number;
  /**
   * @desc Success callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface getCurrentInputMethodSubtypeParams {
  /**
   * @desc Success callback
   * @param {InputMethodSubtype}data- callback parameters
   */
  success?: (data: InputMethodSubtype) => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface InputMethodSubtype {
  /**
   * @desc input subtype identifier
   */
  id: string;

  /**
   * @desc BCP 47 format, such as 'zh-CN' or 'en-US'
   */
  languageTag: string;

  /**
   * @desc display name of the input method subtype
   */
  displayName: string;

  /**
   * @desc input method icon
   */
  icon: string;
}

/**
 * @desc input parameters
 */
declare interface getCurrentInputMethodInfoParams {
  /**
   * @desc Success callback
   * @param {InputMethodInfo}data- callback parameters 
   */
  success?: (data: InputMethodInfo) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc input parameters
 */
declare interface InputMethodInfo {
  /**
   * @desc  input method ID
   */
  id: string;

  /**
   * @desc input method display name
   */
  displayName: string;

  /**
   * @desc nput method name
   */
  name: string;

  /**
   * @desc input method icon
   */
  icon: string;
}
