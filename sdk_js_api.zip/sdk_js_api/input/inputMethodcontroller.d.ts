/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.inputMethodController" }
 */
declare module "@blueos.inputMethod.inputMethodController" {
  /**
   * @desc Close the input method's soft keyboard; after calling this method, the input component will also lose focus
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const dismissKeyboard: () => void;

  /**
   * @desc Monitor the input method's soft keyboard
   * @param {subscribeSoftKeyboardSizeChangeParams}options- Input parameters for monitoring the input method's soft keyboard 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {number}
   */
  const subscribeSoftKeyboardSizeChange: (
    options: subscribeSoftKeyboardSizeChangeParams
  ) => number;

  /**
   * @desc Cancel monitoring of the input method's soft keyboard
   * @param {number}options- Parameters for canceling monitoring of the input method's soft keyboard 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  const unsubscribeSoftKeyboardSizeChange: (options: number) => void;
}

/**
 * @desc input parameters.
 */
declare interface subscribeSoftKeyboardSizeChangeParams {
  /**
   * @desc monitor callback
   * @param {number}width- input parameter 
   * @param {number}heigth- input parameter 
   */
  callback: (width: number, heigth: number) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}
