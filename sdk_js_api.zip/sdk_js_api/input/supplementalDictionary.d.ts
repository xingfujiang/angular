/**
 * input method
 * Interface declaration: { "name": "blueos.inputMethod.supplementalDictionary" }
 */
declare module "@blueos.inputMethod.supplementalDictionary" {
  /**
   * @desc get value
   * @devices (phone,watch)
   * @apiLevel 2
   * @param {getDictionaryParams}options- input parameters 
   * @returns {Promise<Dictionary[]> | void}
   */
  export function getDictionary(
    options?: getDictionaryParams
  ): Promise<Dictionary[]> | void;
}

/**
 * @desc input parameters 
 */
declare interface getDictionaryParams {
  /**
   * @desc success callback
   * @param {Dictionary[]}data- return value
   */
  success?: (data: Dictionary[]) => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback 
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
}

/**
 * @desc return value
 */
declare interface Dictionary {
  /**
   * @desc icon
   */
  lexicon: string;
}
