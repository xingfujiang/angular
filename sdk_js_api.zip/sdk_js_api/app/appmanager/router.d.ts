/**
 * Page route
 * Interface declaration: No declaration needed
 */
declare module "@blueos.app.appmanager.router" {
  /**
   * @desc Navigate to a specific page within the application
   * @param {PushParams}options - Routing navigation parameters
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const push: (options: PushParams) => void;

  /**
   * @desc Navigate to a specific page within the application, with no option to return to the current page
   * @param {ReplaceParams}options- Parameters for route navigation
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const replace: (options: ReplaceParams) => void;

  /**
   * @desc Return to the specified page
   * @param {BackParams}options- Route return parameters
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const back: (options: BackParams) => void;

  /**
   * @desc Clear all historical page records, retaining only the current page
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const clear: () => void;

  /**
   * @desc Get the current page status
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {StateData}
   */
  const getState: () => StateData;

  /**
   * @desc Set the default transition animation parameters for the application
   * @param {SetTransitionParams}options- Set the default transition animation parameters for the application 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const setTransition: (options: SetTransitionParams) => void;
}

/**
 * @desc input parameter
 */
declare interface SetTransitionParams {
  /**
   * @desc animation effect when entering a page via routing
   */
  forward?: forwardData;
  /**
   * @desc animation effect when returning to a page via routing
   */
  back?: backData;
}

/**
 * @desc configuration properties
 */
declare interface TransitionData {
  /**
   * @desc animation effect when navigating to a page via routing
   */
  forward?: forwardData;
  /**
   * @desc animation effect when returning to a page via routing
   */
  back?: backData;
}

/**
 * @desc configuration properties
 */
declare interface backData {
  /**
   * @desc animation for the exiting page {@link TransitionAnimation}
   */
  exit?: string;
  /**
   * @desc animation for the appearing page {@link TransitionAnimation}
   */
  enter?: string;
}

/**
 * @desc configuration properties
 */
declare interface forwardData {
  /**
   * @desc animation for the exiting page {@link TransitionAnimation}
   */
  exit?: string;
  /**
   * @desc animation for the appearing page {@link TransitionAnimation}
   */
  enter?: string;
}

/**
 * @desc input parameter
 */
declare interface StateData {
  /**
   * @desc the position of the current page in the page stack
   */
  index: number;

  /**
   * @desc the name of the current page
   */
  name: string;

  /**
   * @desc the path of the current page
   */
  path: string;
}

/**
 * @desc input parameter
 */
declare interface BackParams {
  /**
   * @desc Return the path of the target page; if this parameter is not provided, it returns to the previous page. The path should start with '/' for pages within the application that have already been opened; for example: /about. Specifically, if the value of path is '/', then it navigates to the page named '/' if it exists, otherwise it navigates to the home page
   */
  path?: string;
}

/**
 * @desc input parameter
 */
declare interface ReplaceParams {
  /**
   * @desc The URI to navigate to, using a path within the application that starts with '/'; for example: /about. Alternatively, use the name of the page within the application that does not start with '/'; for example: About. Specifically, if the value of the URI is '/', it will navigate to the page with the path '/', and if it does not exist, it will navigate to the home page
   */
  uri: string;

  /**
   * @desc The data that needs to be passed during navigation, with parameters accessible in the page using this.param1, where param1 is the parameter name in the JSON. The value corresponding to param1 will be uniformly converted to a String type
   */
  params?: Record<any, any>;
}

/**
 * @desc input parameter
 */
declare interface PushParams {
  /**
   * @desc The URI to navigate to, which includes a complete URI with a schema; currently supported schemas are tel, sms, and mailto, for example, tel:10086. A path within the application starting with '/'; for example: /about. Alternatively, the name of a page within the application that does not start with '/'; for example: About.
   */
  uri: string;

  /**
   * @desc The data that needs to be passed during navigation, with parameters accessible in the page using this.param1, where param1 is the parameter name in the JSON. The value corresponding to param1 will be uniformly converted to a String type. {@link '@blueos.media.audio.audioManager'}
   */
  params?: Record<any, any>;
  /**
   * @desc Set the transition animation for the current navigation
   */
  transition?: TransitionData;
}
