/**
 * scheduled task
 * Interface declaration: {"name": "blueos.app.appmanager.schedule"}
 */
declare module "@blueos.app.appmanager.schedule" {
  /**
   * @desc Set scheduled task
   * @param {ScheduleJobParams} options- Set scheduled task input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Array<Data>> | void}
   */
  export function scheduleJob(
    options: ScheduleJobParams
  ): Promise<Array<Data>> | void;

  /**
   * @desc Cancel scheduled task
   * @param {number} id Cancel scheduled task input parameter
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {boolean}
   */
  const cancel: (id: number) => boolean;
}

/**
 *  @desc return value
 */
declare interface Data {
  /**
   *  @desc uniquely allocated ID by the underlying system
   */
  id: number;
}

/**
 *  @desc  input parameter
 */
declare interface ScheduleJobParams {
  /**
   *  @desc  Hardware time and real elapsed time: the former can trigger the triggerMethod by modifying the system time, whereas the latter relies on the actual passage of time. Even in sleep mode, time is still accounted for
   */
  type: number;
  /**
   *  @desc If type is 1, it represents the timestamp of the first execution time, which is the number of milliseconds from 1970/01/01 00:00:00 GMT to the current time. If type is 2, it represents the interval from the current time to the first execution time in milliseconds
   */
  timeout: number;
  /**
   *  @desc The method name defined in app.ux, which is called when initiated by the background
   */
  triggerMethod: string;
  /**
   *  @desc The interval for periodic execution, in milliseconds. If not specified, it will not execute repeatedly
   */
  interval: number;
  /**
   *  @desc task parameters
   */
  params: Record<any, any>;
  /**
   *  @desc success callback
   *  @param {Data} data - return value 
   */
  success?: (data: Data) => void;

   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
