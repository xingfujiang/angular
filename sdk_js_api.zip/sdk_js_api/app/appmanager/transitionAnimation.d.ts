/**
 * built-in animation name enumeration
 */
declare enum TransitionAnimation {
  /**
   * @desc slide in from the left
   */
  SlideInLeft = "slideInLeft",
  /**
   * @desc slide out to the right
   */
  SlideOutRight = "slideOutRight",
  /**
   * @desc fade in
   */
  FadeIn = "fadeIn",
  /**
   * @desc fade out
   */
  FadeOut = "fadeOut",
  /**
   * @desc No animation, instant display/instant hide
   */
  None = "none",
  /**
   * @desc zoom in
   */
  ZoomIn = "zoomIn",
  /**
   * @desc screen on event
   */
  ZoomOut = "zoomOut",
}
