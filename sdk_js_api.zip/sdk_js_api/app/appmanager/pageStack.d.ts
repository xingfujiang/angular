/**
 * Page stack management.
 * Interface declaration: {"name": "blueos.app.appmanager.pageStack"}
 */
declare module "@blueos.app.appmanager.pageStack" {
  /**
   *  @desc  Get page stack information.
   *  @param  {GetAppStacksParams}options- Input parameters for getting page stack information 
   *  @devices (phone,watch)
   *  @apiLevel 1
   *  @returns {Promise<Array<AppStackPages>> | void}
   */
  export function getAppStacks(
    options: GetAppStacksParams
  ): Promise<Array<AppStackPages>> | void;

  /**
   *  @desc  Close page
   *  @param  {CloseParams}options- Input parameters for closing page 
   *  @devices (phone,watch)
   *  @apiLevel 1
   * @returns  {Promise<void> | void}
   */

  export function close(options: CloseParams): Promise<void> | void;
}

/**
 * @desc Application configuration item
 */
declare interface PageList {
  /**
   * @desc Application package name
   */
  package: string;
  /**
   * @desc Page ID
   */
  pageIds: Array<string>;
  /**
   * @desc Page path
   */
  paths: Array<string>;
}

/**
 * @desc Input parameter
 */
declare interface CloseParams {
  /**
   * @desc Close application configuration item
   */
  pageList: Array<PageList>;

  /**
   *  @desc Successful callback
   */
  success?: () => void;

   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc Callback after execution completion
   */
  complete?: () => void;
}

/**
 * @desc Application information
 */
declare interface AppInfo {
  /**
   * @desc Hierarchy of the associated application
   */
  zIndex: number;
  /**
   * @desc Application package name
   */
  package: string;
}

/**
 * @desc Application page stack information
 */
declare interface Pages {
  /**
   * @desc Page ID
   */
  pageId: number;
  /**
   * @desc Page path
   */
  path: string;
}

/**
 * @desc Return value
 */
declare interface AppStackPages {
  /**
   * @desc Application information
   */
  appInfo: AppInfo;
  /**
   * @desc Application page stack information
   */
  pages: Array<Pages>;
}

/**
 * @desc Input parameter
 */
declare interface GetAppStacksParams {
  /**
   *   @desc Application package name. By default, it retrieves page stack information for all applications, or can be specified as ['com.vivo.app1', 'com.vivo.app2'] or 'com.vivo.app1'.
   */
  package: Array<string> | string;
  /**
   *   @desc Successful callback
   *   @param {Array<AppStackPages>}appStackPages - Return value of the successful callback 
   */
  success?: (appStackPages: Array<AppStackPages>) => void;

  /**
   * 	@desc Failed callback function
   * 	@param {any}data- Return value of the failed callback 
   *	@param {number}code- Return status code of the failed callback
   */
  fail?: (data: any, code: number) => void;
  /**
   *  @desc Callback after execution completion
   */
  complete?: () => void;
}
