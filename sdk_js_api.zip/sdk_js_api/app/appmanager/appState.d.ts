/**
 * Application management
 * Interface declaration: {"name": "blueos.app.appmanager.appState"}
 */
declare module "@blueos.app.appmanager.appState" {
  /**
   * @desc Move the current top application to the background
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {boolean}
   */
  const moveTaskToBack: () => boolean;
}
