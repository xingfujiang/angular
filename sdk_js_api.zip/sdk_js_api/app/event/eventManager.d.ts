/**
 * publish public event
 * Interface declaration: {"name": "blueos.app.event.eventManager"}
 */
declare module "@blueos.app.event.eventManager" {
  /**
   * configuration properties
   */
  const CommonEvent: {
    /**
     * about to shut down
     */
    Shutdown: "usual.event.SHUTDOWN";
  };
  /**
   * @desc publish public event
   * @param {PublishParams}options- input parameters for publishing a public event
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const publish: (options: PublishParams) => void;

  /**
   * @desc subscribe to public events
   * @param {subscribeParams}options- input parameters for subscribing to public events 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {number}
   */
  const subscribe: (options: subscribeParams) => number;

  /**
   * @desc unsubscribe from public events
   * @param {unsubscribeParams}options- input parameters for unsubscribing from public events 
   * @devices (phone,watch)
   * @apiLevel 1
   */
  const unsubscribe: (options: unsubscribeParams) => void;
}

/**
 *  @desc input parameter
 */
declare interface unsubscribeParams {
  /**
   *  @desc subscription id
   */
  id: number;
}

/**
 *  @desc input parameter
 */
declare interface subscribeParams {
  /**
   *  @desc event name
   */
  eventName: SystemEvent;
  /**
   *  @desc event callback
   *  @param {Data}data- return value of the callback 
   */
  callback: (data: Data) => void;
}

/**
 *  @desc return value
 */
declare interface Data {
  /**
   *  @desc event parameters
   */
  params: Record<any, any>;
  /**
   *  @desc event publisher package name
   */
  package: string;
}

/**
 *  @desc input parameter
 */
declare interface PublishParams {
  /**
   *  @desc Event name: Reserved names for public events are occupied by the system, please do not use them.
   */
  eventName: string;

  /**
   *  @desc event parameters
   */
  options?: OptionsParams;
}

/**
 *  @desc configuration parameters
 */
declare interface OptionsParams {
  /**
   *  @desc event parameters
   */
  params: Record<any, any>;
  /**
   *  @desc Permissions of the subscriber: only packages with the required permissions can receive the sent events
   */
  permissions: Array<string>;
}

/**
 * public event naming enumeration
 */
declare enum SystemEvent {
  /**
   * about to shut down
   */
  Shutdown = "usual.event.SHUTDOWN",
  /**
   * Battery level change, parameter: level: between 0.0 and 1.0
   */
  BatteryChanged = "usual.event.BATTERY_CHANGED",
  /**
   * low battery event
   */
  BatteryLow = "usual.event.BATTERY_LOW",
  /**
   * battery full event
   */
  BatteryOkay = "usual.event.BATTERY_OKAY",
  /**
   * screen off event
   */
  ScreenOff = "usual.event.SCREEN_OFF",
  /**
   * AOD event
   */
  ScreenAod = "usual.event.SCREEN_AOD",
  /**
   * screen on event
   */
  ScreenOn = "usual.event.SCREEN_ON",
  /**
   * newly installed application
   */
  PackageAdded = "usual.event.PACKAGE_ADDED",
  /**
   * application installation update
   */
  PackageReplaced = "usual.event.PACKAGE_REPLACED",
  /**
   * application uninstallation
   */
  PackageRemoved = "usual.event.PACKAGE_REMOVED",
  /**
   * stop charging
   */
  Discharging = "usual.event.DISCHARGING",
  /**
   * start charging
   */
  Charging = "usual.event.CHARGING",
  /**
   * ota start transfer
   */
  OtaTransfer = "usual.event.OTA_TRANSFER",
  /**
   * ota start installation
   */
  OtaInstall = "usual.event.OTA_INSTALL",
}
