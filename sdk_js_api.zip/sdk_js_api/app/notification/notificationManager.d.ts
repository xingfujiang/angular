/**
 * notification message
 * Interface declaration: {"name": "blueos.app.notification.notificationManager"}
 */
declare module "@blueos.app.notification.notificationManager" {
  /**
   * @desc publish notification
   * @param {publishParams}options- publish notification input parameters
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function publish(options: publishParams): Promise<void> | void;

  /**
   * @desc clear message notification
   * @param {removeParams}options - clear message notification input parameters 
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<void> | void}
   */
  export function remove(options: removeParams): Promise<void> | void;
}

/**
 * @desc query conditions
 */
declare interface QueryData {
  /**
   * @desc unique ID of the application notification
   */
  id?: number;
  /**
   * @desc notification group
   */
  group?: string;
}

/**
 * @desc input parameter
 */
declare interface removeParams {
  /**
   * @desc conditions for clearing; if the conditions are empty, clear all
   */
  query: QueryData;
  /**
   * @desc successful callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 * @desc input parameter
 */
declare interface ActionData {
  /**
   * @desc Define the callback function triggered by button click, which needs to be defined in app.ux
   */
  triggerMethod?: string;
  /**
   * @desc custom parameters for use by the callback function
   */
  prameters?: Record<string, any>;
}

/**
 * @desc input parameter
 */
declare interface ActionButtonsData {
  /**
   * @desc button title
   */
  label: string;
  /**
   * @desc action triggered upon button click
   */
  action: ActionData;

  /**
   * @desc extended parameters
   */
  extras?: Record<string, any>;
}

/**
 * @desc message notification object
 */
declare interface ContentData {
  /**
   * @desc plain text notification title
   */
  title: string;
  /**
   * @desc plain text notification content
   */
  text: string;
  /**
   * @desc image text notification summary content
   */
  additionalText?: string;
  /**
   * @desc image notification extended title
   */
  briefText?: string;
  /**
   * @desc image text notification brief content
   */
  expandedTitle?: string;
  /**
   * @desc The image for the picture notification, the absolute path of the image under the application
   */
  picture?: string;
}

/**
 * @desc message notification object
 */
declare interface RequestData {
  /**
   * @desc notification small icon, the absolute path of the image under the application
   */
  icon: string;
  /**
   * @desc unique ID of the application notification
   */
  id?: number;
  /**
   * @desc application name
   */
  appName?: string;
  /**
   * @desc Content type. 1: Plain text notification type. 2: Image notification type
   */
  contentType: number;
  /**
   * @desc notification content corresponding to contentType
   */
  content: ContentData;
  /**
   * @desc notification source, 1: PHONE; 2: WATCH_APP
   */
  channel: number;
  /**
   * @desc message channel source (when PHONE) iOS | Android
   */
  platform?: string;
  /**
   * @desc notification sending time
   */
  deliveryTime: number;
  /**
   * @desc notification buttons, up to two buttons
   */
  actionButtons?: Array<ActionButtonsData>;
  /**
   * @desc notification large icon, the absolute path of the image under the application
   */
  largeIcon?: string;
  /**
   * @desc whether it is non-clearable
   */
  isUnremovable?: boolean;
  /**
   * @desc numeric badge (in case of message aggregation)
   */
  badge?: number;
  /**
   * @desc application package name, in the format com.xxx.xxx, this field's value should be filled by native
   */
  appBundleName?: string;
  /**
   * @desc message group
   */
  group?: string;
  /**
   * @desc extended parameters.
   */
  extraInfo?: Record<string, any>;
}

/**
 * @desc input parameter
 */
declare interface publishParams {
  /**
   * @desc message notification object
   */
  request: RequestData;
  /**
   * @desc successful callback
   */
  success?: () => void;
   /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}
