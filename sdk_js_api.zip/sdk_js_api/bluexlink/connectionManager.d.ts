/**
 * device communication
 * Interface declaration: {"name": "blueos.bluexlink.connectionManager"}
 */
declare module "@blueos.bluexlink.connectionManager" {
  /**
   * @desc get the connection status between the watch and the phone
   * @param {getPeerDeviceStatusParams} options- get the connection status between the watch and the phone input parameters
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Promise<Data> | void}
   */
  export function getPeerDeviceStatus(
    options: getPeerDeviceStatusParams
  ): Promise<Data> | void;

  /**
   * @desc create connection instance
   * @param {instanceParams}options- create connection instance input parameters
   * @devices (phone,watch)
   * @apiLevel 1
   * @returns {Instance}
   */
  const instance: (options: instanceParams) => Instance;
}

/**
 *  @desc input parameter
 */
declare interface getPeerDeviceStatusParams {
  /**
   *  @desc success callback
   *  @param {Data}data- return value
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface GetPeerDeviceClientVersionParams {
  /**
   *  @desc success callback
   *  @param {VersionData}data-return value
   */
  success?: (data: VersionData) => void;


  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc return value
 */
declare interface Data {
  /**
   *  @desc 0: not connected. 1: connected
   */
  status: number;
}

/**
 *  @desc return value
 */
declare interface VersionData {
  /**
   *  @desc mobile application version number, returns normally if available, -1: not installed
   */
  version: number;
}

/**
 *  @desc input parameter
 */
declare interface instanceParams {
  /**
   *  @desc mobile app package name
   */
  package: string;
  /**
   *  @desc certificate fingerprint information of the mobile app
   */
  fingerprint: string;
}

/**
 *  @desc input parameter
 */
declare interface SendParams {
  /**
   *  @desc data to be sent
   */
  data: Record<any, any>;

  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface PromiseSendParams {
  /**
   *  @desc data to be sent
   */
  data: Record<any, any>;
}

/**
 *  @desc input parameter
 */
declare interface SendFileParams {
  /**
   *  @desc URI of the directory
   */
  uri: string;
  /**
   *  @desc success callback
   */
  success?: () => void;
  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface PromiseSendFileParams {
  /**
   *  @desc directory URI
   */
  uri: string;
}

/**
 *  @desc return value
 */
declare interface MessageParams {
  /**
   * @desc whether it is a file
   */
  isFileType: boolean;
  /**
   * @desc file storage path
   */
  fileUri: string;
  /**
   * @desc file name
   */
  fileName: string;
}

/**
 *  @desc input parameter
 */
declare interface CloseParams {
  /**
   *  @desc success callback
   */
  success?: () => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc input parameter
 */
declare interface GetReadyStateParams {
  /**
   *  @desc success callback
   *  @param {Data} data - return value 
   */
  success?: (data: Data) => void;

  /**
   * 	@desc failure callback function
   * 	@param {any}data- return value of the failure callback
   *	@param {number}code- return status code of the failure callback 
   */
  fail?: (data: any, code: number) => void;
  /**
   * @desc callback after execution completes
   */
  complete?: () => void;
}

/**
 *  @desc return value
 */
declare interface Instance {
  /**
   * @desc get app connection status
   * @param {GetReadyStateParams}options  get app connection status input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  getReadyState(options?: GetReadyStateParams): void;

  /**
   * @desc get app connection status
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<Data>}
   */
  getReadyState(): Promise<Data>;

  /**
   * @desc query app version status
   * @param {GetPeerDeviceClientVersionParams}options - query app version status input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  getPeerDeviceClientVersion(options?: GetPeerDeviceClientVersionParams): void;

  /**
   * @desc query app version status
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<VersionData>}
   */
  getPeerDeviceClientVersion(): Promise<VersionData>;

  /**
   * @desc used to specify the callback function when the connection is opened
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onOpen: () => void;

  /**
   * @desc used to specify the callback function when the connection is closed
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onClose: () => void;

  /**
   * @desc used to specify the callback function after the connection fails
   * @param {string}data - error message 
   * @param {number}code - return status code of the failure callback
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onError: (data: string, code: number) => void;

  /**
   * @desc send information
   * @param {SendParams}options- send information input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   */
  send(options: SendParams): void;

  /**
   * @desc send information
   * @param {PromiseSendParams}options- send information input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  send(options: PromiseSendParams): Promise<void>;

  /**
   * @desc send data to the mobile app end
   * @param {SendFileParams}options- input parameters
   * @devices (phone,watch)
   * @apiLevel 2
   */
  sendFile(options: SendFileParams): void;

  /**
   * @desc send data to the mobile app end
   * @param {PromiseSendFileParams}options- input parameters 
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  sendFile(options: PromiseSendFileParams): Promise<void>;

  /**
   * @desc close the current connection
   * @param {CloseParams}options- function input parameters for closing the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   */
  close(options?: CloseParams): void;

  /**
   * @desc close the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   * @returns {Promise<void>}
   */
  close(): Promise<void>;

  /**
   * @desc receive data from the mobile app end.
   * @param {MessageParams}options- function input parameters for closing the current connection
   * @devices (phone,watch)
   * @apiLevel 2
   */
  onMessage: (options: MessageParams) => void;
}
